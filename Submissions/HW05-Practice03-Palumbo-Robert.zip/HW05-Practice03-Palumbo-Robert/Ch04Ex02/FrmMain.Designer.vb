﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.grpStockFrmMain = New System.Windows.Forms.GroupBox()
        Me.btnOfferGrpStockFrmMain = New System.Windows.Forms.Button()
        Me.txtStkPriceGrpStockFrmMain = New System.Windows.Forms.TextBox()
        Me.txtStkNameGrpStockFrmMain = New System.Windows.Forms.TextBox()
        Me.txtStkSymGrpStockFrmMain = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.grpPtfItemFrmMain = New System.Windows.Forms.GroupBox()
        Me.txtSharesGrpPtfItemFrmMain = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.btnBuyGrpPtfItemFrmMain = New System.Windows.Forms.Button()
        Me.txtStkPriceGrpPtfItemFrmMain = New System.Windows.Forms.TextBox()
        Me.txtStkNameGrpPtfItemFrmMain = New System.Windows.Forms.TextBox()
        Me.txtStkSymGrpPtfItemFrmMain = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.txtCntGrpStkMktFrmMain = New System.Windows.Forms.TextBox()
        Me.lstStkPriceGrpStkMktFrmMain = New System.Windows.Forms.ListBox()
        Me.lstStkNameGrpStkMktFrmMain = New System.Windows.Forms.ListBox()
        Me.lstStkSymGrpStkMktFrmMain = New System.Windows.Forms.ListBox()
        Me.btnDispPortGrpPortfolioFrmMain = New System.Windows.Forms.Button()
        Me.lstStkSharesGrpPortfolioFrmMain = New System.Windows.Forms.ListBox()
        Me.lstStkNameGrpPortfolioFrmMain = New System.Windows.Forms.ListBox()
        Me.lstStkSymGrpPortfolioFrmMain = New System.Windows.Forms.ListBox()
        Me.lstStkPriceGrpPortfolioFrmMain = New System.Windows.Forms.ListBox()
        Me.lstStkValueGrpPortfolioFrmMain = New System.Windows.Forms.ListBox()
        Me.grpTransLogFrmMain = New System.Windows.Forms.GroupBox()
        Me.txtTransLogFrmMain = New System.Windows.Forms.TextBox()
        Me.btnExitFrmMain = New System.Windows.Forms.Button()
        Me.txtCntGrpPortfolioFrmMain = New System.Windows.Forms.TextBox()
        Me.btnRunTestData = New System.Windows.Forms.Button()
        Me.grpStkMktFrmMain = New System.Windows.Forms.GroupBox()
        Me.btnDispStkMktGrpStkMktFrmMain = New System.Windows.Forms.Button()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.grpPortfolioFrmMain = New System.Windows.Forms.GroupBox()
        Me.txtValueGrpPortfolioFrmMain = New System.Windows.Forms.TextBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.grpStockFrmMain.SuspendLayout()
        Me.grpPtfItemFrmMain.SuspendLayout()
        Me.grpTransLogFrmMain.SuspendLayout()
        Me.grpStkMktFrmMain.SuspendLayout()
        Me.grpPortfolioFrmMain.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Modern No. 20", 24.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Maroon
        Me.Label1.Location = New System.Drawing.Point(210, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(588, 34)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Stock Market Portfolio Management System"
        '
        'grpStockFrmMain
        '
        Me.grpStockFrmMain.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.grpStockFrmMain.Controls.Add(Me.btnOfferGrpStockFrmMain)
        Me.grpStockFrmMain.Controls.Add(Me.txtStkPriceGrpStockFrmMain)
        Me.grpStockFrmMain.Controls.Add(Me.txtStkNameGrpStockFrmMain)
        Me.grpStockFrmMain.Controls.Add(Me.txtStkSymGrpStockFrmMain)
        Me.grpStockFrmMain.Controls.Add(Me.Label4)
        Me.grpStockFrmMain.Controls.Add(Me.Label3)
        Me.grpStockFrmMain.Controls.Add(Me.Label2)
        Me.grpStockFrmMain.Location = New System.Drawing.Point(39, 79)
        Me.grpStockFrmMain.Name = "grpStockFrmMain"
        Me.grpStockFrmMain.Size = New System.Drawing.Size(281, 176)
        Me.grpStockFrmMain.TabIndex = 1
        Me.grpStockFrmMain.TabStop = False
        Me.grpStockFrmMain.Text = "Stock"
        '
        'btnOfferGrpStockFrmMain
        '
        Me.btnOfferGrpStockFrmMain.Location = New System.Drawing.Point(103, 140)
        Me.btnOfferGrpStockFrmMain.Name = "btnOfferGrpStockFrmMain"
        Me.btnOfferGrpStockFrmMain.Size = New System.Drawing.Size(75, 23)
        Me.btnOfferGrpStockFrmMain.TabIndex = 6
        Me.btnOfferGrpStockFrmMain.Text = "&Offer"
        Me.ToolTip1.SetToolTip(Me.btnOfferGrpStockFrmMain, "Click to sell shares")
        Me.btnOfferGrpStockFrmMain.UseVisualStyleBackColor = True
        '
        'txtStkPriceGrpStockFrmMain
        '
        Me.txtStkPriceGrpStockFrmMain.Location = New System.Drawing.Point(126, 87)
        Me.txtStkPriceGrpStockFrmMain.Name = "txtStkPriceGrpStockFrmMain"
        Me.txtStkPriceGrpStockFrmMain.Size = New System.Drawing.Size(77, 20)
        Me.txtStkPriceGrpStockFrmMain.TabIndex = 5
        Me.ToolTip1.SetToolTip(Me.txtStkPriceGrpStockFrmMain, "Price per share")
        '
        'txtStkNameGrpStockFrmMain
        '
        Me.txtStkNameGrpStockFrmMain.Location = New System.Drawing.Point(126, 58)
        Me.txtStkNameGrpStockFrmMain.Name = "txtStkNameGrpStockFrmMain"
        Me.txtStkNameGrpStockFrmMain.Size = New System.Drawing.Size(112, 20)
        Me.txtStkNameGrpStockFrmMain.TabIndex = 3
        Me.ToolTip1.SetToolTip(Me.txtStkNameGrpStockFrmMain, "Stock name")
        '
        'txtStkSymGrpStockFrmMain
        '
        Me.txtStkSymGrpStockFrmMain.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtStkSymGrpStockFrmMain.Location = New System.Drawing.Point(126, 30)
        Me.txtStkSymGrpStockFrmMain.Name = "txtStkSymGrpStockFrmMain"
        Me.txtStkSymGrpStockFrmMain.Size = New System.Drawing.Size(77, 20)
        Me.txtStkSymGrpStockFrmMain.TabIndex = 1
        Me.ToolTip1.SetToolTip(Me.txtStkSymGrpStockFrmMain, "Enter the stock market ticker symbol")
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(86, 90)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(34, 13)
        Me.Label4.TabIndex = 4
        Me.Label4.Text = "Price:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(82, 61)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(38, 13)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Name:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(43, 33)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(77, 13)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "Ticker Symbol:"
        '
        'grpPtfItemFrmMain
        '
        Me.grpPtfItemFrmMain.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.grpPtfItemFrmMain.Controls.Add(Me.txtSharesGrpPtfItemFrmMain)
        Me.grpPtfItemFrmMain.Controls.Add(Me.Label8)
        Me.grpPtfItemFrmMain.Controls.Add(Me.btnBuyGrpPtfItemFrmMain)
        Me.grpPtfItemFrmMain.Controls.Add(Me.txtStkPriceGrpPtfItemFrmMain)
        Me.grpPtfItemFrmMain.Controls.Add(Me.txtStkNameGrpPtfItemFrmMain)
        Me.grpPtfItemFrmMain.Controls.Add(Me.txtStkSymGrpPtfItemFrmMain)
        Me.grpPtfItemFrmMain.Controls.Add(Me.Label5)
        Me.grpPtfItemFrmMain.Controls.Add(Me.Label6)
        Me.grpPtfItemFrmMain.Controls.Add(Me.Label7)
        Me.grpPtfItemFrmMain.Location = New System.Drawing.Point(39, 265)
        Me.grpPtfItemFrmMain.Name = "grpPtfItemFrmMain"
        Me.grpPtfItemFrmMain.Size = New System.Drawing.Size(281, 186)
        Me.grpPtfItemFrmMain.TabIndex = 2
        Me.grpPtfItemFrmMain.TabStop = False
        Me.grpPtfItemFrmMain.Text = "Portfolio Item"
        '
        'txtSharesGrpPtfItemFrmMain
        '
        Me.txtSharesGrpPtfItemFrmMain.Location = New System.Drawing.Point(126, 108)
        Me.txtSharesGrpPtfItemFrmMain.Name = "txtSharesGrpPtfItemFrmMain"
        Me.txtSharesGrpPtfItemFrmMain.Size = New System.Drawing.Size(77, 20)
        Me.txtSharesGrpPtfItemFrmMain.TabIndex = 7
        Me.txtSharesGrpPtfItemFrmMain.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.ToolTip1.SetToolTip(Me.txtSharesGrpPtfItemFrmMain, "Enter number of shares to buy")
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(77, 111)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(43, 13)
        Me.Label8.TabIndex = 6
        Me.Label8.Text = "Shares:"
        '
        'btnBuyGrpPtfItemFrmMain
        '
        Me.btnBuyGrpPtfItemFrmMain.Location = New System.Drawing.Point(103, 143)
        Me.btnBuyGrpPtfItemFrmMain.Name = "btnBuyGrpPtfItemFrmMain"
        Me.btnBuyGrpPtfItemFrmMain.Size = New System.Drawing.Size(75, 23)
        Me.btnBuyGrpPtfItemFrmMain.TabIndex = 8
        Me.btnBuyGrpPtfItemFrmMain.Text = "&Buy"
        Me.ToolTip1.SetToolTip(Me.btnBuyGrpPtfItemFrmMain, "Click to buy the specified shares")
        Me.btnBuyGrpPtfItemFrmMain.UseVisualStyleBackColor = True
        '
        'txtStkPriceGrpPtfItemFrmMain
        '
        Me.txtStkPriceGrpPtfItemFrmMain.Location = New System.Drawing.Point(126, 76)
        Me.txtStkPriceGrpPtfItemFrmMain.Name = "txtStkPriceGrpPtfItemFrmMain"
        Me.txtStkPriceGrpPtfItemFrmMain.ReadOnly = True
        Me.txtStkPriceGrpPtfItemFrmMain.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.txtStkPriceGrpPtfItemFrmMain.Size = New System.Drawing.Size(77, 20)
        Me.txtStkPriceGrpPtfItemFrmMain.TabIndex = 5
        Me.txtStkPriceGrpPtfItemFrmMain.TabStop = False
        Me.ToolTip1.SetToolTip(Me.txtStkPriceGrpPtfItemFrmMain, "Price per share")
        '
        'txtStkNameGrpPtfItemFrmMain
        '
        Me.txtStkNameGrpPtfItemFrmMain.Location = New System.Drawing.Point(126, 47)
        Me.txtStkNameGrpPtfItemFrmMain.Name = "txtStkNameGrpPtfItemFrmMain"
        Me.txtStkNameGrpPtfItemFrmMain.ReadOnly = True
        Me.txtStkNameGrpPtfItemFrmMain.Size = New System.Drawing.Size(112, 20)
        Me.txtStkNameGrpPtfItemFrmMain.TabIndex = 3
        Me.txtStkNameGrpPtfItemFrmMain.TabStop = False
        Me.ToolTip1.SetToolTip(Me.txtStkNameGrpPtfItemFrmMain, "Stock name")
        '
        'txtStkSymGrpPtfItemFrmMain
        '
        Me.txtStkSymGrpPtfItemFrmMain.Location = New System.Drawing.Point(126, 19)
        Me.txtStkSymGrpPtfItemFrmMain.Name = "txtStkSymGrpPtfItemFrmMain"
        Me.txtStkSymGrpPtfItemFrmMain.ReadOnly = True
        Me.txtStkSymGrpPtfItemFrmMain.Size = New System.Drawing.Size(77, 20)
        Me.txtStkSymGrpPtfItemFrmMain.TabIndex = 1
        Me.txtStkSymGrpPtfItemFrmMain.TabStop = False
        Me.ToolTip1.SetToolTip(Me.txtStkSymGrpPtfItemFrmMain, "Enter the stock market ticker symbol")
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(86, 79)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(34, 13)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Price:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(82, 50)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(38, 13)
        Me.Label6.TabIndex = 2
        Me.Label6.Text = "Name:"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(43, 22)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(77, 13)
        Me.Label7.TabIndex = 0
        Me.Label7.Text = "Ticker Symbol:"
        '
        'txtCntGrpStkMktFrmMain
        '
        Me.txtCntGrpStkMktFrmMain.Location = New System.Drawing.Point(66, 142)
        Me.txtCntGrpStkMktFrmMain.Name = "txtCntGrpStkMktFrmMain"
        Me.txtCntGrpStkMktFrmMain.ReadOnly = True
        Me.txtCntGrpStkMktFrmMain.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.txtCntGrpStkMktFrmMain.Size = New System.Drawing.Size(75, 20)
        Me.txtCntGrpStkMktFrmMain.TabIndex = 7
        Me.txtCntGrpStkMktFrmMain.TabStop = False
        Me.txtCntGrpStkMktFrmMain.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.ToolTip1.SetToolTip(Me.txtCntGrpStkMktFrmMain, "Number of stocks contained in stock market")
        '
        'lstStkPriceGrpStkMktFrmMain
        '
        Me.lstStkPriceGrpStkMktFrmMain.BackColor = System.Drawing.SystemColors.Control
        Me.lstStkPriceGrpStkMktFrmMain.Enabled = False
        Me.lstStkPriceGrpStkMktFrmMain.FormatString = "C2"
        Me.lstStkPriceGrpStkMktFrmMain.FormattingEnabled = True
        Me.lstStkPriceGrpStkMktFrmMain.Location = New System.Drawing.Point(335, 35)
        Me.lstStkPriceGrpStkMktFrmMain.Name = "lstStkPriceGrpStkMktFrmMain"
        Me.lstStkPriceGrpStkMktFrmMain.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.lstStkPriceGrpStkMktFrmMain.Size = New System.Drawing.Size(76, 95)
        Me.lstStkPriceGrpStkMktFrmMain.TabIndex = 5
        Me.lstStkPriceGrpStkMktFrmMain.TabStop = False
        Me.ToolTip1.SetToolTip(Me.lstStkPriceGrpStkMktFrmMain, "Price per share ")
        '
        'lstStkNameGrpStkMktFrmMain
        '
        Me.lstStkNameGrpStkMktFrmMain.BackColor = System.Drawing.SystemColors.Control
        Me.lstStkNameGrpStkMktFrmMain.Enabled = False
        Me.lstStkNameGrpStkMktFrmMain.FormattingEnabled = True
        Me.lstStkNameGrpStkMktFrmMain.Location = New System.Drawing.Point(148, 35)
        Me.lstStkNameGrpStkMktFrmMain.Name = "lstStkNameGrpStkMktFrmMain"
        Me.lstStkNameGrpStkMktFrmMain.Size = New System.Drawing.Size(181, 95)
        Me.lstStkNameGrpStkMktFrmMain.TabIndex = 3
        Me.lstStkNameGrpStkMktFrmMain.TabStop = False
        Me.ToolTip1.SetToolTip(Me.lstStkNameGrpStkMktFrmMain, "Stock name")
        '
        'lstStkSymGrpStkMktFrmMain
        '
        Me.lstStkSymGrpStkMktFrmMain.FormattingEnabled = True
        Me.lstStkSymGrpStkMktFrmMain.Location = New System.Drawing.Point(22, 35)
        Me.lstStkSymGrpStkMktFrmMain.Name = "lstStkSymGrpStkMktFrmMain"
        Me.lstStkSymGrpStkMktFrmMain.Size = New System.Drawing.Size(120, 95)
        Me.lstStkSymGrpStkMktFrmMain.TabIndex = 1
        Me.ToolTip1.SetToolTip(Me.lstStkSymGrpStkMktFrmMain, "Ticker symbol")
        '
        'btnDispPortGrpPortfolioFrmMain
        '
        Me.btnDispPortGrpPortfolioFrmMain.Location = New System.Drawing.Point(236, 143)
        Me.btnDispPortGrpPortfolioFrmMain.Name = "btnDispPortGrpPortfolioFrmMain"
        Me.btnDispPortGrpPortfolioFrmMain.Size = New System.Drawing.Size(128, 23)
        Me.btnDispPortGrpPortfolioFrmMain.TabIndex = 12
        Me.btnDispPortGrpPortfolioFrmMain.Text = "Display &Portfolio"
        Me.ToolTip1.SetToolTip(Me.btnDispPortGrpPortfolioFrmMain, "Click to display current portfolio")
        Me.btnDispPortGrpPortfolioFrmMain.UseVisualStyleBackColor = True
        '
        'lstStkSharesGrpPortfolioFrmMain
        '
        Me.lstStkSharesGrpPortfolioFrmMain.BackColor = System.Drawing.SystemColors.Control
        Me.lstStkSharesGrpPortfolioFrmMain.Enabled = False
        Me.lstStkSharesGrpPortfolioFrmMain.FormatString = "N0"
        Me.lstStkSharesGrpPortfolioFrmMain.FormattingEnabled = True
        Me.lstStkSharesGrpPortfolioFrmMain.Location = New System.Drawing.Point(335, 40)
        Me.lstStkSharesGrpPortfolioFrmMain.Name = "lstStkSharesGrpPortfolioFrmMain"
        Me.lstStkSharesGrpPortfolioFrmMain.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.lstStkSharesGrpPortfolioFrmMain.Size = New System.Drawing.Size(76, 95)
        Me.lstStkSharesGrpPortfolioFrmMain.TabIndex = 5
        Me.lstStkSharesGrpPortfolioFrmMain.TabStop = False
        Me.ToolTip1.SetToolTip(Me.lstStkSharesGrpPortfolioFrmMain, "Number of shares in portfolio")
        '
        'lstStkNameGrpPortfolioFrmMain
        '
        Me.lstStkNameGrpPortfolioFrmMain.BackColor = System.Drawing.SystemColors.Control
        Me.lstStkNameGrpPortfolioFrmMain.Enabled = False
        Me.lstStkNameGrpPortfolioFrmMain.FormattingEnabled = True
        Me.lstStkNameGrpPortfolioFrmMain.Location = New System.Drawing.Point(148, 40)
        Me.lstStkNameGrpPortfolioFrmMain.Name = "lstStkNameGrpPortfolioFrmMain"
        Me.lstStkNameGrpPortfolioFrmMain.Size = New System.Drawing.Size(181, 95)
        Me.lstStkNameGrpPortfolioFrmMain.TabIndex = 3
        Me.lstStkNameGrpPortfolioFrmMain.TabStop = False
        Me.ToolTip1.SetToolTip(Me.lstStkNameGrpPortfolioFrmMain, "Stock name")
        '
        'lstStkSymGrpPortfolioFrmMain
        '
        Me.lstStkSymGrpPortfolioFrmMain.FormattingEnabled = True
        Me.lstStkSymGrpPortfolioFrmMain.Location = New System.Drawing.Point(22, 40)
        Me.lstStkSymGrpPortfolioFrmMain.Name = "lstStkSymGrpPortfolioFrmMain"
        Me.lstStkSymGrpPortfolioFrmMain.Size = New System.Drawing.Size(120, 95)
        Me.lstStkSymGrpPortfolioFrmMain.TabIndex = 1
        Me.ToolTip1.SetToolTip(Me.lstStkSymGrpPortfolioFrmMain, "Ticker symbol")
        '
        'lstStkPriceGrpPortfolioFrmMain
        '
        Me.lstStkPriceGrpPortfolioFrmMain.BackColor = System.Drawing.SystemColors.Control
        Me.lstStkPriceGrpPortfolioFrmMain.Enabled = False
        Me.lstStkPriceGrpPortfolioFrmMain.FormatString = "C2"
        Me.lstStkPriceGrpPortfolioFrmMain.FormattingEnabled = True
        Me.lstStkPriceGrpPortfolioFrmMain.Location = New System.Drawing.Point(417, 40)
        Me.lstStkPriceGrpPortfolioFrmMain.Name = "lstStkPriceGrpPortfolioFrmMain"
        Me.lstStkPriceGrpPortfolioFrmMain.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.lstStkPriceGrpPortfolioFrmMain.Size = New System.Drawing.Size(76, 95)
        Me.lstStkPriceGrpPortfolioFrmMain.TabIndex = 7
        Me.lstStkPriceGrpPortfolioFrmMain.TabStop = False
        Me.ToolTip1.SetToolTip(Me.lstStkPriceGrpPortfolioFrmMain, "Price per share")
        '
        'lstStkValueGrpPortfolioFrmMain
        '
        Me.lstStkValueGrpPortfolioFrmMain.BackColor = System.Drawing.SystemColors.Control
        Me.lstStkValueGrpPortfolioFrmMain.Enabled = False
        Me.lstStkValueGrpPortfolioFrmMain.FormatString = "N2"
        Me.lstStkValueGrpPortfolioFrmMain.FormattingEnabled = True
        Me.lstStkValueGrpPortfolioFrmMain.Location = New System.Drawing.Point(499, 40)
        Me.lstStkValueGrpPortfolioFrmMain.Name = "lstStkValueGrpPortfolioFrmMain"
        Me.lstStkValueGrpPortfolioFrmMain.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.lstStkValueGrpPortfolioFrmMain.Size = New System.Drawing.Size(76, 95)
        Me.lstStkValueGrpPortfolioFrmMain.TabIndex = 9
        Me.lstStkValueGrpPortfolioFrmMain.TabStop = False
        Me.ToolTip1.SetToolTip(Me.lstStkValueGrpPortfolioFrmMain, "Total value of stock held in portfolio")
        '
        'grpTransLogFrmMain
        '
        Me.grpTransLogFrmMain.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.grpTransLogFrmMain.Controls.Add(Me.txtTransLogFrmMain)
        Me.grpTransLogFrmMain.Location = New System.Drawing.Point(39, 471)
        Me.grpTransLogFrmMain.Name = "grpTransLogFrmMain"
        Me.grpTransLogFrmMain.Size = New System.Drawing.Size(917, 187)
        Me.grpTransLogFrmMain.TabIndex = 5
        Me.grpTransLogFrmMain.TabStop = False
        Me.grpTransLogFrmMain.Text = "Transaction Log"
        Me.ToolTip1.SetToolTip(Me.grpTransLogFrmMain, "System transaction log")
        '
        'txtTransLogFrmMain
        '
        Me.txtTransLogFrmMain.Location = New System.Drawing.Point(26, 19)
        Me.txtTransLogFrmMain.Multiline = True
        Me.txtTransLogFrmMain.Name = "txtTransLogFrmMain"
        Me.txtTransLogFrmMain.ReadOnly = True
        Me.txtTransLogFrmMain.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtTransLogFrmMain.Size = New System.Drawing.Size(864, 148)
        Me.txtTransLogFrmMain.TabIndex = 0
        Me.txtTransLogFrmMain.TabStop = False
        '
        'btnExitFrmMain
        '
        Me.btnExitFrmMain.Location = New System.Drawing.Point(462, 667)
        Me.btnExitFrmMain.Name = "btnExitFrmMain"
        Me.btnExitFrmMain.Size = New System.Drawing.Size(75, 23)
        Me.btnExitFrmMain.TabIndex = 6
        Me.btnExitFrmMain.Text = "E&xit"
        Me.ToolTip1.SetToolTip(Me.btnExitFrmMain, "Click to close and exit the system")
        Me.btnExitFrmMain.UseVisualStyleBackColor = True
        '
        'txtCntGrpPortfolioFrmMain
        '
        Me.txtCntGrpPortfolioFrmMain.Location = New System.Drawing.Point(66, 145)
        Me.txtCntGrpPortfolioFrmMain.Name = "txtCntGrpPortfolioFrmMain"
        Me.txtCntGrpPortfolioFrmMain.ReadOnly = True
        Me.txtCntGrpPortfolioFrmMain.Size = New System.Drawing.Size(75, 20)
        Me.txtCntGrpPortfolioFrmMain.TabIndex = 11
        Me.txtCntGrpPortfolioFrmMain.TabStop = False
        Me.txtCntGrpPortfolioFrmMain.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.ToolTip1.SetToolTip(Me.txtCntGrpPortfolioFrmMain, "Number of stocks in the portfolio")
        '
        'btnRunTestData
        '
        Me.btnRunTestData.Location = New System.Drawing.Point(845, 79)
        Me.btnRunTestData.Name = "btnRunTestData"
        Me.btnRunTestData.Size = New System.Drawing.Size(111, 23)
        Me.btnRunTestData.TabIndex = 7
        Me.btnRunTestData.Text = "&Run Test-Data"
        Me.ToolTip1.SetToolTip(Me.btnRunTestData, "Click to run test data simulation")
        Me.btnRunTestData.UseVisualStyleBackColor = True
        '
        'grpStkMktFrmMain
        '
        Me.grpStkMktFrmMain.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.grpStkMktFrmMain.Controls.Add(Me.btnDispStkMktGrpStkMktFrmMain)
        Me.grpStkMktFrmMain.Controls.Add(Me.txtCntGrpStkMktFrmMain)
        Me.grpStkMktFrmMain.Controls.Add(Me.Label12)
        Me.grpStkMktFrmMain.Controls.Add(Me.Label11)
        Me.grpStkMktFrmMain.Controls.Add(Me.Label10)
        Me.grpStkMktFrmMain.Controls.Add(Me.Label9)
        Me.grpStkMktFrmMain.Controls.Add(Me.lstStkPriceGrpStkMktFrmMain)
        Me.grpStkMktFrmMain.Controls.Add(Me.lstStkNameGrpStkMktFrmMain)
        Me.grpStkMktFrmMain.Controls.Add(Me.lstStkSymGrpStkMktFrmMain)
        Me.grpStkMktFrmMain.Location = New System.Drawing.Point(346, 79)
        Me.grpStkMktFrmMain.Name = "grpStkMktFrmMain"
        Me.grpStkMktFrmMain.Size = New System.Drawing.Size(428, 176)
        Me.grpStkMktFrmMain.TabIndex = 3
        Me.grpStkMktFrmMain.TabStop = False
        Me.grpStkMktFrmMain.Text = "Stock Market"
        '
        'btnDispStkMktGrpStkMktFrmMain
        '
        Me.btnDispStkMktGrpStkMktFrmMain.Location = New System.Drawing.Point(169, 140)
        Me.btnDispStkMktGrpStkMktFrmMain.Name = "btnDispStkMktGrpStkMktFrmMain"
        Me.btnDispStkMktGrpStkMktFrmMain.Size = New System.Drawing.Size(128, 23)
        Me.btnDispStkMktGrpStkMktFrmMain.TabIndex = 8
        Me.btnDispStkMktGrpStkMktFrmMain.Text = "Display Stock &Market"
        Me.btnDispStkMktGrpStkMktFrmMain.UseVisualStyleBackColor = True
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(22, 145)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(38, 13)
        Me.Label12.TabIndex = 6
        Me.Label12.Text = "Count:"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(380, 18)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(31, 13)
        Me.Label11.TabIndex = 4
        Me.Label11.Text = "Price"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(148, 18)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(66, 13)
        Me.Label10.TabIndex = 2
        Me.Label10.Text = "Stock Name"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(22, 19)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(74, 13)
        Me.Label9.TabIndex = 0
        Me.Label9.Text = "Ticker Symbol"
        '
        'grpPortfolioFrmMain
        '
        Me.grpPortfolioFrmMain.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.grpPortfolioFrmMain.Controls.Add(Me.txtValueGrpPortfolioFrmMain)
        Me.grpPortfolioFrmMain.Controls.Add(Me.Label19)
        Me.grpPortfolioFrmMain.Controls.Add(Me.txtCntGrpPortfolioFrmMain)
        Me.grpPortfolioFrmMain.Controls.Add(Me.Label18)
        Me.grpPortfolioFrmMain.Controls.Add(Me.Label17)
        Me.grpPortfolioFrmMain.Controls.Add(Me.lstStkValueGrpPortfolioFrmMain)
        Me.grpPortfolioFrmMain.Controls.Add(Me.Label16)
        Me.grpPortfolioFrmMain.Controls.Add(Me.lstStkPriceGrpPortfolioFrmMain)
        Me.grpPortfolioFrmMain.Controls.Add(Me.btnDispPortGrpPortfolioFrmMain)
        Me.grpPortfolioFrmMain.Controls.Add(Me.Label13)
        Me.grpPortfolioFrmMain.Controls.Add(Me.Label14)
        Me.grpPortfolioFrmMain.Controls.Add(Me.Label15)
        Me.grpPortfolioFrmMain.Controls.Add(Me.lstStkSharesGrpPortfolioFrmMain)
        Me.grpPortfolioFrmMain.Controls.Add(Me.lstStkNameGrpPortfolioFrmMain)
        Me.grpPortfolioFrmMain.Controls.Add(Me.lstStkSymGrpPortfolioFrmMain)
        Me.grpPortfolioFrmMain.Location = New System.Drawing.Point(346, 265)
        Me.grpPortfolioFrmMain.Name = "grpPortfolioFrmMain"
        Me.grpPortfolioFrmMain.Size = New System.Drawing.Size(610, 186)
        Me.grpPortfolioFrmMain.TabIndex = 4
        Me.grpPortfolioFrmMain.TabStop = False
        Me.grpPortfolioFrmMain.Text = "Portfolio"
        '
        'txtValueGrpPortfolioFrmMain
        '
        Me.txtValueGrpPortfolioFrmMain.Location = New System.Drawing.Point(475, 145)
        Me.txtValueGrpPortfolioFrmMain.Name = "txtValueGrpPortfolioFrmMain"
        Me.txtValueGrpPortfolioFrmMain.ReadOnly = True
        Me.txtValueGrpPortfolioFrmMain.Size = New System.Drawing.Size(100, 20)
        Me.txtValueGrpPortfolioFrmMain.TabIndex = 14
        Me.txtValueGrpPortfolioFrmMain.TabStop = False
        Me.txtValueGrpPortfolioFrmMain.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(432, 148)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(37, 13)
        Me.Label19.TabIndex = 13
        Me.Label19.Text = "Value:"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(22, 148)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(38, 13)
        Me.Label18.TabIndex = 10
        Me.Label18.Text = "Count:"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(541, 22)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(34, 13)
        Me.Label17.TabIndex = 8
        Me.Label17.Text = "Value"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(462, 23)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(31, 13)
        Me.Label16.TabIndex = 6
        Me.Label16.Text = "Price"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(371, 22)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(40, 13)
        Me.Label13.TabIndex = 4
        Me.Label13.Text = "Shares"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(148, 22)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(66, 13)
        Me.Label14.TabIndex = 2
        Me.Label14.Text = "Stock Name"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(19, 22)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(74, 13)
        Me.Label15.TabIndex = 0
        Me.Label15.Text = "Ticker Symbol"
        '
        'FrmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.AntiqueWhite
        Me.ClientSize = New System.Drawing.Size(1009, 702)
        Me.Controls.Add(Me.btnRunTestData)
        Me.Controls.Add(Me.btnExitFrmMain)
        Me.Controls.Add(Me.grpTransLogFrmMain)
        Me.Controls.Add(Me.grpPortfolioFrmMain)
        Me.Controls.Add(Me.grpStkMktFrmMain)
        Me.Controls.Add(Me.grpPtfItemFrmMain)
        Me.Controls.Add(Me.grpStockFrmMain)
        Me.Controls.Add(Me.Label1)
        Me.Name = "FrmMain"
        Me.Text = "Ch0502 - Stock Market Portfolio Managment"
        Me.ToolTip1.SetToolTip(Me, "Stock Market Portfolio Management")
        Me.grpStockFrmMain.ResumeLayout(False)
        Me.grpStockFrmMain.PerformLayout()
        Me.grpPtfItemFrmMain.ResumeLayout(False)
        Me.grpPtfItemFrmMain.PerformLayout()
        Me.grpTransLogFrmMain.ResumeLayout(False)
        Me.grpTransLogFrmMain.PerformLayout()
        Me.grpStkMktFrmMain.ResumeLayout(False)
        Me.grpStkMktFrmMain.PerformLayout()
        Me.grpPortfolioFrmMain.ResumeLayout(False)
        Me.grpPortfolioFrmMain.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents grpStockFrmMain As System.Windows.Forms.GroupBox
    Friend WithEvents btnOfferGrpStockFrmMain As System.Windows.Forms.Button
    Friend WithEvents txtStkPriceGrpStockFrmMain As System.Windows.Forms.TextBox
    Friend WithEvents txtStkNameGrpStockFrmMain As System.Windows.Forms.TextBox
    Friend WithEvents txtStkSymGrpStockFrmMain As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents grpPtfItemFrmMain As System.Windows.Forms.GroupBox
    Friend WithEvents txtSharesGrpPtfItemFrmMain As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents btnBuyGrpPtfItemFrmMain As System.Windows.Forms.Button
    Friend WithEvents txtStkPriceGrpPtfItemFrmMain As System.Windows.Forms.TextBox
    Friend WithEvents txtStkNameGrpPtfItemFrmMain As System.Windows.Forms.TextBox
    Friend WithEvents txtStkSymGrpPtfItemFrmMain As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
    Friend WithEvents grpStkMktFrmMain As System.Windows.Forms.GroupBox
    Friend WithEvents grpPortfolioFrmMain As System.Windows.Forms.GroupBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents lstStkPriceGrpStkMktFrmMain As System.Windows.Forms.ListBox
    Friend WithEvents lstStkNameGrpStkMktFrmMain As System.Windows.Forms.ListBox
    Friend WithEvents lstStkSymGrpStkMktFrmMain As System.Windows.Forms.ListBox
    Friend WithEvents btnDispStkMktGrpStkMktFrmMain As System.Windows.Forms.Button
    Friend WithEvents txtCntGrpStkMktFrmMain As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents lstStkValueGrpPortfolioFrmMain As System.Windows.Forms.ListBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents lstStkPriceGrpPortfolioFrmMain As System.Windows.Forms.ListBox
    Friend WithEvents btnDispPortGrpPortfolioFrmMain As System.Windows.Forms.Button
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents lstStkSharesGrpPortfolioFrmMain As System.Windows.Forms.ListBox
    Friend WithEvents lstStkNameGrpPortfolioFrmMain As System.Windows.Forms.ListBox
    Friend WithEvents lstStkSymGrpPortfolioFrmMain As System.Windows.Forms.ListBox
    Friend WithEvents grpTransLogFrmMain As System.Windows.Forms.GroupBox
    Friend WithEvents txtTransLogFrmMain As System.Windows.Forms.TextBox
    Friend WithEvents btnExitFrmMain As System.Windows.Forms.Button
    Friend WithEvents txtValueGrpPortfolioFrmMain As System.Windows.Forms.TextBox
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents txtCntGrpPortfolioFrmMain As System.Windows.Forms.TextBox
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents btnRunTestData As System.Windows.Forms.Button

End Class
