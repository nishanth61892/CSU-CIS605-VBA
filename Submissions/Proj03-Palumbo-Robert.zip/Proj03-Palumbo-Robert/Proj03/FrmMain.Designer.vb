﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmMain))
        Me.mnuMainApplMenu = New System.Windows.Forms.MenuStrip()
        Me.mnuFileFrmMain = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuSaveFileFrmMain = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuImportFileFrmMain = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuExportFileFrmMain = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuExitFileFrmMain = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuEditFrmMain = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuCutEditFrmMain = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuCopyEditFrmMain = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuPasteEditFrmMain = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuPassbooksFrmMain = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuPurchasePassbooksFrmMain = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuFeaturePassbooksFrmMain = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuAddFeaturesPassbooksFrmMain = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuUpdateFeaturesPassbooksFrmMain = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuUseFeaturesPassbooksFrmMain = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuViewFrmMain = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuDashboardViewFrmMain = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuTransLogViewFrmMain = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuTestFrmMain = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuRunSysTestTestFrmMain = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuImportTestFrmMain = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuExportTestFrmMain = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuHelpFrmMain = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuAboutHelpFrmMain = New System.Windows.Forms.ToolStripMenuItem()
        Me.lblThemeParkMgmtSysFrmMain = New System.Windows.Forms.Label()
        Me.tabPassbkFeatTbcMainFrmMain = New System.Windows.Forms.TabPage()
        Me.tbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain = New System.Windows.Forms.TabControl()
        Me.tabAddFeatTbcPassbkFeatMainTbcMain = New System.Windows.Forms.TabPage()
        Me.grpAnon3 = New System.Windows.Forms.GroupBox()
        Me.txtPassBkFeatIdTabAddFeatTbcPassbkFeatMainTbcMain = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.txtPriceTabAddFeatTbcPassbkFeatMainTbcMain = New System.Windows.Forms.TextBox()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.txtQtyTabAddFeatTbcPassbkFeatMainTbcMain = New System.Windows.Forms.TextBox()
        Me.grpFeatTabAddFeatureTbcPassbookFeatureMainTbcMain = New System.Windows.Forms.GroupBox()
        Me.cboFeatIdTabAddFeatTbcPassbkFeatMainTbcMain = New System.Windows.Forms.ComboBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.txtFeatToStringTabAddFeatTbcPassbkFeatMainTbcMain = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.grpPassbkTabAddFeatureTbcPassbookFeatureMainTbcMain = New System.Windows.Forms.GroupBox()
        Me.cboPassbkIdTabAddFeatTbcPassbkFeatMainTbcMain = New System.Windows.Forms.ComboBox()
        Me.txtVisToStringTabAddFeatTbcPassbkFeatMainTbcMain = New System.Windows.Forms.TextBox()
        Me.txtCustToStringTabAddFeatTbcPassbkFeatMainTbcMain = New System.Windows.Forms.TextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.btnResetTabAddFeatTbcPassbkFeatMainTbcMain = New System.Windows.Forms.Button()
        Me.btnSubmitTabAddFeatTbcPassbkFeatMainTbcMain = New System.Windows.Forms.Button()
        Me.tabUpdtFeatTbcPassbkFeatMainTbcMain = New System.Windows.Forms.TabPage()
        Me.btnResetTabUpdtFeatTbcPassbkFeatMainTbcMain = New System.Windows.Forms.Button()
        Me.btnSubmitTabUpdtFeatTbcPassbkFeatMainTbcMain = New System.Windows.Forms.Button()
        Me.grpAnon4 = New System.Windows.Forms.GroupBox()
        Me.txtPriceTabUpdtFeatTbcPassbkFeatMainTbcMain = New System.Windows.Forms.TextBox()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.txtNewQtyTabUpdtFeatTbcPassbkFeatMainTbcMain = New System.Windows.Forms.TextBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.txtRemQtyTabUpdtFeatTbcPassbkFeatMainTbcMain = New System.Windows.Forms.TextBox()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.grpPassbkTabUpdtFeatTbcPassbkFeatMainTbcMain = New System.Windows.Forms.GroupBox()
        Me.cboFeatIdTabUpdtFeatTbcPassbkFeatMainTbcMain = New System.Windows.Forms.ComboBox()
        Me.txtPrevUsedToStringTabUpdtFeatTbcPassbkFeatMainTbcMain = New System.Windows.Forms.TextBox()
        Me.txtVisToStringTabUpdtFeatTbcPassbkFeatMainTbcMain = New System.Windows.Forms.TextBox()
        Me.txtFeatToStringTabUpdtFeatTbcPassbkFeatMainTbcMain = New System.Windows.Forms.TextBox()
        Me.Label47 = New System.Windows.Forms.Label()
        Me.txtCustToStringTabUpdtFeatTbcPassbkFeatMainTbcMain = New System.Windows.Forms.TextBox()
        Me.Label48 = New System.Windows.Forms.Label()
        Me.Label49 = New System.Windows.Forms.Label()
        Me.Label50 = New System.Windows.Forms.Label()
        Me.Label51 = New System.Windows.Forms.Label()
        Me.tabPostFeatTbcPassbkFeatMainTbcMain = New System.Windows.Forms.TabPage()
        Me.grpAnon1 = New System.Windows.Forms.GroupBox()
        Me.txtQtyUsedTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain = New System.Windows.Forms.TextBox()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.txtRemQuantTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain = New System.Windows.Forms.TextBox()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.txtLocTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain = New System.Windows.Forms.TextBox()
        Me.btnResetTabPostFeatTbcPassbkFeatMainTbcMain = New System.Windows.Forms.Button()
        Me.grpPassbkTabPostTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain = New System.Windows.Forms.GroupBox()
        Me.cboPassbkFeatIdTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain = New System.Windows.Forms.ComboBox()
        Me.txtPrevUsedTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain = New System.Windows.Forms.TextBox()
        Me.txtVisToStringTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain = New System.Windows.Forms.TextBox()
        Me.txtFeatToStringTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.txtCustToStringTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.btnSubmitTabPostFeatTbcPassbkFeatMainTbcMain = New System.Windows.Forms.Button()
        Me.tabPassbkTbcMainFrmMain = New System.Windows.Forms.TabPage()
        Me.grpAddPassbkTabPassbkTbcMainFrmMain = New System.Windows.Forms.GroupBox()
        Me.grpAnon2 = New System.Windows.Forms.GroupBox()
        Me.txtVisNameGrpAddPassbkTabPassbkTbcMainFrmMain = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txtVisDobGrpAddPassbkTabPassbkTbcMainFrmMain = New System.Windows.Forms.DateTimePicker()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtPassbkIdGrpAddPassbkTabPassbkTbcMainFrmMain = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.grpCustInfoGrpAddPassbkTabPassbkTbcMainFrmMain = New System.Windows.Forms.GroupBox()
        Me.cboCustIdGrpCustInfoGrpAddPassbkTabPassbkTbcMainFrmMain = New System.Windows.Forms.ComboBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtToStringGrpCustInfoGrpAddPassbkTabPassbkTbcMainFrmMain = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.btnResetGrpAddPassbkTabPassbkTbcMainFrmMain = New System.Windows.Forms.Button()
        Me.btnSubmitGrpAddPassbkTabPassbkTbcMainFrmMain = New System.Windows.Forms.Button()
        Me.tabCustTbcMainFrmMain = New System.Windows.Forms.TabPage()
        Me.grpAddCustTabCustTbcMainFrmMain = New System.Windows.Forms.GroupBox()
        Me.grpAnon6 = New System.Windows.Forms.GroupBox()
        Me.txtCustNameGrpAddCustTabCustTbcMainFrmMain = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtCustIdGrpAddCustTabCustTbcMainFrmMain = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.btnResetGrpCustInfoTabCustTbcMainFrmMain = New System.Windows.Forms.Button()
        Me.btnSubmitGrpCustInfoTabCustTbcMainFrmMain = New System.Windows.Forms.Button()
        Me.tbcMainFrmMain = New System.Windows.Forms.TabControl()
        Me.tabDashTbcMainFrmMain = New System.Windows.Forms.TabPage()
        Me.lstUsedFeatCntTabDashboardTbcMain = New System.Windows.Forms.TextBox()
        Me.txtPassbkFeatCntTabDashboardTbcMain = New System.Windows.Forms.TextBox()
        Me.txtPassbkCntTabDashboardTbcMain = New System.Windows.Forms.TextBox()
        Me.txtFeatCntTabDashboardTbcMain = New System.Windows.Forms.TextBox()
        Me.txtCustCntTabDashboardTbcMain = New System.Windows.Forms.TextBox()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.txtToStringTabDashboardTbcMain = New System.Windows.Forms.TextBox()
        Me.lstUsedFeatTabDashboardTbcMain = New System.Windows.Forms.ListBox()
        Me.lstPassbkFeatTabDashboardTbcMain = New System.Windows.Forms.ListBox()
        Me.lstPassbkTabDashboardTbcMain = New System.Windows.Forms.ListBox()
        Me.lstFeatTabDashboardTbcMain = New System.Windows.Forms.ListBox()
        Me.lstCustTabDashboardTbcMain = New System.Windows.Forms.ListBox()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.grpKpiTabDashboardTbcMain = New System.Windows.Forms.GroupBox()
        Me.tabFeatTbcMainFrmMain = New System.Windows.Forms.TabPage()
        Me.grpAddFeatTabFeatTbcMainFrmMain = New System.Windows.Forms.GroupBox()
        Me.grpAnon7 = New System.Windows.Forms.GroupBox()
        Me.txtPriceChildGrpAddFeatTabFeatTbcMainFrmMain = New System.Windows.Forms.TextBox()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.txtPriceAdultGrpAddFeatTabFeatTbcMainFrmMain = New System.Windows.Forms.TextBox()
        Me.txtUnifOfMeasGrpAddFeatTabFeatTbcMainFrmMain = New System.Windows.Forms.TextBox()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.txtFeatNameGrpAddFeatTabFeatTbcMainFrmMain = New System.Windows.Forms.TextBox()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.txtFeatIdAddFeatTabFeatTbcMainFrmMain = New System.Windows.Forms.TextBox()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.btnResetGrpAddFeatTabFeatTbcMainFrmMain = New System.Windows.Forms.Button()
        Me.btnSubmitGrpAddFeatTabFeatTbcMainFrmMain = New System.Windows.Forms.Button()
        Me.tabTransLogTbcMainFrmMain = New System.Windows.Forms.TabPage()
        Me.btnClearTabTransLogTbcMainFrmMain = New System.Windows.Forms.Button()
        Me.grpTransLogTabTransLogTbcMain = New System.Windows.Forms.GroupBox()
        Me.txtTransLogTabTransLogTbcMainFrmMain = New System.Windows.Forms.TextBox()
        Me.tabSysTestTbcMainFrmMain = New System.Windows.Forms.TabPage()
        Me.grpSysTestTabSysTestTbcMainFrmMain = New System.Windows.Forms.GroupBox()
        Me.chkUseTestParkGrpSysTestTabSysTestTbcMainFrmMain = New System.Windows.Forms.CheckBox()
        Me.grpAnon5 = New System.Windows.Forms.GroupBox()
        Me.btnWriteFileGrpSysTestTabSysTestTbcMainFrmMain = New System.Windows.Forms.Button()
        Me.chkAppendTabSysTestTbcMainFrmMain = New System.Windows.Forms.CheckBox()
        Me.btnReadFileTabSysTestTbcMainFrmMain = New System.Windows.Forms.Button()
        Me.btnProcTestDataGrpSysTestTabSysTestTbcMainFrmMain = New System.Windows.Forms.Button()
        Me.btnExitFrmMain = New System.Windows.Forms.Button()
        Me.tipTPMS = New System.Windows.Forms.ToolTip(Me.components)
        Me.btnAddGrpCustInfoTcbMain = New System.Windows.Forms.Button()
        Me.btnResetGrpCustInfoTcbMain = New System.Windows.Forms.Button()
        Me.ListBox2 = New System.Windows.Forms.ListBox()
        Me.ListBox1 = New System.Windows.Forms.ListBox()
        Me.NumericUpDown3 = New System.Windows.Forms.NumericUpDown()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.lblCustIdTabAddCustTbcCustomerMainTabCustomerTbcMain = New System.Windows.Forms.Label()
        Me.lblCustNameTabAddCustTbcCustomerMainTabCustomerTbcMain = New System.Windows.Forms.Label()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.mnuMainApplMenu.SuspendLayout()
        Me.tabPassbkFeatTbcMainFrmMain.SuspendLayout()
        Me.tbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain.SuspendLayout()
        Me.tabAddFeatTbcPassbkFeatMainTbcMain.SuspendLayout()
        Me.grpAnon3.SuspendLayout()
        Me.grpFeatTabAddFeatureTbcPassbookFeatureMainTbcMain.SuspendLayout()
        Me.grpPassbkTabAddFeatureTbcPassbookFeatureMainTbcMain.SuspendLayout()
        Me.tabUpdtFeatTbcPassbkFeatMainTbcMain.SuspendLayout()
        Me.grpAnon4.SuspendLayout()
        Me.grpPassbkTabUpdtFeatTbcPassbkFeatMainTbcMain.SuspendLayout()
        Me.tabPostFeatTbcPassbkFeatMainTbcMain.SuspendLayout()
        Me.grpAnon1.SuspendLayout()
        Me.grpPassbkTabPostTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain.SuspendLayout()
        Me.tabPassbkTbcMainFrmMain.SuspendLayout()
        Me.grpAddPassbkTabPassbkTbcMainFrmMain.SuspendLayout()
        Me.grpAnon2.SuspendLayout()
        Me.grpCustInfoGrpAddPassbkTabPassbkTbcMainFrmMain.SuspendLayout()
        Me.tabCustTbcMainFrmMain.SuspendLayout()
        Me.grpAddCustTabCustTbcMainFrmMain.SuspendLayout()
        Me.grpAnon6.SuspendLayout()
        Me.tbcMainFrmMain.SuspendLayout()
        Me.tabDashTbcMainFrmMain.SuspendLayout()
        Me.tabFeatTbcMainFrmMain.SuspendLayout()
        Me.grpAddFeatTabFeatTbcMainFrmMain.SuspendLayout()
        Me.grpAnon7.SuspendLayout()
        Me.tabTransLogTbcMainFrmMain.SuspendLayout()
        Me.grpTransLogTabTransLogTbcMain.SuspendLayout()
        Me.tabSysTestTbcMainFrmMain.SuspendLayout()
        Me.grpSysTestTabSysTestTbcMainFrmMain.SuspendLayout()
        Me.grpAnon5.SuspendLayout()
        CType(Me.NumericUpDown3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'mnuMainApplMenu
        '
        Me.mnuMainApplMenu.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.mnuMainApplMenu.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.mnuMainApplMenu.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuFileFrmMain, Me.mnuEditFrmMain, Me.mnuPassbooksFrmMain, Me.mnuViewFrmMain, Me.mnuTestFrmMain, Me.mnuHelpFrmMain})
        Me.mnuMainApplMenu.Location = New System.Drawing.Point(0, 0)
        Me.mnuMainApplMenu.Name = "mnuMainApplMenu"
        Me.mnuMainApplMenu.Padding = New System.Windows.Forms.Padding(8, 2, 0, 2)
        Me.mnuMainApplMenu.Size = New System.Drawing.Size(1012, 25)
        Me.mnuMainApplMenu.TabIndex = 0
        Me.mnuMainApplMenu.Text = "MenuStrip1"
        '
        'mnuFileFrmMain
        '
        Me.mnuFileFrmMain.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuSaveFileFrmMain, Me.mnuImportFileFrmMain, Me.mnuExportFileFrmMain, Me.mnuExitFileFrmMain})
        Me.mnuFileFrmMain.Name = "mnuFileFrmMain"
        Me.mnuFileFrmMain.Size = New System.Drawing.Size(40, 21)
        Me.mnuFileFrmMain.Text = "&File"
        Me.mnuFileFrmMain.ToolTipText = "Save Session"
        '
        'mnuSaveFileFrmMain
        '
        Me.mnuSaveFileFrmMain.Image = CType(resources.GetObject("mnuSaveFileFrmMain.Image"), System.Drawing.Image)
        Me.mnuSaveFileFrmMain.Name = "mnuSaveFileFrmMain"
        Me.mnuSaveFileFrmMain.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.S), System.Windows.Forms.Keys)
        Me.mnuSaveFileFrmMain.Size = New System.Drawing.Size(149, 22)
        Me.mnuSaveFileFrmMain.Text = "Save"
        Me.mnuSaveFileFrmMain.ToolTipText = "Save Session"
        '
        'mnuImportFileFrmMain
        '
        Me.mnuImportFileFrmMain.Name = "mnuImportFileFrmMain"
        Me.mnuImportFileFrmMain.Size = New System.Drawing.Size(149, 22)
        Me.mnuImportFileFrmMain.Text = "Import"
        Me.mnuImportFileFrmMain.ToolTipText = "Import Data"
        '
        'mnuExportFileFrmMain
        '
        Me.mnuExportFileFrmMain.Name = "mnuExportFileFrmMain"
        Me.mnuExportFileFrmMain.Size = New System.Drawing.Size(149, 22)
        Me.mnuExportFileFrmMain.Text = "Export"
        Me.mnuExportFileFrmMain.ToolTipText = "Export Data"
        '
        'mnuExitFileFrmMain
        '
        Me.mnuExitFileFrmMain.Name = "mnuExitFileFrmMain"
        Me.mnuExitFileFrmMain.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.X), System.Windows.Forms.Keys)
        Me.mnuExitFileFrmMain.Size = New System.Drawing.Size(149, 22)
        Me.mnuExitFileFrmMain.Text = "Exit"
        Me.mnuExitFileFrmMain.ToolTipText = "Exit the system"
        '
        'mnuEditFrmMain
        '
        Me.mnuEditFrmMain.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuCutEditFrmMain, Me.mnuCopyEditFrmMain, Me.mnuPasteEditFrmMain})
        Me.mnuEditFrmMain.Name = "mnuEditFrmMain"
        Me.mnuEditFrmMain.Size = New System.Drawing.Size(43, 21)
        Me.mnuEditFrmMain.Text = "&Edit"
        '
        'mnuCutEditFrmMain
        '
        Me.mnuCutEditFrmMain.Image = CType(resources.GetObject("mnuCutEditFrmMain.Image"), System.Drawing.Image)
        Me.mnuCutEditFrmMain.Name = "mnuCutEditFrmMain"
        Me.mnuCutEditFrmMain.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.X), System.Windows.Forms.Keys)
        Me.mnuCutEditFrmMain.Size = New System.Drawing.Size(155, 22)
        Me.mnuCutEditFrmMain.Text = "Cut"
        '
        'mnuCopyEditFrmMain
        '
        Me.mnuCopyEditFrmMain.Image = CType(resources.GetObject("mnuCopyEditFrmMain.Image"), System.Drawing.Image)
        Me.mnuCopyEditFrmMain.Name = "mnuCopyEditFrmMain"
        Me.mnuCopyEditFrmMain.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.C), System.Windows.Forms.Keys)
        Me.mnuCopyEditFrmMain.Size = New System.Drawing.Size(155, 22)
        Me.mnuCopyEditFrmMain.Text = "Copy"
        '
        'mnuPasteEditFrmMain
        '
        Me.mnuPasteEditFrmMain.Image = CType(resources.GetObject("mnuPasteEditFrmMain.Image"), System.Drawing.Image)
        Me.mnuPasteEditFrmMain.Name = "mnuPasteEditFrmMain"
        Me.mnuPasteEditFrmMain.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.V), System.Windows.Forms.Keys)
        Me.mnuPasteEditFrmMain.Size = New System.Drawing.Size(155, 22)
        Me.mnuPasteEditFrmMain.Text = "Paste"
        '
        'mnuPassbooksFrmMain
        '
        Me.mnuPassbooksFrmMain.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuPurchasePassbooksFrmMain, Me.mnuFeaturePassbooksFrmMain})
        Me.mnuPassbooksFrmMain.Name = "mnuPassbooksFrmMain"
        Me.mnuPassbooksFrmMain.Size = New System.Drawing.Size(84, 21)
        Me.mnuPassbooksFrmMain.Text = "&Passbooks"
        Me.mnuPassbooksFrmMain.ToolTipText = "Purchase Passbook & Features"
        '
        'mnuPurchasePassbooksFrmMain
        '
        Me.mnuPurchasePassbooksFrmMain.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right
        Me.mnuPurchasePassbooksFrmMain.Name = "mnuPurchasePassbooksFrmMain"
        Me.mnuPurchasePassbooksFrmMain.Size = New System.Drawing.Size(132, 22)
        Me.mnuPurchasePassbooksFrmMain.Text = "Add New"
        Me.mnuPurchasePassbooksFrmMain.ToolTipText = "Passbook and feature purchase options"
        '
        'mnuFeaturePassbooksFrmMain
        '
        Me.mnuFeaturePassbooksFrmMain.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuAddFeaturesPassbooksFrmMain, Me.mnuUpdateFeaturesPassbooksFrmMain, Me.mnuUseFeaturesPassbooksFrmMain})
        Me.mnuFeaturePassbooksFrmMain.Name = "mnuFeaturePassbooksFrmMain"
        Me.mnuFeaturePassbooksFrmMain.Size = New System.Drawing.Size(132, 22)
        Me.mnuFeaturePassbooksFrmMain.Text = "Features"
        Me.mnuFeaturePassbooksFrmMain.ToolTipText = "Add or update a passbook feature"
        '
        'mnuAddFeaturesPassbooksFrmMain
        '
        Me.mnuAddFeaturesPassbooksFrmMain.Name = "mnuAddFeaturesPassbooksFrmMain"
        Me.mnuAddFeaturesPassbooksFrmMain.Size = New System.Drawing.Size(131, 22)
        Me.mnuAddFeaturesPassbooksFrmMain.Text = "Purchase"
        Me.mnuAddFeaturesPassbooksFrmMain.ToolTipText = "Add a passbook feature"
        '
        'mnuUpdateFeaturesPassbooksFrmMain
        '
        Me.mnuUpdateFeaturesPassbooksFrmMain.Name = "mnuUpdateFeaturesPassbooksFrmMain"
        Me.mnuUpdateFeaturesPassbooksFrmMain.Size = New System.Drawing.Size(131, 22)
        Me.mnuUpdateFeaturesPassbooksFrmMain.Text = "Update"
        Me.mnuUpdateFeaturesPassbooksFrmMain.ToolTipText = "Update a passbook feature"
        '
        'mnuUseFeaturesPassbooksFrmMain
        '
        Me.mnuUseFeaturesPassbooksFrmMain.Name = "mnuUseFeaturesPassbooksFrmMain"
        Me.mnuUseFeaturesPassbooksFrmMain.Size = New System.Drawing.Size(131, 22)
        Me.mnuUseFeaturesPassbooksFrmMain.Text = "Post"
        '
        'mnuViewFrmMain
        '
        Me.mnuViewFrmMain.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuDashboardViewFrmMain, Me.mnuTransLogViewFrmMain})
        Me.mnuViewFrmMain.Name = "mnuViewFrmMain"
        Me.mnuViewFrmMain.Size = New System.Drawing.Size(48, 21)
        Me.mnuViewFrmMain.Text = "&View"
        '
        'mnuDashboardViewFrmMain
        '
        Me.mnuDashboardViewFrmMain.Name = "mnuDashboardViewFrmMain"
        Me.mnuDashboardViewFrmMain.Size = New System.Drawing.Size(172, 22)
        Me.mnuDashboardViewFrmMain.Text = "Dashboard"
        Me.mnuDashboardViewFrmMain.ToolTipText = "View the system dashboard (KPI)"
        '
        'mnuTransLogViewFrmMain
        '
        Me.mnuTransLogViewFrmMain.Name = "mnuTransLogViewFrmMain"
        Me.mnuTransLogViewFrmMain.Size = New System.Drawing.Size(172, 22)
        Me.mnuTransLogViewFrmMain.Text = "Transaction Log"
        Me.mnuTransLogViewFrmMain.ToolTipText = "View the system transaction log"
        '
        'mnuTestFrmMain
        '
        Me.mnuTestFrmMain.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuRunSysTestTestFrmMain, Me.mnuImportTestFrmMain, Me.mnuExportTestFrmMain})
        Me.mnuTestFrmMain.Name = "mnuTestFrmMain"
        Me.mnuTestFrmMain.Size = New System.Drawing.Size(45, 21)
        Me.mnuTestFrmMain.Text = "&Test"
        '
        'mnuRunSysTestTestFrmMain
        '
        Me.mnuRunSysTestTestFrmMain.Name = "mnuRunSysTestTestFrmMain"
        Me.mnuRunSysTestTestFrmMain.Size = New System.Drawing.Size(177, 22)
        Me.mnuRunSysTestTestFrmMain.Text = "Run System Test"
        '
        'mnuImportTestFrmMain
        '
        Me.mnuImportTestFrmMain.Name = "mnuImportTestFrmMain"
        Me.mnuImportTestFrmMain.Size = New System.Drawing.Size(177, 22)
        Me.mnuImportTestFrmMain.Text = "Import"
        Me.mnuImportTestFrmMain.ToolTipText = "Import test data for simulation"
        '
        'mnuExportTestFrmMain
        '
        Me.mnuExportTestFrmMain.Name = "mnuExportTestFrmMain"
        Me.mnuExportTestFrmMain.Size = New System.Drawing.Size(177, 22)
        Me.mnuExportTestFrmMain.Text = "Export "
        Me.mnuExportTestFrmMain.ToolTipText = "Export data for backup"
        '
        'mnuHelpFrmMain
        '
        Me.mnuHelpFrmMain.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuAboutHelpFrmMain})
        Me.mnuHelpFrmMain.Name = "mnuHelpFrmMain"
        Me.mnuHelpFrmMain.Size = New System.Drawing.Size(48, 21)
        Me.mnuHelpFrmMain.Text = "&Help"
        '
        'mnuAboutHelpFrmMain
        '
        Me.mnuAboutHelpFrmMain.AutoToolTip = True
        Me.mnuAboutHelpFrmMain.Name = "mnuAboutHelpFrmMain"
        Me.mnuAboutHelpFrmMain.Size = New System.Drawing.Size(279, 22)
        Me.mnuAboutHelpFrmMain.Text = "About Theme Park Mgmt System"
        '
        'lblThemeParkMgmtSysFrmMain
        '
        Me.lblThemeParkMgmtSysFrmMain.AutoSize = True
        Me.lblThemeParkMgmtSysFrmMain.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblThemeParkMgmtSysFrmMain.Font = New System.Drawing.Font("Modern No. 20", 27.75!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblThemeParkMgmtSysFrmMain.ForeColor = System.Drawing.Color.Maroon
        Me.lblThemeParkMgmtSysFrmMain.Location = New System.Drawing.Point(345, 49)
        Me.lblThemeParkMgmtSysFrmMain.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblThemeParkMgmtSysFrmMain.Name = "lblThemeParkMgmtSysFrmMain"
        Me.lblThemeParkMgmtSysFrmMain.Size = New System.Drawing.Size(74, 40)
        Me.lblThemeParkMgmtSysFrmMain.TabIndex = 1
        Me.lblThemeParkMgmtSysFrmMain.Tag = "CIS605 Theme Park"
        Me.lblThemeParkMgmtSysFrmMain.Text = "     "
        '
        'tabPassbkFeatTbcMainFrmMain
        '
        Me.tabPassbkFeatTbcMainFrmMain.BackColor = System.Drawing.Color.LightGray
        Me.tabPassbkFeatTbcMainFrmMain.Controls.Add(Me.tbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain)
        Me.tabPassbkFeatTbcMainFrmMain.Location = New System.Drawing.Point(4, 27)
        Me.tabPassbkFeatTbcMainFrmMain.Name = "tabPassbkFeatTbcMainFrmMain"
        Me.tabPassbkFeatTbcMainFrmMain.Padding = New System.Windows.Forms.Padding(3)
        Me.tabPassbkFeatTbcMainFrmMain.Size = New System.Drawing.Size(919, 468)
        Me.tabPassbkFeatTbcMainFrmMain.TabIndex = 3
        Me.tabPassbkFeatTbcMainFrmMain.Text = "Passbook Features"
        Me.tipTPMS.SetToolTip(Me.tabPassbkFeatTbcMainFrmMain, "Passbook feature  options")
        '
        'tbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain
        '
        Me.tbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain.Appearance = System.Windows.Forms.TabAppearance.Buttons
        Me.tbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain.Controls.Add(Me.tabAddFeatTbcPassbkFeatMainTbcMain)
        Me.tbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain.Controls.Add(Me.tabUpdtFeatTbcPassbkFeatMainTbcMain)
        Me.tbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain.Controls.Add(Me.tabPostFeatTbcPassbkFeatMainTbcMain)
        Me.tbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain.Location = New System.Drawing.Point(20, 14)
        Me.tbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain.Name = "tbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain"
        Me.tbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain.SelectedIndex = 0
        Me.tbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain.Size = New System.Drawing.Size(879, 447)
        Me.tbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain.TabIndex = 0
        Me.tipTPMS.SetToolTip(Me.tbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain, "Update an existing passbook feature")
        '
        'tabAddFeatTbcPassbkFeatMainTbcMain
        '
        Me.tabAddFeatTbcPassbkFeatMainTbcMain.AllowDrop = True
        Me.tabAddFeatTbcPassbkFeatMainTbcMain.BackColor = System.Drawing.Color.LightGray
        Me.tabAddFeatTbcPassbkFeatMainTbcMain.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.tabAddFeatTbcPassbkFeatMainTbcMain.Controls.Add(Me.grpAnon3)
        Me.tabAddFeatTbcPassbkFeatMainTbcMain.Controls.Add(Me.grpFeatTabAddFeatureTbcPassbookFeatureMainTbcMain)
        Me.tabAddFeatTbcPassbkFeatMainTbcMain.Controls.Add(Me.grpPassbkTabAddFeatureTbcPassbookFeatureMainTbcMain)
        Me.tabAddFeatTbcPassbkFeatMainTbcMain.Controls.Add(Me.btnResetTabAddFeatTbcPassbkFeatMainTbcMain)
        Me.tabAddFeatTbcPassbkFeatMainTbcMain.Controls.Add(Me.btnSubmitTabAddFeatTbcPassbkFeatMainTbcMain)
        Me.tabAddFeatTbcPassbkFeatMainTbcMain.Location = New System.Drawing.Point(4, 27)
        Me.tabAddFeatTbcPassbkFeatMainTbcMain.Name = "tabAddFeatTbcPassbkFeatMainTbcMain"
        Me.tabAddFeatTbcPassbkFeatMainTbcMain.Padding = New System.Windows.Forms.Padding(3)
        Me.tabAddFeatTbcPassbkFeatMainTbcMain.Size = New System.Drawing.Size(871, 416)
        Me.tabAddFeatTbcPassbkFeatMainTbcMain.TabIndex = 0
        Me.tabAddFeatTbcPassbkFeatMainTbcMain.Text = "Purchase "
        Me.tipTPMS.SetToolTip(Me.tabAddFeatTbcPassbkFeatMainTbcMain, "Purchase a feature for the specified passbook")
        '
        'grpAnon3
        '
        Me.grpAnon3.BackColor = System.Drawing.SystemColors.Control
        Me.grpAnon3.Controls.Add(Me.txtPassBkFeatIdTabAddFeatTbcPassbkFeatMainTbcMain)
        Me.grpAnon3.Controls.Add(Me.Label9)
        Me.grpAnon3.Controls.Add(Me.txtPriceTabAddFeatTbcPassbkFeatMainTbcMain)
        Me.grpAnon3.Controls.Add(Me.Label46)
        Me.grpAnon3.Controls.Add(Me.Label25)
        Me.grpAnon3.Controls.Add(Me.txtQtyTabAddFeatTbcPassbkFeatMainTbcMain)
        Me.grpAnon3.Location = New System.Drawing.Point(200, 254)
        Me.grpAnon3.Name = "grpAnon3"
        Me.grpAnon3.Size = New System.Drawing.Size(466, 90)
        Me.grpAnon3.TabIndex = 2
        Me.grpAnon3.TabStop = False
        '
        'txtPassBkFeatIdTabAddFeatTbcPassbkFeatMainTbcMain
        '
        Me.txtPassBkFeatIdTabAddFeatTbcPassbkFeatMainTbcMain.Location = New System.Drawing.Point(103, 29)
        Me.txtPassBkFeatIdTabAddFeatTbcPassbkFeatMainTbcMain.Name = "txtPassBkFeatIdTabAddFeatTbcPassbkFeatMainTbcMain"
        Me.txtPassBkFeatIdTabAddFeatTbcPassbkFeatMainTbcMain.Size = New System.Drawing.Size(111, 21)
        Me.txtPassBkFeatIdTabAddFeatTbcPassbkFeatMainTbcMain.TabIndex = 1
        Me.tipTPMS.SetToolTip(Me.txtPassBkFeatIdTabAddFeatTbcPassbkFeatMainTbcMain, "Enter a unqiue feature identifier for this Passbook Feature")
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(24, 19)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(67, 30)
        Me.Label9.TabIndex = 0
        Me.Label9.Text = "Passbook" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Feature ID:" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'txtPriceTabAddFeatTbcPassbkFeatMainTbcMain
        '
        Me.txtPriceTabAddFeatTbcPassbkFeatMainTbcMain.BackColor = System.Drawing.SystemColors.ControlLight
        Me.txtPriceTabAddFeatTbcPassbkFeatMainTbcMain.Location = New System.Drawing.Point(338, 29)
        Me.txtPriceTabAddFeatTbcPassbkFeatMainTbcMain.Name = "txtPriceTabAddFeatTbcPassbkFeatMainTbcMain"
        Me.txtPriceTabAddFeatTbcPassbkFeatMainTbcMain.ReadOnly = True
        Me.txtPriceTabAddFeatTbcPassbkFeatMainTbcMain.Size = New System.Drawing.Size(100, 21)
        Me.txtPriceTabAddFeatTbcPassbkFeatMainTbcMain.TabIndex = 5
        Me.txtPriceTabAddFeatTbcPassbkFeatMainTbcMain.TabStop = False
        Me.tipTPMS.SetToolTip(Me.txtPriceTabAddFeatTbcPassbkFeatMainTbcMain, "Total price to purchase this passbook feature")
        '
        'Label46
        '
        Me.Label46.AutoSize = True
        Me.Label46.Location = New System.Drawing.Point(256, 32)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(68, 15)
        Me.Label46.TabIndex = 4
        Me.Label46.Text = "Total Price:"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(38, 60)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(54, 15)
        Me.Label25.TabIndex = 2
        Me.Label25.Text = "Quantity:"
        '
        'txtQtyTabAddFeatTbcPassbkFeatMainTbcMain
        '
        Me.txtQtyTabAddFeatTbcPassbkFeatMainTbcMain.Location = New System.Drawing.Point(103, 57)
        Me.txtQtyTabAddFeatTbcPassbkFeatMainTbcMain.Name = "txtQtyTabAddFeatTbcPassbkFeatMainTbcMain"
        Me.txtQtyTabAddFeatTbcPassbkFeatMainTbcMain.Size = New System.Drawing.Size(54, 21)
        Me.txtQtyTabAddFeatTbcPassbkFeatMainTbcMain.TabIndex = 3
        Me.tipTPMS.SetToolTip(Me.txtQtyTabAddFeatTbcPassbkFeatMainTbcMain, "Enter the quantity of this feature to purchase")
        '
        'grpFeatTabAddFeatureTbcPassbookFeatureMainTbcMain
        '
        Me.grpFeatTabAddFeatureTbcPassbookFeatureMainTbcMain.BackColor = System.Drawing.SystemColors.Control
        Me.grpFeatTabAddFeatureTbcPassbookFeatureMainTbcMain.Controls.Add(Me.cboFeatIdTabAddFeatTbcPassbkFeatMainTbcMain)
        Me.grpFeatTabAddFeatureTbcPassbookFeatureMainTbcMain.Controls.Add(Me.Label14)
        Me.grpFeatTabAddFeatureTbcPassbookFeatureMainTbcMain.Controls.Add(Me.txtFeatToStringTabAddFeatTbcPassbkFeatMainTbcMain)
        Me.grpFeatTabAddFeatureTbcPassbookFeatureMainTbcMain.Controls.Add(Me.Label15)
        Me.grpFeatTabAddFeatureTbcPassbookFeatureMainTbcMain.Location = New System.Drawing.Point(130, 160)
        Me.grpFeatTabAddFeatureTbcPassbookFeatureMainTbcMain.Name = "grpFeatTabAddFeatureTbcPassbookFeatureMainTbcMain"
        Me.grpFeatTabAddFeatureTbcPassbookFeatureMainTbcMain.Size = New System.Drawing.Size(606, 88)
        Me.grpFeatTabAddFeatureTbcPassbookFeatureMainTbcMain.TabIndex = 1
        Me.grpFeatTabAddFeatureTbcPassbookFeatureMainTbcMain.TabStop = False
        Me.grpFeatTabAddFeatureTbcPassbookFeatureMainTbcMain.Text = "Feature Selection"
        '
        'cboFeatIdTabAddFeatTbcPassbkFeatMainTbcMain
        '
        Me.cboFeatIdTabAddFeatTbcPassbkFeatMainTbcMain.FormattingEnabled = True
        Me.cboFeatIdTabAddFeatTbcPassbkFeatMainTbcMain.Location = New System.Drawing.Point(109, 23)
        Me.cboFeatIdTabAddFeatTbcPassbkFeatMainTbcMain.Name = "cboFeatIdTabAddFeatTbcPassbkFeatMainTbcMain"
        Me.cboFeatIdTabAddFeatTbcPassbkFeatMainTbcMain.Size = New System.Drawing.Size(136, 23)
        Me.cboFeatIdTabAddFeatTbcPassbkFeatMainTbcMain.TabIndex = 4
        Me.tipTPMS.SetToolTip(Me.cboFeatIdTabAddFeatTbcPassbkFeatMainTbcMain, "Select a Feature from the list")
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(31, 26)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(67, 15)
        Me.Label14.TabIndex = 0
        Me.Label14.Text = "Feature ID:"
        '
        'txtFeatToStringTabAddFeatTbcPassbkFeatMainTbcMain
        '
        Me.txtFeatToStringTabAddFeatTbcPassbkFeatMainTbcMain.BackColor = System.Drawing.SystemColors.ControlLight
        Me.txtFeatToStringTabAddFeatTbcPassbkFeatMainTbcMain.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtFeatToStringTabAddFeatTbcPassbkFeatMainTbcMain.Location = New System.Drawing.Point(278, 37)
        Me.txtFeatToStringTabAddFeatTbcPassbkFeatMainTbcMain.Multiline = True
        Me.txtFeatToStringTabAddFeatTbcPassbkFeatMainTbcMain.Name = "txtFeatToStringTabAddFeatTbcPassbkFeatMainTbcMain"
        Me.txtFeatToStringTabAddFeatTbcPassbkFeatMainTbcMain.ReadOnly = True
        Me.txtFeatToStringTabAddFeatTbcPassbkFeatMainTbcMain.Size = New System.Drawing.Size(298, 38)
        Me.txtFeatToStringTabAddFeatTbcPassbkFeatMainTbcMain.TabIndex = 3
        Me.txtFeatToStringTabAddFeatTbcPassbkFeatMainTbcMain.TabStop = False
        Me.tipTPMS.SetToolTip(Me.txtFeatToStringTabAddFeatTbcPassbkFeatMainTbcMain, "Displays selected passbook feature information")
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(275, 17)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(163, 15)
        Me.Label15.TabIndex = 2
        Me.Label15.Text = "Feature ToString Information"
        '
        'grpPassbkTabAddFeatureTbcPassbookFeatureMainTbcMain
        '
        Me.grpPassbkTabAddFeatureTbcPassbookFeatureMainTbcMain.BackColor = System.Drawing.SystemColors.Control
        Me.grpPassbkTabAddFeatureTbcPassbookFeatureMainTbcMain.Controls.Add(Me.cboPassbkIdTabAddFeatTbcPassbkFeatMainTbcMain)
        Me.grpPassbkTabAddFeatureTbcPassbookFeatureMainTbcMain.Controls.Add(Me.txtVisToStringTabAddFeatTbcPassbkFeatMainTbcMain)
        Me.grpPassbkTabAddFeatureTbcPassbookFeatureMainTbcMain.Controls.Add(Me.txtCustToStringTabAddFeatTbcPassbkFeatMainTbcMain)
        Me.grpPassbkTabAddFeatureTbcPassbookFeatureMainTbcMain.Controls.Add(Me.Label16)
        Me.grpPassbkTabAddFeatureTbcPassbookFeatureMainTbcMain.Controls.Add(Me.Label17)
        Me.grpPassbkTabAddFeatureTbcPassbookFeatureMainTbcMain.Controls.Add(Me.Label18)
        Me.grpPassbkTabAddFeatureTbcPassbookFeatureMainTbcMain.Location = New System.Drawing.Point(130, 6)
        Me.grpPassbkTabAddFeatureTbcPassbookFeatureMainTbcMain.Name = "grpPassbkTabAddFeatureTbcPassbookFeatureMainTbcMain"
        Me.grpPassbkTabAddFeatureTbcPassbookFeatureMainTbcMain.Size = New System.Drawing.Size(606, 148)
        Me.grpPassbkTabAddFeatureTbcPassbookFeatureMainTbcMain.TabIndex = 0
        Me.grpPassbkTabAddFeatureTbcPassbookFeatureMainTbcMain.TabStop = False
        Me.grpPassbkTabAddFeatureTbcPassbookFeatureMainTbcMain.Text = "Passbook Selection"
        Me.tipTPMS.SetToolTip(Me.grpPassbkTabAddFeatureTbcPassbookFeatureMainTbcMain, "Enter feature specific information")
        '
        'cboPassbkIdTabAddFeatTbcPassbkFeatMainTbcMain
        '
        Me.cboPassbkIdTabAddFeatTbcPassbkFeatMainTbcMain.FormattingEnabled = True
        Me.cboPassbkIdTabAddFeatTbcPassbkFeatMainTbcMain.Location = New System.Drawing.Point(110, 29)
        Me.cboPassbkIdTabAddFeatTbcPassbkFeatMainTbcMain.Name = "cboPassbkIdTabAddFeatTbcPassbkFeatMainTbcMain"
        Me.cboPassbkIdTabAddFeatTbcPassbkFeatMainTbcMain.Size = New System.Drawing.Size(135, 23)
        Me.cboPassbkIdTabAddFeatTbcPassbkFeatMainTbcMain.TabIndex = 6
        Me.tipTPMS.SetToolTip(Me.cboPassbkIdTabAddFeatTbcPassbkFeatMainTbcMain, "Select a Passbook from the list")
        '
        'txtVisToStringTabAddFeatTbcPassbkFeatMainTbcMain
        '
        Me.txtVisToStringTabAddFeatTbcPassbkFeatMainTbcMain.BackColor = System.Drawing.SystemColors.ControlLight
        Me.txtVisToStringTabAddFeatTbcPassbkFeatMainTbcMain.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtVisToStringTabAddFeatTbcPassbkFeatMainTbcMain.Location = New System.Drawing.Point(278, 96)
        Me.txtVisToStringTabAddFeatTbcPassbkFeatMainTbcMain.Multiline = True
        Me.txtVisToStringTabAddFeatTbcPassbkFeatMainTbcMain.Name = "txtVisToStringTabAddFeatTbcPassbkFeatMainTbcMain"
        Me.txtVisToStringTabAddFeatTbcPassbkFeatMainTbcMain.ReadOnly = True
        Me.txtVisToStringTabAddFeatTbcPassbkFeatMainTbcMain.Size = New System.Drawing.Size(298, 38)
        Me.txtVisToStringTabAddFeatTbcPassbkFeatMainTbcMain.TabIndex = 5
        Me.txtVisToStringTabAddFeatTbcPassbkFeatMainTbcMain.TabStop = False
        Me.tipTPMS.SetToolTip(Me.txtVisToStringTabAddFeatTbcPassbkFeatMainTbcMain, "Displays selected passbook visitor information")
        '
        'txtCustToStringTabAddFeatTbcPassbkFeatMainTbcMain
        '
        Me.txtCustToStringTabAddFeatTbcPassbkFeatMainTbcMain.BackColor = System.Drawing.SystemColors.ControlLight
        Me.txtCustToStringTabAddFeatTbcPassbkFeatMainTbcMain.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCustToStringTabAddFeatTbcPassbkFeatMainTbcMain.Location = New System.Drawing.Point(278, 37)
        Me.txtCustToStringTabAddFeatTbcPassbkFeatMainTbcMain.Multiline = True
        Me.txtCustToStringTabAddFeatTbcPassbkFeatMainTbcMain.Name = "txtCustToStringTabAddFeatTbcPassbkFeatMainTbcMain"
        Me.txtCustToStringTabAddFeatTbcPassbkFeatMainTbcMain.ReadOnly = True
        Me.txtCustToStringTabAddFeatTbcPassbkFeatMainTbcMain.Size = New System.Drawing.Size(298, 38)
        Me.txtCustToStringTabAddFeatTbcPassbkFeatMainTbcMain.TabIndex = 3
        Me.txtCustToStringTabAddFeatTbcPassbkFeatMainTbcMain.TabStop = False
        Me.tipTPMS.SetToolTip(Me.txtCustToStringTabAddFeatTbcPassbkFeatMainTbcMain, "Displays selected passbook customer information")
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(275, 78)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(154, 15)
        Me.Label16.TabIndex = 4
        Me.Label16.Text = "Visitor ToString Information"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(275, 17)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(174, 15)
        Me.Label17.TabIndex = 2
        Me.Label17.Text = "Customer ToString Information"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(15, 32)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(79, 15)
        Me.Label18.TabIndex = 0
        Me.Label18.Text = "Passbook ID:"
        Me.tipTPMS.SetToolTip(Me.Label18, "Enter the assigned transaction ID")
        '
        'btnResetTabAddFeatTbcPassbkFeatMainTbcMain
        '
        Me.btnResetTabAddFeatTbcPassbkFeatMainTbcMain.Location = New System.Drawing.Point(443, 373)
        Me.btnResetTabAddFeatTbcPassbkFeatMainTbcMain.Name = "btnResetTabAddFeatTbcPassbkFeatMainTbcMain"
        Me.btnResetTabAddFeatTbcPassbkFeatMainTbcMain.Size = New System.Drawing.Size(75, 23)
        Me.btnResetTabAddFeatTbcPassbkFeatMainTbcMain.TabIndex = 4
        Me.btnResetTabAddFeatTbcPassbkFeatMainTbcMain.Text = "&Reset"
        Me.tipTPMS.SetToolTip(Me.btnResetTabAddFeatTbcPassbkFeatMainTbcMain, "Click to reset all input fields")
        Me.btnResetTabAddFeatTbcPassbkFeatMainTbcMain.UseVisualStyleBackColor = True
        '
        'btnSubmitTabAddFeatTbcPassbkFeatMainTbcMain
        '
        Me.btnSubmitTabAddFeatTbcPassbkFeatMainTbcMain.Location = New System.Drawing.Point(348, 373)
        Me.btnSubmitTabAddFeatTbcPassbkFeatMainTbcMain.Name = "btnSubmitTabAddFeatTbcPassbkFeatMainTbcMain"
        Me.btnSubmitTabAddFeatTbcPassbkFeatMainTbcMain.Size = New System.Drawing.Size(75, 23)
        Me.btnSubmitTabAddFeatTbcPassbkFeatMainTbcMain.TabIndex = 3
        Me.btnSubmitTabAddFeatTbcPassbkFeatMainTbcMain.Text = "&Submit"
        Me.tipTPMS.SetToolTip(Me.btnSubmitTabAddFeatTbcPassbkFeatMainTbcMain, "Click to validate and submit feature information")
        Me.btnSubmitTabAddFeatTbcPassbkFeatMainTbcMain.UseVisualStyleBackColor = True
        '
        'tabUpdtFeatTbcPassbkFeatMainTbcMain
        '
        Me.tabUpdtFeatTbcPassbkFeatMainTbcMain.BackColor = System.Drawing.Color.LightGray
        Me.tabUpdtFeatTbcPassbkFeatMainTbcMain.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.tabUpdtFeatTbcPassbkFeatMainTbcMain.Controls.Add(Me.btnResetTabUpdtFeatTbcPassbkFeatMainTbcMain)
        Me.tabUpdtFeatTbcPassbkFeatMainTbcMain.Controls.Add(Me.btnSubmitTabUpdtFeatTbcPassbkFeatMainTbcMain)
        Me.tabUpdtFeatTbcPassbkFeatMainTbcMain.Controls.Add(Me.grpAnon4)
        Me.tabUpdtFeatTbcPassbkFeatMainTbcMain.Controls.Add(Me.grpPassbkTabUpdtFeatTbcPassbkFeatMainTbcMain)
        Me.tabUpdtFeatTbcPassbkFeatMainTbcMain.Location = New System.Drawing.Point(4, 27)
        Me.tabUpdtFeatTbcPassbkFeatMainTbcMain.Name = "tabUpdtFeatTbcPassbkFeatMainTbcMain"
        Me.tabUpdtFeatTbcPassbkFeatMainTbcMain.Padding = New System.Windows.Forms.Padding(3)
        Me.tabUpdtFeatTbcPassbkFeatMainTbcMain.Size = New System.Drawing.Size(871, 416)
        Me.tabUpdtFeatTbcPassbkFeatMainTbcMain.TabIndex = 1
        Me.tabUpdtFeatTbcPassbkFeatMainTbcMain.Text = "Update"
        Me.tabUpdtFeatTbcPassbkFeatMainTbcMain.ToolTipText = "Update passbook feature"
        '
        'btnResetTabUpdtFeatTbcPassbkFeatMainTbcMain
        '
        Me.btnResetTabUpdtFeatTbcPassbkFeatMainTbcMain.Location = New System.Drawing.Point(443, 373)
        Me.btnResetTabUpdtFeatTbcPassbkFeatMainTbcMain.Name = "btnResetTabUpdtFeatTbcPassbkFeatMainTbcMain"
        Me.btnResetTabUpdtFeatTbcPassbkFeatMainTbcMain.Size = New System.Drawing.Size(75, 23)
        Me.btnResetTabUpdtFeatTbcPassbkFeatMainTbcMain.TabIndex = 3
        Me.btnResetTabUpdtFeatTbcPassbkFeatMainTbcMain.Text = "&Reset"
        Me.tipTPMS.SetToolTip(Me.btnResetTabUpdtFeatTbcPassbkFeatMainTbcMain, "Click to reset all input fields")
        Me.btnResetTabUpdtFeatTbcPassbkFeatMainTbcMain.UseVisualStyleBackColor = True
        '
        'btnSubmitTabUpdtFeatTbcPassbkFeatMainTbcMain
        '
        Me.btnSubmitTabUpdtFeatTbcPassbkFeatMainTbcMain.Location = New System.Drawing.Point(348, 373)
        Me.btnSubmitTabUpdtFeatTbcPassbkFeatMainTbcMain.Name = "btnSubmitTabUpdtFeatTbcPassbkFeatMainTbcMain"
        Me.btnSubmitTabUpdtFeatTbcPassbkFeatMainTbcMain.Size = New System.Drawing.Size(75, 23)
        Me.btnSubmitTabUpdtFeatTbcPassbkFeatMainTbcMain.TabIndex = 2
        Me.btnSubmitTabUpdtFeatTbcPassbkFeatMainTbcMain.Text = "&Submit"
        Me.tipTPMS.SetToolTip(Me.btnSubmitTabUpdtFeatTbcPassbkFeatMainTbcMain, "Click to validate and submit feature information")
        Me.btnSubmitTabUpdtFeatTbcPassbkFeatMainTbcMain.UseVisualStyleBackColor = True
        '
        'grpAnon4
        '
        Me.grpAnon4.BackColor = System.Drawing.SystemColors.Control
        Me.grpAnon4.Controls.Add(Me.txtPriceTabUpdtFeatTbcPassbkFeatMainTbcMain)
        Me.grpAnon4.Controls.Add(Me.Label21)
        Me.grpAnon4.Controls.Add(Me.txtNewQtyTabUpdtFeatTbcPassbkFeatMainTbcMain)
        Me.grpAnon4.Controls.Add(Me.Label19)
        Me.grpAnon4.Controls.Add(Me.txtRemQtyTabUpdtFeatTbcPassbkFeatMainTbcMain)
        Me.grpAnon4.Controls.Add(Me.Label20)
        Me.grpAnon4.Location = New System.Drawing.Point(200, 222)
        Me.grpAnon4.Name = "grpAnon4"
        Me.grpAnon4.Size = New System.Drawing.Size(467, 110)
        Me.grpAnon4.TabIndex = 1
        Me.grpAnon4.TabStop = False
        '
        'txtPriceTabUpdtFeatTbcPassbkFeatMainTbcMain
        '
        Me.txtPriceTabUpdtFeatTbcPassbkFeatMainTbcMain.BackColor = System.Drawing.SystemColors.ControlLight
        Me.txtPriceTabUpdtFeatTbcPassbkFeatMainTbcMain.Location = New System.Drawing.Point(229, 16)
        Me.txtPriceTabUpdtFeatTbcPassbkFeatMainTbcMain.Name = "txtPriceTabUpdtFeatTbcPassbkFeatMainTbcMain"
        Me.txtPriceTabUpdtFeatTbcPassbkFeatMainTbcMain.ReadOnly = True
        Me.txtPriceTabUpdtFeatTbcPassbkFeatMainTbcMain.Size = New System.Drawing.Size(100, 21)
        Me.txtPriceTabUpdtFeatTbcPassbkFeatMainTbcMain.TabIndex = 1
        Me.txtPriceTabUpdtFeatTbcPassbkFeatMainTbcMain.TabStop = False
        Me.tipTPMS.SetToolTip(Me.txtPriceTabUpdtFeatTbcPassbkFeatMainTbcMain, "Displays price for this feature update")
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(179, 19)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(38, 15)
        Me.Label21.TabIndex = 0
        Me.Label21.Text = "Price:"
        '
        'txtNewQtyTabUpdtFeatTbcPassbkFeatMainTbcMain
        '
        Me.txtNewQtyTabUpdtFeatTbcPassbkFeatMainTbcMain.Location = New System.Drawing.Point(229, 70)
        Me.txtNewQtyTabUpdtFeatTbcPassbkFeatMainTbcMain.Name = "txtNewQtyTabUpdtFeatTbcPassbkFeatMainTbcMain"
        Me.txtNewQtyTabUpdtFeatTbcPassbkFeatMainTbcMain.Size = New System.Drawing.Size(100, 21)
        Me.txtNewQtyTabUpdtFeatTbcPassbkFeatMainTbcMain.TabIndex = 5
        Me.tipTPMS.SetToolTip(Me.txtNewQtyTabUpdtFeatTbcPassbkFeatMainTbcMain, "Enter the amount of feature that was used")
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(134, 73)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(82, 15)
        Me.Label19.TabIndex = 4
        Me.Label19.Text = "New Quantity:"
        '
        'txtRemQtyTabUpdtFeatTbcPassbkFeatMainTbcMain
        '
        Me.txtRemQtyTabUpdtFeatTbcPassbkFeatMainTbcMain.BackColor = System.Drawing.SystemColors.ControlLight
        Me.txtRemQtyTabUpdtFeatTbcPassbkFeatMainTbcMain.Location = New System.Drawing.Point(229, 44)
        Me.txtRemQtyTabUpdtFeatTbcPassbkFeatMainTbcMain.Name = "txtRemQtyTabUpdtFeatTbcPassbkFeatMainTbcMain"
        Me.txtRemQtyTabUpdtFeatTbcPassbkFeatMainTbcMain.ReadOnly = True
        Me.txtRemQtyTabUpdtFeatTbcPassbkFeatMainTbcMain.Size = New System.Drawing.Size(100, 21)
        Me.txtRemQtyTabUpdtFeatTbcPassbkFeatMainTbcMain.TabIndex = 3
        Me.txtRemQtyTabUpdtFeatTbcPassbkFeatMainTbcMain.TabStop = False
        Me.tipTPMS.SetToolTip(Me.txtRemQtyTabUpdtFeatTbcPassbkFeatMainTbcMain, "Amount of this feature remaining for the specified passbook")
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(96, 47)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(118, 15)
        Me.Label20.TabIndex = 2
        Me.Label20.Text = "Remaining Quantity:"
        '
        'grpPassbkTabUpdtFeatTbcPassbkFeatMainTbcMain
        '
        Me.grpPassbkTabUpdtFeatTbcPassbkFeatMainTbcMain.BackColor = System.Drawing.SystemColors.Control
        Me.grpPassbkTabUpdtFeatTbcPassbkFeatMainTbcMain.Controls.Add(Me.cboFeatIdTabUpdtFeatTbcPassbkFeatMainTbcMain)
        Me.grpPassbkTabUpdtFeatTbcPassbkFeatMainTbcMain.Controls.Add(Me.txtPrevUsedToStringTabUpdtFeatTbcPassbkFeatMainTbcMain)
        Me.grpPassbkTabUpdtFeatTbcPassbkFeatMainTbcMain.Controls.Add(Me.txtVisToStringTabUpdtFeatTbcPassbkFeatMainTbcMain)
        Me.grpPassbkTabUpdtFeatTbcPassbkFeatMainTbcMain.Controls.Add(Me.txtFeatToStringTabUpdtFeatTbcPassbkFeatMainTbcMain)
        Me.grpPassbkTabUpdtFeatTbcPassbkFeatMainTbcMain.Controls.Add(Me.Label47)
        Me.grpPassbkTabUpdtFeatTbcPassbkFeatMainTbcMain.Controls.Add(Me.txtCustToStringTabUpdtFeatTbcPassbkFeatMainTbcMain)
        Me.grpPassbkTabUpdtFeatTbcPassbkFeatMainTbcMain.Controls.Add(Me.Label48)
        Me.grpPassbkTabUpdtFeatTbcPassbkFeatMainTbcMain.Controls.Add(Me.Label49)
        Me.grpPassbkTabUpdtFeatTbcPassbkFeatMainTbcMain.Controls.Add(Me.Label50)
        Me.grpPassbkTabUpdtFeatTbcPassbkFeatMainTbcMain.Controls.Add(Me.Label51)
        Me.grpPassbkTabUpdtFeatTbcPassbkFeatMainTbcMain.Location = New System.Drawing.Point(26, 6)
        Me.grpPassbkTabUpdtFeatTbcPassbkFeatMainTbcMain.Name = "grpPassbkTabUpdtFeatTbcPassbkFeatMainTbcMain"
        Me.grpPassbkTabUpdtFeatTbcPassbkFeatMainTbcMain.Size = New System.Drawing.Size(815, 209)
        Me.grpPassbkTabUpdtFeatTbcPassbkFeatMainTbcMain.TabIndex = 0
        Me.grpPassbkTabUpdtFeatTbcPassbkFeatMainTbcMain.TabStop = False
        Me.grpPassbkTabUpdtFeatTbcPassbkFeatMainTbcMain.Text = "Passbook"
        Me.tipTPMS.SetToolTip(Me.grpPassbkTabUpdtFeatTbcPassbkFeatMainTbcMain, "Enter feature specific information")
        '
        'cboFeatIdTabUpdtFeatTbcPassbkFeatMainTbcMain
        '
        Me.cboFeatIdTabUpdtFeatTbcPassbkFeatMainTbcMain.FormattingEnabled = True
        Me.cboFeatIdTabUpdtFeatTbcPassbkFeatMainTbcMain.Location = New System.Drawing.Point(98, 36)
        Me.cboFeatIdTabUpdtFeatTbcPassbkFeatMainTbcMain.Name = "cboFeatIdTabUpdtFeatTbcPassbkFeatMainTbcMain"
        Me.cboFeatIdTabUpdtFeatTbcPassbkFeatMainTbcMain.Size = New System.Drawing.Size(136, 23)
        Me.cboFeatIdTabUpdtFeatTbcPassbkFeatMainTbcMain.TabIndex = 10
        Me.tipTPMS.SetToolTip(Me.cboFeatIdTabUpdtFeatTbcPassbkFeatMainTbcMain, "Select a Passbook Feature from the list")
        '
        'txtPrevUsedToStringTabUpdtFeatTbcPassbkFeatMainTbcMain
        '
        Me.txtPrevUsedToStringTabUpdtFeatTbcPassbkFeatMainTbcMain.BackColor = System.Drawing.SystemColors.ControlLight
        Me.txtPrevUsedToStringTabUpdtFeatTbcPassbkFeatMainTbcMain.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPrevUsedToStringTabUpdtFeatTbcPassbkFeatMainTbcMain.Location = New System.Drawing.Point(590, 38)
        Me.txtPrevUsedToStringTabUpdtFeatTbcPassbkFeatMainTbcMain.Multiline = True
        Me.txtPrevUsedToStringTabUpdtFeatTbcPassbkFeatMainTbcMain.Name = "txtPrevUsedToStringTabUpdtFeatTbcPassbkFeatMainTbcMain"
        Me.txtPrevUsedToStringTabUpdtFeatTbcPassbkFeatMainTbcMain.ReadOnly = True
        Me.txtPrevUsedToStringTabUpdtFeatTbcPassbkFeatMainTbcMain.Size = New System.Drawing.Size(212, 157)
        Me.txtPrevUsedToStringTabUpdtFeatTbcPassbkFeatMainTbcMain.TabIndex = 9
        Me.txtPrevUsedToStringTabUpdtFeatTbcPassbkFeatMainTbcMain.TabStop = False
        Me.tipTPMS.SetToolTip(Me.txtPrevUsedToStringTabUpdtFeatTbcPassbkFeatMainTbcMain, "Displays information of previously used features")
        '
        'txtVisToStringTabUpdtFeatTbcPassbkFeatMainTbcMain
        '
        Me.txtVisToStringTabUpdtFeatTbcPassbkFeatMainTbcMain.BackColor = System.Drawing.SystemColors.ControlLight
        Me.txtVisToStringTabUpdtFeatTbcPassbkFeatMainTbcMain.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtVisToStringTabUpdtFeatTbcPassbkFeatMainTbcMain.Location = New System.Drawing.Point(283, 97)
        Me.txtVisToStringTabUpdtFeatTbcPassbkFeatMainTbcMain.Multiline = True
        Me.txtVisToStringTabUpdtFeatTbcPassbkFeatMainTbcMain.Name = "txtVisToStringTabUpdtFeatTbcPassbkFeatMainTbcMain"
        Me.txtVisToStringTabUpdtFeatTbcPassbkFeatMainTbcMain.ReadOnly = True
        Me.txtVisToStringTabUpdtFeatTbcPassbkFeatMainTbcMain.Size = New System.Drawing.Size(268, 38)
        Me.txtVisToStringTabUpdtFeatTbcPassbkFeatMainTbcMain.TabIndex = 5
        Me.txtVisToStringTabUpdtFeatTbcPassbkFeatMainTbcMain.TabStop = False
        Me.tipTPMS.SetToolTip(Me.txtVisToStringTabUpdtFeatTbcPassbkFeatMainTbcMain, "Displays selected passbook feature visitor information")
        '
        'txtFeatToStringTabUpdtFeatTbcPassbkFeatMainTbcMain
        '
        Me.txtFeatToStringTabUpdtFeatTbcPassbkFeatMainTbcMain.BackColor = System.Drawing.SystemColors.ControlLight
        Me.txtFeatToStringTabUpdtFeatTbcPassbkFeatMainTbcMain.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtFeatToStringTabUpdtFeatTbcPassbkFeatMainTbcMain.Location = New System.Drawing.Point(283, 157)
        Me.txtFeatToStringTabUpdtFeatTbcPassbkFeatMainTbcMain.Multiline = True
        Me.txtFeatToStringTabUpdtFeatTbcPassbkFeatMainTbcMain.Name = "txtFeatToStringTabUpdtFeatTbcPassbkFeatMainTbcMain"
        Me.txtFeatToStringTabUpdtFeatTbcPassbkFeatMainTbcMain.ReadOnly = True
        Me.txtFeatToStringTabUpdtFeatTbcPassbkFeatMainTbcMain.Size = New System.Drawing.Size(268, 38)
        Me.txtFeatToStringTabUpdtFeatTbcPassbkFeatMainTbcMain.TabIndex = 7
        Me.txtFeatToStringTabUpdtFeatTbcPassbkFeatMainTbcMain.TabStop = False
        Me.tipTPMS.SetToolTip(Me.txtFeatToStringTabUpdtFeatTbcPassbkFeatMainTbcMain, "Displays selected passbook feature information")
        '
        'Label47
        '
        Me.Label47.AutoSize = True
        Me.Label47.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label47.Location = New System.Drawing.Point(587, 18)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(94, 15)
        Me.Label47.TabIndex = 8
        Me.Label47.Text = "Previously Used"
        '
        'txtCustToStringTabUpdtFeatTbcPassbkFeatMainTbcMain
        '
        Me.txtCustToStringTabUpdtFeatTbcPassbkFeatMainTbcMain.BackColor = System.Drawing.SystemColors.ControlLight
        Me.txtCustToStringTabUpdtFeatTbcPassbkFeatMainTbcMain.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCustToStringTabUpdtFeatTbcPassbkFeatMainTbcMain.Location = New System.Drawing.Point(283, 37)
        Me.txtCustToStringTabUpdtFeatTbcPassbkFeatMainTbcMain.Multiline = True
        Me.txtCustToStringTabUpdtFeatTbcPassbkFeatMainTbcMain.Name = "txtCustToStringTabUpdtFeatTbcPassbkFeatMainTbcMain"
        Me.txtCustToStringTabUpdtFeatTbcPassbkFeatMainTbcMain.ReadOnly = True
        Me.txtCustToStringTabUpdtFeatTbcPassbkFeatMainTbcMain.Size = New System.Drawing.Size(271, 38)
        Me.txtCustToStringTabUpdtFeatTbcPassbkFeatMainTbcMain.TabIndex = 3
        Me.txtCustToStringTabUpdtFeatTbcPassbkFeatMainTbcMain.TabStop = False
        Me.tipTPMS.SetToolTip(Me.txtCustToStringTabUpdtFeatTbcPassbkFeatMainTbcMain, "Displays selected passbook feature customer information")
        '
        'Label48
        '
        Me.Label48.AutoSize = True
        Me.Label48.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label48.Location = New System.Drawing.Point(280, 138)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(163, 15)
        Me.Label48.TabIndex = 6
        Me.Label48.Text = "Feature ToString Information"
        '
        'Label49
        '
        Me.Label49.AutoSize = True
        Me.Label49.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label49.Location = New System.Drawing.Point(280, 78)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(154, 15)
        Me.Label49.TabIndex = 4
        Me.Label49.Text = "Visitor ToString Information"
        '
        'Label50
        '
        Me.Label50.AutoSize = True
        Me.Label50.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label50.Location = New System.Drawing.Point(280, 18)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(174, 15)
        Me.Label50.TabIndex = 2
        Me.Label50.Text = "Customer ToString Information"
        '
        'Label51
        '
        Me.Label51.AutoSize = True
        Me.Label51.Location = New System.Drawing.Point(19, 28)
        Me.Label51.Name = "Label51"
        Me.Label51.Size = New System.Drawing.Size(67, 30)
        Me.Label51.TabIndex = 0
        Me.Label51.Text = "Passbook " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Feature ID:"
        Me.tipTPMS.SetToolTip(Me.Label51, "Enter the assigned transaction ID")
        '
        'tabPostFeatTbcPassbkFeatMainTbcMain
        '
        Me.tabPostFeatTbcPassbkFeatMainTbcMain.BackColor = System.Drawing.Color.LightGray
        Me.tabPostFeatTbcPassbkFeatMainTbcMain.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.tabPostFeatTbcPassbkFeatMainTbcMain.Controls.Add(Me.grpAnon1)
        Me.tabPostFeatTbcPassbkFeatMainTbcMain.Controls.Add(Me.btnResetTabPostFeatTbcPassbkFeatMainTbcMain)
        Me.tabPostFeatTbcPassbkFeatMainTbcMain.Controls.Add(Me.grpPassbkTabPostTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain)
        Me.tabPostFeatTbcPassbkFeatMainTbcMain.Controls.Add(Me.btnSubmitTabPostFeatTbcPassbkFeatMainTbcMain)
        Me.tabPostFeatTbcPassbkFeatMainTbcMain.Location = New System.Drawing.Point(4, 27)
        Me.tabPostFeatTbcPassbkFeatMainTbcMain.Name = "tabPostFeatTbcPassbkFeatMainTbcMain"
        Me.tabPostFeatTbcPassbkFeatMainTbcMain.Padding = New System.Windows.Forms.Padding(3)
        Me.tabPostFeatTbcPassbkFeatMainTbcMain.Size = New System.Drawing.Size(871, 416)
        Me.tabPostFeatTbcPassbkFeatMainTbcMain.TabIndex = 2
        Me.tabPostFeatTbcPassbkFeatMainTbcMain.Text = "Post "
        Me.tipTPMS.SetToolTip(Me.tabPostFeatTbcPassbkFeatMainTbcMain, "Register use of a specific feature")
        '
        'grpAnon1
        '
        Me.grpAnon1.BackColor = System.Drawing.SystemColors.Control
        Me.grpAnon1.Controls.Add(Me.txtQtyUsedTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain)
        Me.grpAnon1.Controls.Add(Me.Label24)
        Me.grpAnon1.Controls.Add(Me.txtRemQuantTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain)
        Me.grpAnon1.Controls.Add(Me.Label23)
        Me.grpAnon1.Controls.Add(Me.Label26)
        Me.grpAnon1.Controls.Add(Me.txtLocTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain)
        Me.grpAnon1.Location = New System.Drawing.Point(200, 222)
        Me.grpAnon1.Name = "grpAnon1"
        Me.grpAnon1.Size = New System.Drawing.Size(467, 110)
        Me.grpAnon1.TabIndex = 1
        Me.grpAnon1.TabStop = False
        '
        'txtQtyUsedTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain
        '
        Me.txtQtyUsedTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain.Location = New System.Drawing.Point(153, 45)
        Me.txtQtyUsedTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain.Name = "txtQtyUsedTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain"
        Me.txtQtyUsedTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain.Size = New System.Drawing.Size(100, 21)
        Me.txtQtyUsedTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain.TabIndex = 3
        Me.tipTPMS.SetToolTip(Me.txtQtyUsedTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain, "Enter the amount of feature that was used")
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(52, 48)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(86, 15)
        Me.Label24.TabIndex = 2
        Me.Label24.Text = "Quantity Used:"
        '
        'txtRemQuantTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain
        '
        Me.txtRemQuantTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain.BackColor = System.Drawing.SystemColors.ControlLight
        Me.txtRemQuantTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain.Location = New System.Drawing.Point(153, 19)
        Me.txtRemQuantTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain.Name = "txtRemQuantTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain"
        Me.txtRemQuantTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain.ReadOnly = True
        Me.txtRemQuantTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain.Size = New System.Drawing.Size(100, 21)
        Me.txtRemQuantTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain.TabIndex = 1
        Me.txtRemQuantTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain.TabStop = False
        Me.tipTPMS.SetToolTip(Me.txtRemQuantTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain, "Amount of this feature remaining for the specified passbook")
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(20, 22)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(118, 15)
        Me.Label23.TabIndex = 0
        Me.Label23.Text = "Remaining Quantity:"
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(82, 77)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(57, 15)
        Me.Label26.TabIndex = 4
        Me.Label26.Text = "Location:"
        Me.tipTPMS.SetToolTip(Me.Label26, "Enter the location where transaction occurred")
        '
        'txtLocTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain
        '
        Me.txtLocTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain.AccessibleRole = System.Windows.Forms.AccessibleRole.None
        Me.txtLocTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain.Location = New System.Drawing.Point(153, 74)
        Me.txtLocTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain.Name = "txtLocTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain"
        Me.txtLocTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain.Size = New System.Drawing.Size(249, 21)
        Me.txtLocTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain.TabIndex = 5
        Me.tipTPMS.SetToolTip(Me.txtLocTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain, "Enter the location where this feature was used")
        '
        'btnResetTabPostFeatTbcPassbkFeatMainTbcMain
        '
        Me.btnResetTabPostFeatTbcPassbkFeatMainTbcMain.Location = New System.Drawing.Point(443, 373)
        Me.btnResetTabPostFeatTbcPassbkFeatMainTbcMain.Name = "btnResetTabPostFeatTbcPassbkFeatMainTbcMain"
        Me.btnResetTabPostFeatTbcPassbkFeatMainTbcMain.Size = New System.Drawing.Size(75, 23)
        Me.btnResetTabPostFeatTbcPassbkFeatMainTbcMain.TabIndex = 3
        Me.btnResetTabPostFeatTbcPassbkFeatMainTbcMain.Text = "&Reset"
        Me.tipTPMS.SetToolTip(Me.btnResetTabPostFeatTbcPassbkFeatMainTbcMain, "Click to reset all input fields")
        Me.btnResetTabPostFeatTbcPassbkFeatMainTbcMain.UseVisualStyleBackColor = True
        '
        'grpPassbkTabPostTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain
        '
        Me.grpPassbkTabPostTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain.BackColor = System.Drawing.SystemColors.Control
        Me.grpPassbkTabPostTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain.Controls.Add(Me.cboPassbkFeatIdTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain)
        Me.grpPassbkTabPostTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain.Controls.Add(Me.txtPrevUsedTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain)
        Me.grpPassbkTabPostTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain.Controls.Add(Me.txtVisToStringTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain)
        Me.grpPassbkTabPostTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain.Controls.Add(Me.txtFeatToStringTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain)
        Me.grpPassbkTabPostTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain.Controls.Add(Me.Label13)
        Me.grpPassbkTabPostTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain.Controls.Add(Me.txtCustToStringTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain)
        Me.grpPassbkTabPostTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain.Controls.Add(Me.Label12)
        Me.grpPassbkTabPostTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain.Controls.Add(Me.Label11)
        Me.grpPassbkTabPostTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain.Controls.Add(Me.Label10)
        Me.grpPassbkTabPostTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain.Controls.Add(Me.Label22)
        Me.grpPassbkTabPostTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpPassbkTabPostTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain.Location = New System.Drawing.Point(26, 6)
        Me.grpPassbkTabPostTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain.Name = "grpPassbkTabPostTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain"
        Me.grpPassbkTabPostTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain.Size = New System.Drawing.Size(815, 209)
        Me.grpPassbkTabPostTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain.TabIndex = 0
        Me.grpPassbkTabPostTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain.TabStop = False
        Me.grpPassbkTabPostTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain.Text = "Passbook"
        Me.tipTPMS.SetToolTip(Me.grpPassbkTabPostTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain, "Enter feature specific information")
        '
        'cboPassbkFeatIdTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain
        '
        Me.cboPassbkFeatIdTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain.FormattingEnabled = True
        Me.cboPassbkFeatIdTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain.Location = New System.Drawing.Point(98, 36)
        Me.cboPassbkFeatIdTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain.Name = "cboPassbkFeatIdTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain"
        Me.cboPassbkFeatIdTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain.Size = New System.Drawing.Size(136, 23)
        Me.cboPassbkFeatIdTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain.TabIndex = 10
        Me.tipTPMS.SetToolTip(Me.cboPassbkFeatIdTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain, "Select a Passbook Feature from the list")
        '
        'txtPrevUsedTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain
        '
        Me.txtPrevUsedTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain.BackColor = System.Drawing.SystemColors.ControlLight
        Me.txtPrevUsedTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPrevUsedTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain.Location = New System.Drawing.Point(590, 38)
        Me.txtPrevUsedTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain.Multiline = True
        Me.txtPrevUsedTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain.Name = "txtPrevUsedTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain"
        Me.txtPrevUsedTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain.ReadOnly = True
        Me.txtPrevUsedTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain.Size = New System.Drawing.Size(212, 157)
        Me.txtPrevUsedTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain.TabIndex = 9
        Me.txtPrevUsedTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain.TabStop = False
        Me.tipTPMS.SetToolTip(Me.txtPrevUsedTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain, "Displays information of previously used features")
        '
        'txtVisToStringTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain
        '
        Me.txtVisToStringTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain.BackColor = System.Drawing.SystemColors.ControlLight
        Me.txtVisToStringTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtVisToStringTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain.Location = New System.Drawing.Point(283, 97)
        Me.txtVisToStringTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain.Multiline = True
        Me.txtVisToStringTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain.Name = "txtVisToStringTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain"
        Me.txtVisToStringTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain.ReadOnly = True
        Me.txtVisToStringTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain.Size = New System.Drawing.Size(268, 38)
        Me.txtVisToStringTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain.TabIndex = 5
        Me.txtVisToStringTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain.TabStop = False
        Me.tipTPMS.SetToolTip(Me.txtVisToStringTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain, "Displays selected passbook feature visitor information")
        '
        'txtFeatToStringTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain
        '
        Me.txtFeatToStringTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain.BackColor = System.Drawing.SystemColors.ControlLight
        Me.txtFeatToStringTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtFeatToStringTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain.Location = New System.Drawing.Point(283, 157)
        Me.txtFeatToStringTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain.Multiline = True
        Me.txtFeatToStringTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain.Name = "txtFeatToStringTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain"
        Me.txtFeatToStringTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain.ReadOnly = True
        Me.txtFeatToStringTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain.Size = New System.Drawing.Size(268, 38)
        Me.txtFeatToStringTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain.TabIndex = 7
        Me.txtFeatToStringTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain.TabStop = False
        Me.tipTPMS.SetToolTip(Me.txtFeatToStringTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain, "Displays selected passbook feature information")
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(587, 18)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(94, 15)
        Me.Label13.TabIndex = 8
        Me.Label13.Text = "Previously Used"
        '
        'txtCustToStringTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain
        '
        Me.txtCustToStringTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain.BackColor = System.Drawing.SystemColors.ControlLight
        Me.txtCustToStringTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCustToStringTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain.Location = New System.Drawing.Point(283, 37)
        Me.txtCustToStringTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain.Multiline = True
        Me.txtCustToStringTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain.Name = "txtCustToStringTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain"
        Me.txtCustToStringTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain.ReadOnly = True
        Me.txtCustToStringTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain.Size = New System.Drawing.Size(271, 38)
        Me.txtCustToStringTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain.TabIndex = 3
        Me.txtCustToStringTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain.TabStop = False
        Me.tipTPMS.SetToolTip(Me.txtCustToStringTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain, "Displays selected passbook feature customer information")
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(280, 138)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(163, 15)
        Me.Label12.TabIndex = 6
        Me.Label12.Text = "Feature ToString Information"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(280, 78)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(154, 15)
        Me.Label11.TabIndex = 4
        Me.Label11.Text = "Visitor ToString Information"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(280, 18)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(174, 15)
        Me.Label10.TabIndex = 2
        Me.Label10.Text = "Customer ToString Information"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.Location = New System.Drawing.Point(19, 28)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(67, 30)
        Me.Label22.TabIndex = 0
        Me.Label22.Text = "Passbook" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Feature ID:"
        Me.tipTPMS.SetToolTip(Me.Label22, "Enter the assigned transaction ID")
        '
        'btnSubmitTabPostFeatTbcPassbkFeatMainTbcMain
        '
        Me.btnSubmitTabPostFeatTbcPassbkFeatMainTbcMain.Location = New System.Drawing.Point(348, 373)
        Me.btnSubmitTabPostFeatTbcPassbkFeatMainTbcMain.Name = "btnSubmitTabPostFeatTbcPassbkFeatMainTbcMain"
        Me.btnSubmitTabPostFeatTbcPassbkFeatMainTbcMain.Size = New System.Drawing.Size(75, 23)
        Me.btnSubmitTabPostFeatTbcPassbkFeatMainTbcMain.TabIndex = 2
        Me.btnSubmitTabPostFeatTbcPassbkFeatMainTbcMain.Text = "&Submit"
        Me.tipTPMS.SetToolTip(Me.btnSubmitTabPostFeatTbcPassbkFeatMainTbcMain, "Click to validate and submit feature information")
        Me.btnSubmitTabPostFeatTbcPassbkFeatMainTbcMain.UseVisualStyleBackColor = True
        '
        'tabPassbkTbcMainFrmMain
        '
        Me.tabPassbkTbcMainFrmMain.BackColor = System.Drawing.Color.LightGray
        Me.tabPassbkTbcMainFrmMain.Controls.Add(Me.grpAddPassbkTabPassbkTbcMainFrmMain)
        Me.tabPassbkTbcMainFrmMain.Location = New System.Drawing.Point(4, 27)
        Me.tabPassbkTbcMainFrmMain.Name = "tabPassbkTbcMainFrmMain"
        Me.tabPassbkTbcMainFrmMain.Padding = New System.Windows.Forms.Padding(3)
        Me.tabPassbkTbcMainFrmMain.Size = New System.Drawing.Size(919, 468)
        Me.tabPassbkTbcMainFrmMain.TabIndex = 2
        Me.tabPassbkTbcMainFrmMain.Text = "Passbook"
        Me.tipTPMS.SetToolTip(Me.tabPassbkTbcMainFrmMain, "Add a new passbook to the system")
        '
        'grpAddPassbkTabPassbkTbcMainFrmMain
        '
        Me.grpAddPassbkTabPassbkTbcMainFrmMain.BackColor = System.Drawing.Color.LightGray
        Me.grpAddPassbkTabPassbkTbcMainFrmMain.Controls.Add(Me.grpAnon2)
        Me.grpAddPassbkTabPassbkTbcMainFrmMain.Controls.Add(Me.grpCustInfoGrpAddPassbkTabPassbkTbcMainFrmMain)
        Me.grpAddPassbkTabPassbkTbcMainFrmMain.Controls.Add(Me.btnResetGrpAddPassbkTabPassbkTbcMainFrmMain)
        Me.grpAddPassbkTabPassbkTbcMainFrmMain.Controls.Add(Me.btnSubmitGrpAddPassbkTabPassbkTbcMainFrmMain)
        Me.grpAddPassbkTabPassbkTbcMainFrmMain.Location = New System.Drawing.Point(87, 30)
        Me.grpAddPassbkTabPassbkTbcMainFrmMain.Name = "grpAddPassbkTabPassbkTbcMainFrmMain"
        Me.grpAddPassbkTabPassbkTbcMainFrmMain.Size = New System.Drawing.Size(745, 393)
        Me.grpAddPassbkTabPassbkTbcMainFrmMain.TabIndex = 0
        Me.grpAddPassbkTabPassbkTbcMainFrmMain.TabStop = False
        Me.grpAddPassbkTabPassbkTbcMainFrmMain.Text = "Add New Passbook"
        Me.tipTPMS.SetToolTip(Me.grpAddPassbkTabPassbkTbcMainFrmMain, "Enter passbook specific information")
        '
        'grpAnon2
        '
        Me.grpAnon2.BackColor = System.Drawing.SystemColors.Control
        Me.grpAnon2.Controls.Add(Me.txtVisNameGrpAddPassbkTabPassbkTbcMainFrmMain)
        Me.grpAnon2.Controls.Add(Me.Label7)
        Me.grpAnon2.Controls.Add(Me.txtVisDobGrpAddPassbkTabPassbkTbcMainFrmMain)
        Me.grpAnon2.Controls.Add(Me.Label5)
        Me.grpAnon2.Controls.Add(Me.txtPassbkIdGrpAddPassbkTabPassbkTbcMainFrmMain)
        Me.grpAnon2.Controls.Add(Me.Label8)
        Me.grpAnon2.Location = New System.Drawing.Point(164, 193)
        Me.grpAnon2.Name = "grpAnon2"
        Me.grpAnon2.Size = New System.Drawing.Size(416, 114)
        Me.grpAnon2.TabIndex = 1
        Me.grpAnon2.TabStop = False
        '
        'txtVisNameGrpAddPassbkTabPassbkTbcMainFrmMain
        '
        Me.txtVisNameGrpAddPassbkTabPassbkTbcMainFrmMain.Location = New System.Drawing.Point(131, 48)
        Me.txtVisNameGrpAddPassbkTabPassbkTbcMainFrmMain.Name = "txtVisNameGrpAddPassbkTabPassbkTbcMainFrmMain"
        Me.txtVisNameGrpAddPassbkTabPassbkTbcMainFrmMain.Size = New System.Drawing.Size(249, 21)
        Me.txtVisNameGrpAddPassbkTabPassbkTbcMainFrmMain.TabIndex = 3
        Me.tipTPMS.SetToolTip(Me.txtVisNameGrpAddPassbkTabPassbkTbcMainFrmMain, "Enter Vistor name <Lastname, Firstname>")
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(39, 51)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(80, 15)
        Me.Label7.TabIndex = 2
        Me.Label7.Text = "Visitor Name:"
        '
        'txtVisDobGrpAddPassbkTabPassbkTbcMainFrmMain
        '
        Me.txtVisDobGrpAddPassbkTabPassbkTbcMainFrmMain.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.txtVisDobGrpAddPassbkTabPassbkTbcMainFrmMain.Location = New System.Drawing.Point(133, 76)
        Me.txtVisDobGrpAddPassbkTabPassbkTbcMainFrmMain.Name = "txtVisDobGrpAddPassbkTabPassbkTbcMainFrmMain"
        Me.txtVisDobGrpAddPassbkTabPassbkTbcMainFrmMain.Size = New System.Drawing.Size(107, 21)
        Me.txtVisDobGrpAddPassbkTabPassbkTbcMainFrmMain.TabIndex = 5
        Me.tipTPMS.SetToolTip(Me.txtVisDobGrpAddPassbkTabPassbkTbcMainFrmMain, "Select Vistor's date of birth from the calendar")
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(36, 23)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(79, 15)
        Me.Label5.TabIndex = 0
        Me.Label5.Text = "Passbook ID:"
        '
        'txtPassbkIdGrpAddPassbkTabPassbkTbcMainFrmMain
        '
        Me.txtPassbkIdGrpAddPassbkTabPassbkTbcMainFrmMain.Location = New System.Drawing.Point(131, 20)
        Me.txtPassbkIdGrpAddPassbkTabPassbkTbcMainFrmMain.Name = "txtPassbkIdGrpAddPassbkTabPassbkTbcMainFrmMain"
        Me.txtPassbkIdGrpAddPassbkTabPassbkTbcMainFrmMain.Size = New System.Drawing.Size(136, 21)
        Me.txtPassbkIdGrpAddPassbkTabPassbkTbcMainFrmMain.TabIndex = 1
        Me.tipTPMS.SetToolTip(Me.txtPassbkIdGrpAddPassbkTabPassbkTbcMainFrmMain, "Enter a unique passbook identifier")
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(47, 80)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(72, 15)
        Me.Label8.TabIndex = 4
        Me.Label8.Text = "Visitor DOB:"
        '
        'grpCustInfoGrpAddPassbkTabPassbkTbcMainFrmMain
        '
        Me.grpCustInfoGrpAddPassbkTabPassbkTbcMainFrmMain.BackColor = System.Drawing.SystemColors.Control
        Me.grpCustInfoGrpAddPassbkTabPassbkTbcMainFrmMain.Controls.Add(Me.cboCustIdGrpCustInfoGrpAddPassbkTabPassbkTbcMainFrmMain)
        Me.grpCustInfoGrpAddPassbkTabPassbkTbcMainFrmMain.Controls.Add(Me.Label3)
        Me.grpCustInfoGrpAddPassbkTabPassbkTbcMainFrmMain.Controls.Add(Me.txtToStringGrpCustInfoGrpAddPassbkTabPassbkTbcMainFrmMain)
        Me.grpCustInfoGrpAddPassbkTabPassbkTbcMainFrmMain.Controls.Add(Me.Label6)
        Me.grpCustInfoGrpAddPassbkTabPassbkTbcMainFrmMain.Location = New System.Drawing.Point(48, 21)
        Me.grpCustInfoGrpAddPassbkTabPassbkTbcMainFrmMain.Name = "grpCustInfoGrpAddPassbkTabPassbkTbcMainFrmMain"
        Me.grpCustInfoGrpAddPassbkTabPassbkTbcMainFrmMain.Size = New System.Drawing.Size(649, 153)
        Me.grpCustInfoGrpAddPassbkTabPassbkTbcMainFrmMain.TabIndex = 0
        Me.grpCustInfoGrpAddPassbkTabPassbkTbcMainFrmMain.TabStop = False
        Me.grpCustInfoGrpAddPassbkTabPassbkTbcMainFrmMain.Text = "Customer Info"
        '
        'cboCustIdGrpCustInfoGrpAddPassbkTabPassbkTbcMainFrmMain
        '
        Me.cboCustIdGrpCustInfoGrpAddPassbkTabPassbkTbcMainFrmMain.FormattingEnabled = True
        Me.cboCustIdGrpCustInfoGrpAddPassbkTabPassbkTbcMainFrmMain.Location = New System.Drawing.Point(117, 43)
        Me.cboCustIdGrpCustInfoGrpAddPassbkTabPassbkTbcMainFrmMain.Name = "cboCustIdGrpCustInfoGrpAddPassbkTabPassbkTbcMainFrmMain"
        Me.cboCustIdGrpCustInfoGrpAddPassbkTabPassbkTbcMainFrmMain.Size = New System.Drawing.Size(144, 23)
        Me.cboCustIdGrpCustInfoGrpAddPassbkTabPassbkTbcMainFrmMain.TabIndex = 1
        Me.tipTPMS.SetToolTip(Me.cboCustIdGrpCustInfoGrpAddPassbkTabPassbkTbcMainFrmMain, "Select a Customer from the list")
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(294, 24)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(174, 15)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Customer ToString Information"
        '
        'txtToStringGrpCustInfoGrpAddPassbkTabPassbkTbcMainFrmMain
        '
        Me.txtToStringGrpCustInfoGrpAddPassbkTabPassbkTbcMainFrmMain.BackColor = System.Drawing.SystemColors.ControlLight
        Me.txtToStringGrpCustInfoGrpAddPassbkTabPassbkTbcMainFrmMain.Location = New System.Drawing.Point(297, 43)
        Me.txtToStringGrpCustInfoGrpAddPassbkTabPassbkTbcMainFrmMain.Multiline = True
        Me.txtToStringGrpCustInfoGrpAddPassbkTabPassbkTbcMainFrmMain.Name = "txtToStringGrpCustInfoGrpAddPassbkTabPassbkTbcMainFrmMain"
        Me.txtToStringGrpCustInfoGrpAddPassbkTabPassbkTbcMainFrmMain.ReadOnly = True
        Me.txtToStringGrpCustInfoGrpAddPassbkTabPassbkTbcMainFrmMain.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtToStringGrpCustInfoGrpAddPassbkTabPassbkTbcMainFrmMain.Size = New System.Drawing.Size(346, 90)
        Me.txtToStringGrpCustInfoGrpAddPassbkTabPassbkTbcMainFrmMain.TabIndex = 3
        Me.txtToStringGrpCustInfoGrpAddPassbkTabPassbkTbcMainFrmMain.TabStop = False
        Me.tipTPMS.SetToolTip(Me.txtToStringGrpCustInfoGrpAddPassbkTabPassbkTbcMainFrmMain, "Display specific customer information")
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(27, 46)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(78, 15)
        Me.Label6.TabIndex = 0
        Me.Label6.Text = "Customer ID:"
        '
        'btnResetGrpAddPassbkTabPassbkTbcMainFrmMain
        '
        Me.btnResetGrpAddPassbkTabPassbkTbcMainFrmMain.Location = New System.Drawing.Point(382, 345)
        Me.btnResetGrpAddPassbkTabPassbkTbcMainFrmMain.Name = "btnResetGrpAddPassbkTabPassbkTbcMainFrmMain"
        Me.btnResetGrpAddPassbkTabPassbkTbcMainFrmMain.Size = New System.Drawing.Size(75, 23)
        Me.btnResetGrpAddPassbkTabPassbkTbcMainFrmMain.TabIndex = 3
        Me.btnResetGrpAddPassbkTabPassbkTbcMainFrmMain.Text = "&Reset"
        Me.tipTPMS.SetToolTip(Me.btnResetGrpAddPassbkTabPassbkTbcMainFrmMain, "Click to reset input fields")
        Me.btnResetGrpAddPassbkTabPassbkTbcMainFrmMain.UseVisualStyleBackColor = True
        '
        'btnSubmitGrpAddPassbkTabPassbkTbcMainFrmMain
        '
        Me.btnSubmitGrpAddPassbkTabPassbkTbcMainFrmMain.Location = New System.Drawing.Point(287, 345)
        Me.btnSubmitGrpAddPassbkTabPassbkTbcMainFrmMain.Name = "btnSubmitGrpAddPassbkTabPassbkTbcMainFrmMain"
        Me.btnSubmitGrpAddPassbkTabPassbkTbcMainFrmMain.Size = New System.Drawing.Size(75, 23)
        Me.btnSubmitGrpAddPassbkTabPassbkTbcMainFrmMain.TabIndex = 2
        Me.btnSubmitGrpAddPassbkTabPassbkTbcMainFrmMain.Text = "&Submit"
        Me.tipTPMS.SetToolTip(Me.btnSubmitGrpAddPassbkTabPassbkTbcMainFrmMain, "Click to validate and submit passbook purchase")
        Me.btnSubmitGrpAddPassbkTabPassbkTbcMainFrmMain.UseVisualStyleBackColor = True
        '
        'tabCustTbcMainFrmMain
        '
        Me.tabCustTbcMainFrmMain.BackColor = System.Drawing.Color.LightGray
        Me.tabCustTbcMainFrmMain.Controls.Add(Me.grpAddCustTabCustTbcMainFrmMain)
        Me.tabCustTbcMainFrmMain.Location = New System.Drawing.Point(4, 27)
        Me.tabCustTbcMainFrmMain.Margin = New System.Windows.Forms.Padding(4)
        Me.tabCustTbcMainFrmMain.Name = "tabCustTbcMainFrmMain"
        Me.tabCustTbcMainFrmMain.Padding = New System.Windows.Forms.Padding(4)
        Me.tabCustTbcMainFrmMain.Size = New System.Drawing.Size(919, 468)
        Me.tabCustTbcMainFrmMain.TabIndex = 0
        Me.tabCustTbcMainFrmMain.Text = "Customer"
        Me.tipTPMS.SetToolTip(Me.tabCustTbcMainFrmMain, "Add a new customer to the system")
        '
        'grpAddCustTabCustTbcMainFrmMain
        '
        Me.grpAddCustTabCustTbcMainFrmMain.BackColor = System.Drawing.Color.LightGray
        Me.grpAddCustTabCustTbcMainFrmMain.Controls.Add(Me.grpAnon6)
        Me.grpAddCustTabCustTbcMainFrmMain.Controls.Add(Me.btnResetGrpCustInfoTabCustTbcMainFrmMain)
        Me.grpAddCustTabCustTbcMainFrmMain.Controls.Add(Me.btnSubmitGrpCustInfoTabCustTbcMainFrmMain)
        Me.grpAddCustTabCustTbcMainFrmMain.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.grpAddCustTabCustTbcMainFrmMain.Location = New System.Drawing.Point(198, 68)
        Me.grpAddCustTabCustTbcMainFrmMain.Margin = New System.Windows.Forms.Padding(4)
        Me.grpAddCustTabCustTbcMainFrmMain.Name = "grpAddCustTabCustTbcMainFrmMain"
        Me.grpAddCustTabCustTbcMainFrmMain.Padding = New System.Windows.Forms.Padding(4)
        Me.grpAddCustTabCustTbcMainFrmMain.Size = New System.Drawing.Size(523, 339)
        Me.grpAddCustTabCustTbcMainFrmMain.TabIndex = 0
        Me.grpAddCustTabCustTbcMainFrmMain.TabStop = False
        Me.grpAddCustTabCustTbcMainFrmMain.Text = "Add New Customer"
        Me.tipTPMS.SetToolTip(Me.grpAddCustTabCustTbcMainFrmMain, "Enter customer specific information")
        '
        'grpAnon6
        '
        Me.grpAnon6.BackColor = System.Drawing.SystemColors.Control
        Me.grpAnon6.Controls.Add(Me.txtCustNameGrpAddCustTabCustTbcMainFrmMain)
        Me.grpAnon6.Controls.Add(Me.Label1)
        Me.grpAnon6.Controls.Add(Me.txtCustIdGrpAddCustTabCustTbcMainFrmMain)
        Me.grpAnon6.Controls.Add(Me.Label2)
        Me.grpAnon6.Location = New System.Drawing.Point(66, 50)
        Me.grpAnon6.Name = "grpAnon6"
        Me.grpAnon6.Size = New System.Drawing.Size(391, 118)
        Me.grpAnon6.TabIndex = 0
        Me.grpAnon6.TabStop = False
        '
        'txtCustNameGrpAddCustTabCustTbcMainFrmMain
        '
        Me.txtCustNameGrpAddCustTabCustTbcMainFrmMain.Location = New System.Drawing.Point(128, 65)
        Me.txtCustNameGrpAddCustTabCustTbcMainFrmMain.Name = "txtCustNameGrpAddCustTabCustTbcMainFrmMain"
        Me.txtCustNameGrpAddCustTabCustTbcMainFrmMain.Size = New System.Drawing.Size(249, 21)
        Me.txtCustNameGrpAddCustTabCustTbcMainFrmMain.TabIndex = 3
        Me.tipTPMS.SetToolTip(Me.txtCustNameGrpAddCustTabCustTbcMainFrmMain, "Enter customer name <LastName, FirstName>")
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(38, 34)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(78, 15)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Customer ID:"
        Me.tipTPMS.SetToolTip(Me.Label1, "Enter assigned customer ID")
        '
        'txtCustIdGrpAddCustTabCustTbcMainFrmMain
        '
        Me.txtCustIdGrpAddCustTabCustTbcMainFrmMain.Location = New System.Drawing.Point(128, 31)
        Me.txtCustIdGrpAddCustTabCustTbcMainFrmMain.Name = "txtCustIdGrpAddCustTabCustTbcMainFrmMain"
        Me.txtCustIdGrpAddCustTabCustTbcMainFrmMain.Size = New System.Drawing.Size(144, 21)
        Me.txtCustIdGrpAddCustTabCustTbcMainFrmMain.TabIndex = 1
        Me.tipTPMS.SetToolTip(Me.txtCustIdGrpAddCustTabCustTbcMainFrmMain, "Enter unique customer identifier")
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(14, 68)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(100, 15)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Customer Name:"
        '
        'btnResetGrpCustInfoTabCustTbcMainFrmMain
        '
        Me.btnResetGrpCustInfoTabCustTbcMainFrmMain.Location = New System.Drawing.Point(277, 288)
        Me.btnResetGrpCustInfoTabCustTbcMainFrmMain.Name = "btnResetGrpCustInfoTabCustTbcMainFrmMain"
        Me.btnResetGrpCustInfoTabCustTbcMainFrmMain.Size = New System.Drawing.Size(75, 23)
        Me.btnResetGrpCustInfoTabCustTbcMainFrmMain.TabIndex = 2
        Me.btnResetGrpCustInfoTabCustTbcMainFrmMain.Text = "&Reset"
        Me.tipTPMS.SetToolTip(Me.btnResetGrpCustInfoTabCustTbcMainFrmMain, "Click to reset input fields")
        Me.btnResetGrpCustInfoTabCustTbcMainFrmMain.UseVisualStyleBackColor = True
        '
        'btnSubmitGrpCustInfoTabCustTbcMainFrmMain
        '
        Me.btnSubmitGrpCustInfoTabCustTbcMainFrmMain.Location = New System.Drawing.Point(178, 288)
        Me.btnSubmitGrpCustInfoTabCustTbcMainFrmMain.Name = "btnSubmitGrpCustInfoTabCustTbcMainFrmMain"
        Me.btnSubmitGrpCustInfoTabCustTbcMainFrmMain.Size = New System.Drawing.Size(75, 23)
        Me.btnSubmitGrpCustInfoTabCustTbcMainFrmMain.TabIndex = 1
        Me.btnSubmitGrpCustInfoTabCustTbcMainFrmMain.Text = "&Submit"
        Me.tipTPMS.SetToolTip(Me.btnSubmitGrpCustInfoTabCustTbcMainFrmMain, "Click to validate and submit customer information")
        Me.btnSubmitGrpCustInfoTabCustTbcMainFrmMain.UseVisualStyleBackColor = True
        '
        'tbcMainFrmMain
        '
        Me.tbcMainFrmMain.Appearance = System.Windows.Forms.TabAppearance.Buttons
        Me.tbcMainFrmMain.Controls.Add(Me.tabDashTbcMainFrmMain)
        Me.tbcMainFrmMain.Controls.Add(Me.tabCustTbcMainFrmMain)
        Me.tbcMainFrmMain.Controls.Add(Me.tabFeatTbcMainFrmMain)
        Me.tbcMainFrmMain.Controls.Add(Me.tabPassbkTbcMainFrmMain)
        Me.tbcMainFrmMain.Controls.Add(Me.tabPassbkFeatTbcMainFrmMain)
        Me.tbcMainFrmMain.Controls.Add(Me.tabTransLogTbcMainFrmMain)
        Me.tbcMainFrmMain.Controls.Add(Me.tabSysTestTbcMainFrmMain)
        Me.tbcMainFrmMain.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbcMainFrmMain.Location = New System.Drawing.Point(43, 109)
        Me.tbcMainFrmMain.Margin = New System.Windows.Forms.Padding(4)
        Me.tbcMainFrmMain.Name = "tbcMainFrmMain"
        Me.tbcMainFrmMain.RightToLeftLayout = True
        Me.tbcMainFrmMain.SelectedIndex = 0
        Me.tbcMainFrmMain.Size = New System.Drawing.Size(927, 499)
        Me.tbcMainFrmMain.TabIndex = 2
        '
        'tabDashTbcMainFrmMain
        '
        Me.tabDashTbcMainFrmMain.BackColor = System.Drawing.Color.LightGray
        Me.tabDashTbcMainFrmMain.Controls.Add(Me.lstUsedFeatCntTabDashboardTbcMain)
        Me.tabDashTbcMainFrmMain.Controls.Add(Me.txtPassbkFeatCntTabDashboardTbcMain)
        Me.tabDashTbcMainFrmMain.Controls.Add(Me.txtPassbkCntTabDashboardTbcMain)
        Me.tabDashTbcMainFrmMain.Controls.Add(Me.txtFeatCntTabDashboardTbcMain)
        Me.tabDashTbcMainFrmMain.Controls.Add(Me.txtCustCntTabDashboardTbcMain)
        Me.tabDashTbcMainFrmMain.Controls.Add(Me.Label37)
        Me.tabDashTbcMainFrmMain.Controls.Add(Me.Label36)
        Me.tabDashTbcMainFrmMain.Controls.Add(Me.Label35)
        Me.tabDashTbcMainFrmMain.Controls.Add(Me.Label34)
        Me.tabDashTbcMainFrmMain.Controls.Add(Me.Label33)
        Me.tabDashTbcMainFrmMain.Controls.Add(Me.Label32)
        Me.tabDashTbcMainFrmMain.Controls.Add(Me.txtToStringTabDashboardTbcMain)
        Me.tabDashTbcMainFrmMain.Controls.Add(Me.lstUsedFeatTabDashboardTbcMain)
        Me.tabDashTbcMainFrmMain.Controls.Add(Me.lstPassbkFeatTabDashboardTbcMain)
        Me.tabDashTbcMainFrmMain.Controls.Add(Me.lstPassbkTabDashboardTbcMain)
        Me.tabDashTbcMainFrmMain.Controls.Add(Me.lstFeatTabDashboardTbcMain)
        Me.tabDashTbcMainFrmMain.Controls.Add(Me.lstCustTabDashboardTbcMain)
        Me.tabDashTbcMainFrmMain.Controls.Add(Me.Label31)
        Me.tabDashTbcMainFrmMain.Controls.Add(Me.Label30)
        Me.tabDashTbcMainFrmMain.Controls.Add(Me.Label29)
        Me.tabDashTbcMainFrmMain.Controls.Add(Me.Label28)
        Me.tabDashTbcMainFrmMain.Controls.Add(Me.Label27)
        Me.tabDashTbcMainFrmMain.Controls.Add(Me.grpKpiTabDashboardTbcMain)
        Me.tabDashTbcMainFrmMain.Location = New System.Drawing.Point(4, 27)
        Me.tabDashTbcMainFrmMain.Name = "tabDashTbcMainFrmMain"
        Me.tabDashTbcMainFrmMain.Padding = New System.Windows.Forms.Padding(3)
        Me.tabDashTbcMainFrmMain.Size = New System.Drawing.Size(919, 468)
        Me.tabDashTbcMainFrmMain.TabIndex = 5
        Me.tabDashTbcMainFrmMain.Text = "Dashboard"
        Me.tipTPMS.SetToolTip(Me.tabDashTbcMainFrmMain, "System dashboard")
        '
        'lstUsedFeatCntTabDashboardTbcMain
        '
        Me.lstUsedFeatCntTabDashboardTbcMain.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstUsedFeatCntTabDashboardTbcMain.Location = New System.Drawing.Point(563, 261)
        Me.lstUsedFeatCntTabDashboardTbcMain.Name = "lstUsedFeatCntTabDashboardTbcMain"
        Me.lstUsedFeatCntTabDashboardTbcMain.ReadOnly = True
        Me.lstUsedFeatCntTabDashboardTbcMain.Size = New System.Drawing.Size(57, 20)
        Me.lstUsedFeatCntTabDashboardTbcMain.TabIndex = 19
        Me.lstUsedFeatCntTabDashboardTbcMain.TabStop = False
        Me.tipTPMS.SetToolTip(Me.lstUsedFeatCntTabDashboardTbcMain, "Number of used features in the system")
        '
        'txtPassbkFeatCntTabDashboardTbcMain
        '
        Me.txtPassbkFeatCntTabDashboardTbcMain.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPassbkFeatCntTabDashboardTbcMain.Location = New System.Drawing.Point(439, 261)
        Me.txtPassbkFeatCntTabDashboardTbcMain.Name = "txtPassbkFeatCntTabDashboardTbcMain"
        Me.txtPassbkFeatCntTabDashboardTbcMain.ReadOnly = True
        Me.txtPassbkFeatCntTabDashboardTbcMain.Size = New System.Drawing.Size(57, 20)
        Me.txtPassbkFeatCntTabDashboardTbcMain.TabIndex = 15
        Me.txtPassbkFeatCntTabDashboardTbcMain.TabStop = False
        Me.tipTPMS.SetToolTip(Me.txtPassbkFeatCntTabDashboardTbcMain, "Number of passbook features in the system")
        '
        'txtPassbkCntTabDashboardTbcMain
        '
        Me.txtPassbkCntTabDashboardTbcMain.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPassbkCntTabDashboardTbcMain.Location = New System.Drawing.Point(317, 259)
        Me.txtPassbkCntTabDashboardTbcMain.Name = "txtPassbkCntTabDashboardTbcMain"
        Me.txtPassbkCntTabDashboardTbcMain.ReadOnly = True
        Me.txtPassbkCntTabDashboardTbcMain.Size = New System.Drawing.Size(57, 20)
        Me.txtPassbkCntTabDashboardTbcMain.TabIndex = 11
        Me.txtPassbkCntTabDashboardTbcMain.TabStop = False
        Me.tipTPMS.SetToolTip(Me.txtPassbkCntTabDashboardTbcMain, "Number of passbooks in the system")
        '
        'txtFeatCntTabDashboardTbcMain
        '
        Me.txtFeatCntTabDashboardTbcMain.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtFeatCntTabDashboardTbcMain.Location = New System.Drawing.Point(195, 259)
        Me.txtFeatCntTabDashboardTbcMain.Name = "txtFeatCntTabDashboardTbcMain"
        Me.txtFeatCntTabDashboardTbcMain.ReadOnly = True
        Me.txtFeatCntTabDashboardTbcMain.Size = New System.Drawing.Size(57, 20)
        Me.txtFeatCntTabDashboardTbcMain.TabIndex = 7
        Me.txtFeatCntTabDashboardTbcMain.TabStop = False
        Me.tipTPMS.SetToolTip(Me.txtFeatCntTabDashboardTbcMain, "Number of features in the system")
        '
        'txtCustCntTabDashboardTbcMain
        '
        Me.txtCustCntTabDashboardTbcMain.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCustCntTabDashboardTbcMain.Location = New System.Drawing.Point(76, 259)
        Me.txtCustCntTabDashboardTbcMain.Name = "txtCustCntTabDashboardTbcMain"
        Me.txtCustCntTabDashboardTbcMain.ReadOnly = True
        Me.txtCustCntTabDashboardTbcMain.Size = New System.Drawing.Size(57, 20)
        Me.txtCustCntTabDashboardTbcMain.TabIndex = 3
        Me.txtCustCntTabDashboardTbcMain.TabStop = False
        Me.tipTPMS.SetToolTip(Me.txtCustCntTabDashboardTbcMain, "Number of customers in the system")
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label37.Location = New System.Drawing.Point(519, 264)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(38, 13)
        Me.Label37.TabIndex = 18
        Me.Label37.Text = "Count:"
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label36.Location = New System.Drawing.Point(395, 264)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(38, 13)
        Me.Label36.TabIndex = 14
        Me.Label36.Text = "Count:"
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label35.Location = New System.Drawing.Point(273, 264)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(38, 13)
        Me.Label35.TabIndex = 10
        Me.Label35.Text = "Count:"
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label34.Location = New System.Drawing.Point(151, 264)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(38, 13)
        Me.Label34.TabIndex = 6
        Me.Label34.Text = "Count:"
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label33.Location = New System.Drawing.Point(32, 264)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(38, 13)
        Me.Label33.TabIndex = 2
        Me.Label33.Text = "Count:"
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Location = New System.Drawing.Point(647, 25)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(118, 15)
        Me.Label32.TabIndex = 20
        Me.Label32.Text = "ToString Information"
        '
        'txtToStringTabDashboardTbcMain
        '
        Me.txtToStringTabDashboardTbcMain.BackColor = System.Drawing.SystemColors.ControlLight
        Me.txtToStringTabDashboardTbcMain.Location = New System.Drawing.Point(650, 44)
        Me.txtToStringTabDashboardTbcMain.Multiline = True
        Me.txtToStringTabDashboardTbcMain.Name = "txtToStringTabDashboardTbcMain"
        Me.txtToStringTabDashboardTbcMain.ReadOnly = True
        Me.txtToStringTabDashboardTbcMain.Size = New System.Drawing.Size(235, 99)
        Me.txtToStringTabDashboardTbcMain.TabIndex = 21
        Me.txtToStringTabDashboardTbcMain.TabStop = False
        Me.tipTPMS.SetToolTip(Me.txtToStringTabDashboardTbcMain, "Display of specific information of current selected item")
        '
        'lstUsedFeatTabDashboardTbcMain
        '
        Me.lstUsedFeatTabDashboardTbcMain.FormattingEnabled = True
        Me.lstUsedFeatTabDashboardTbcMain.ItemHeight = 15
        Me.lstUsedFeatTabDashboardTbcMain.Location = New System.Drawing.Point(517, 44)
        Me.lstUsedFeatTabDashboardTbcMain.Name = "lstUsedFeatTabDashboardTbcMain"
        Me.lstUsedFeatTabDashboardTbcMain.Size = New System.Drawing.Size(103, 199)
        Me.lstUsedFeatTabDashboardTbcMain.TabIndex = 17
        Me.lstUsedFeatTabDashboardTbcMain.TabStop = False
        Me.tipTPMS.SetToolTip(Me.lstUsedFeatTabDashboardTbcMain, "System used feature list")
        '
        'lstPassbkFeatTabDashboardTbcMain
        '
        Me.lstPassbkFeatTabDashboardTbcMain.FormattingEnabled = True
        Me.lstPassbkFeatTabDashboardTbcMain.ItemHeight = 15
        Me.lstPassbkFeatTabDashboardTbcMain.Location = New System.Drawing.Point(393, 44)
        Me.lstPassbkFeatTabDashboardTbcMain.Name = "lstPassbkFeatTabDashboardTbcMain"
        Me.lstPassbkFeatTabDashboardTbcMain.Size = New System.Drawing.Size(103, 199)
        Me.lstPassbkFeatTabDashboardTbcMain.TabIndex = 13
        Me.lstPassbkFeatTabDashboardTbcMain.TabStop = False
        Me.tipTPMS.SetToolTip(Me.lstPassbkFeatTabDashboardTbcMain, "System passbook feature list")
        '
        'lstPassbkTabDashboardTbcMain
        '
        Me.lstPassbkTabDashboardTbcMain.FormattingEnabled = True
        Me.lstPassbkTabDashboardTbcMain.ItemHeight = 15
        Me.lstPassbkTabDashboardTbcMain.Location = New System.Drawing.Point(271, 44)
        Me.lstPassbkTabDashboardTbcMain.Name = "lstPassbkTabDashboardTbcMain"
        Me.lstPassbkTabDashboardTbcMain.Size = New System.Drawing.Size(103, 199)
        Me.lstPassbkTabDashboardTbcMain.TabIndex = 9
        Me.lstPassbkTabDashboardTbcMain.TabStop = False
        Me.tipTPMS.SetToolTip(Me.lstPassbkTabDashboardTbcMain, "System passbook list")
        '
        'lstFeatTabDashboardTbcMain
        '
        Me.lstFeatTabDashboardTbcMain.FormattingEnabled = True
        Me.lstFeatTabDashboardTbcMain.ItemHeight = 15
        Me.lstFeatTabDashboardTbcMain.Location = New System.Drawing.Point(149, 44)
        Me.lstFeatTabDashboardTbcMain.Name = "lstFeatTabDashboardTbcMain"
        Me.lstFeatTabDashboardTbcMain.Size = New System.Drawing.Size(103, 199)
        Me.lstFeatTabDashboardTbcMain.TabIndex = 5
        Me.lstFeatTabDashboardTbcMain.TabStop = False
        Me.tipTPMS.SetToolTip(Me.lstFeatTabDashboardTbcMain, "System feature list")
        '
        'lstCustTabDashboardTbcMain
        '
        Me.lstCustTabDashboardTbcMain.FormattingEnabled = True
        Me.lstCustTabDashboardTbcMain.ItemHeight = 15
        Me.lstCustTabDashboardTbcMain.Location = New System.Drawing.Point(30, 44)
        Me.lstCustTabDashboardTbcMain.Name = "lstCustTabDashboardTbcMain"
        Me.lstCustTabDashboardTbcMain.Size = New System.Drawing.Size(103, 199)
        Me.lstCustTabDashboardTbcMain.TabIndex = 1
        Me.lstCustTabDashboardTbcMain.TabStop = False
        Me.tipTPMS.SetToolTip(Me.lstCustTabDashboardTbcMain, "System customer list")
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Location = New System.Drawing.Point(514, 9)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(71, 30)
        Me.Label31.TabIndex = 16
        Me.Label31.Text = "Used" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Feature List" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Location = New System.Drawing.Point(390, 9)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(71, 30)
        Me.Label30.TabIndex = 12
        Me.Label30.Text = "Passbook" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Feature List" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Location = New System.Drawing.Point(268, 25)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(83, 15)
        Me.Label29.TabIndex = 8
        Me.Label29.Text = "Passbook List"
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Location = New System.Drawing.Point(146, 25)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(71, 15)
        Me.Label28.TabIndex = 4
        Me.Label28.Text = "Feature List"
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Location = New System.Drawing.Point(27, 25)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(82, 15)
        Me.Label27.TabIndex = 0
        Me.Label27.Text = "Customer List"
        '
        'grpKpiTabDashboardTbcMain
        '
        Me.grpKpiTabDashboardTbcMain.BackColor = System.Drawing.SystemColors.ControlLight
        Me.grpKpiTabDashboardTbcMain.Location = New System.Drawing.Point(35, 305)
        Me.grpKpiTabDashboardTbcMain.Name = "grpKpiTabDashboardTbcMain"
        Me.grpKpiTabDashboardTbcMain.Size = New System.Drawing.Size(850, 122)
        Me.grpKpiTabDashboardTbcMain.TabIndex = 22
        Me.grpKpiTabDashboardTbcMain.TabStop = False
        Me.grpKpiTabDashboardTbcMain.Text = "Key Performance Indicators"
        Me.tipTPMS.SetToolTip(Me.grpKpiTabDashboardTbcMain, "Displays system wide key performance indicators")
        '
        'tabFeatTbcMainFrmMain
        '
        Me.tabFeatTbcMainFrmMain.BackColor = System.Drawing.Color.LightGray
        Me.tabFeatTbcMainFrmMain.Controls.Add(Me.grpAddFeatTabFeatTbcMainFrmMain)
        Me.tabFeatTbcMainFrmMain.Location = New System.Drawing.Point(4, 27)
        Me.tabFeatTbcMainFrmMain.Name = "tabFeatTbcMainFrmMain"
        Me.tabFeatTbcMainFrmMain.Padding = New System.Windows.Forms.Padding(3)
        Me.tabFeatTbcMainFrmMain.Size = New System.Drawing.Size(919, 468)
        Me.tabFeatTbcMainFrmMain.TabIndex = 7
        Me.tabFeatTbcMainFrmMain.Text = "Feature"
        Me.tipTPMS.SetToolTip(Me.tabFeatTbcMainFrmMain, "Add a new feature to the system")
        '
        'grpAddFeatTabFeatTbcMainFrmMain
        '
        Me.grpAddFeatTabFeatTbcMainFrmMain.BackColor = System.Drawing.Color.LightGray
        Me.grpAddFeatTabFeatTbcMainFrmMain.Controls.Add(Me.grpAnon7)
        Me.grpAddFeatTabFeatTbcMainFrmMain.Controls.Add(Me.btnResetGrpAddFeatTabFeatTbcMainFrmMain)
        Me.grpAddFeatTabFeatTbcMainFrmMain.Controls.Add(Me.btnSubmitGrpAddFeatTabFeatTbcMainFrmMain)
        Me.grpAddFeatTabFeatTbcMainFrmMain.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.grpAddFeatTabFeatTbcMainFrmMain.Location = New System.Drawing.Point(198, 68)
        Me.grpAddFeatTabFeatTbcMainFrmMain.Margin = New System.Windows.Forms.Padding(4)
        Me.grpAddFeatTabFeatTbcMainFrmMain.Name = "grpAddFeatTabFeatTbcMainFrmMain"
        Me.grpAddFeatTabFeatTbcMainFrmMain.Padding = New System.Windows.Forms.Padding(4)
        Me.grpAddFeatTabFeatTbcMainFrmMain.Size = New System.Drawing.Size(523, 339)
        Me.grpAddFeatTabFeatTbcMainFrmMain.TabIndex = 1
        Me.grpAddFeatTabFeatTbcMainFrmMain.TabStop = False
        Me.grpAddFeatTabFeatTbcMainFrmMain.Text = "Add New Feature"
        Me.tipTPMS.SetToolTip(Me.grpAddFeatTabFeatTbcMainFrmMain, "Enter feature specific information")
        '
        'grpAnon7
        '
        Me.grpAnon7.BackColor = System.Drawing.SystemColors.Control
        Me.grpAnon7.Controls.Add(Me.txtPriceChildGrpAddFeatTabFeatTbcMainFrmMain)
        Me.grpAnon7.Controls.Add(Me.Label39)
        Me.grpAnon7.Controls.Add(Me.txtPriceAdultGrpAddFeatTabFeatTbcMainFrmMain)
        Me.grpAnon7.Controls.Add(Me.txtUnifOfMeasGrpAddFeatTabFeatTbcMainFrmMain)
        Me.grpAnon7.Controls.Add(Me.Label40)
        Me.grpAnon7.Controls.Add(Me.txtFeatNameGrpAddFeatTabFeatTbcMainFrmMain)
        Me.grpAnon7.Controls.Add(Me.Label41)
        Me.grpAnon7.Controls.Add(Me.txtFeatIdAddFeatTabFeatTbcMainFrmMain)
        Me.grpAnon7.Controls.Add(Me.Label42)
        Me.grpAnon7.Controls.Add(Me.Label43)
        Me.grpAnon7.Location = New System.Drawing.Point(51, 32)
        Me.grpAnon7.Name = "grpAnon7"
        Me.grpAnon7.Size = New System.Drawing.Size(420, 239)
        Me.grpAnon7.TabIndex = 2
        Me.grpAnon7.TabStop = False
        '
        'txtPriceChildGrpAddFeatTabFeatTbcMainFrmMain
        '
        Me.txtPriceChildGrpAddFeatTabFeatTbcMainFrmMain.Location = New System.Drawing.Point(144, 183)
        Me.txtPriceChildGrpAddFeatTabFeatTbcMainFrmMain.Name = "txtPriceChildGrpAddFeatTabFeatTbcMainFrmMain"
        Me.txtPriceChildGrpAddFeatTabFeatTbcMainFrmMain.Size = New System.Drawing.Size(166, 21)
        Me.txtPriceChildGrpAddFeatTabFeatTbcMainFrmMain.TabIndex = 19
        Me.tipTPMS.SetToolTip(Me.txtPriceChildGrpAddFeatTabFeatTbcMainFrmMain, "Enter feature cost for a child ")
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Location = New System.Drawing.Point(24, 186)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(101, 15)
        Me.Label39.TabIndex = 18
        Me.Label39.Text = "Price (Child < 13)"
        '
        'txtPriceAdultGrpAddFeatTabFeatTbcMainFrmMain
        '
        Me.txtPriceAdultGrpAddFeatTabFeatTbcMainFrmMain.Location = New System.Drawing.Point(144, 143)
        Me.txtPriceAdultGrpAddFeatTabFeatTbcMainFrmMain.Name = "txtPriceAdultGrpAddFeatTabFeatTbcMainFrmMain"
        Me.txtPriceAdultGrpAddFeatTabFeatTbcMainFrmMain.Size = New System.Drawing.Size(166, 21)
        Me.txtPriceAdultGrpAddFeatTabFeatTbcMainFrmMain.TabIndex = 17
        Me.tipTPMS.SetToolTip(Me.txtPriceAdultGrpAddFeatTabFeatTbcMainFrmMain, "Enter feature cost fo an adult")
        '
        'txtUnifOfMeasGrpAddFeatTabFeatTbcMainFrmMain
        '
        Me.txtUnifOfMeasGrpAddFeatTabFeatTbcMainFrmMain.Location = New System.Drawing.Point(144, 105)
        Me.txtUnifOfMeasGrpAddFeatTabFeatTbcMainFrmMain.Name = "txtUnifOfMeasGrpAddFeatTabFeatTbcMainFrmMain"
        Me.txtUnifOfMeasGrpAddFeatTabFeatTbcMainFrmMain.Size = New System.Drawing.Size(166, 21)
        Me.txtUnifOfMeasGrpAddFeatTabFeatTbcMainFrmMain.TabIndex = 15
        Me.tipTPMS.SetToolTip(Me.txtUnifOfMeasGrpAddFeatTabFeatTbcMainFrmMain, "Enter feature unit of measure (e.g ""Day"" for Parking Pass)")
        '
        'Label40
        '
        Me.Label40.AutoSize = True
        Me.Label40.Location = New System.Drawing.Point(34, 108)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(97, 15)
        Me.Label40.TabIndex = 14
        Me.Label40.Text = "Unit of Measure:"
        '
        'txtFeatNameGrpAddFeatTabFeatTbcMainFrmMain
        '
        Me.txtFeatNameGrpAddFeatTabFeatTbcMainFrmMain.Location = New System.Drawing.Point(144, 68)
        Me.txtFeatNameGrpAddFeatTabFeatTbcMainFrmMain.Name = "txtFeatNameGrpAddFeatTabFeatTbcMainFrmMain"
        Me.txtFeatNameGrpAddFeatTabFeatTbcMainFrmMain.Size = New System.Drawing.Size(253, 21)
        Me.txtFeatNameGrpAddFeatTabFeatTbcMainFrmMain.TabIndex = 13
        Me.tipTPMS.SetToolTip(Me.txtFeatNameGrpAddFeatTabFeatTbcMainFrmMain, "Enter Feature name (e.g Meal Plan)")
        '
        'Label41
        '
        Me.Label41.AutoSize = True
        Me.Label41.Location = New System.Drawing.Point(62, 37)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(70, 15)
        Me.Label41.TabIndex = 10
        Me.Label41.Text = "Feature ID: "
        '
        'txtFeatIdAddFeatTabFeatTbcMainFrmMain
        '
        Me.txtFeatIdAddFeatTabFeatTbcMainFrmMain.Location = New System.Drawing.Point(144, 34)
        Me.txtFeatIdAddFeatTabFeatTbcMainFrmMain.Name = "txtFeatIdAddFeatTabFeatTbcMainFrmMain"
        Me.txtFeatIdAddFeatTabFeatTbcMainFrmMain.Size = New System.Drawing.Size(136, 21)
        Me.txtFeatIdAddFeatTabFeatTbcMainFrmMain.TabIndex = 11
        Me.tipTPMS.SetToolTip(Me.txtFeatIdAddFeatTabFeatTbcMainFrmMain, "Enter a unique feature identifier")
        '
        'Label42
        '
        Me.Label42.AutoSize = True
        Me.Label42.Location = New System.Drawing.Point(51, 146)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(73, 15)
        Me.Label42.TabIndex = 16
        Me.Label42.Text = "Price (Adult)"
        '
        'Label43
        '
        Me.Label43.AutoSize = True
        Me.Label43.Location = New System.Drawing.Point(41, 71)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(89, 15)
        Me.Label43.TabIndex = 12
        Me.Label43.Text = "Feature Name:"
        '
        'btnResetGrpAddFeatTabFeatTbcMainFrmMain
        '
        Me.btnResetGrpAddFeatTabFeatTbcMainFrmMain.Location = New System.Drawing.Point(273, 288)
        Me.btnResetGrpAddFeatTabFeatTbcMainFrmMain.Name = "btnResetGrpAddFeatTabFeatTbcMainFrmMain"
        Me.btnResetGrpAddFeatTabFeatTbcMainFrmMain.Size = New System.Drawing.Size(75, 23)
        Me.btnResetGrpAddFeatTabFeatTbcMainFrmMain.TabIndex = 11
        Me.btnResetGrpAddFeatTabFeatTbcMainFrmMain.Text = "&Reset"
        Me.tipTPMS.SetToolTip(Me.btnResetGrpAddFeatTabFeatTbcMainFrmMain, "Click to reset input fields")
        Me.btnResetGrpAddFeatTabFeatTbcMainFrmMain.UseVisualStyleBackColor = True
        '
        'btnSubmitGrpAddFeatTabFeatTbcMainFrmMain
        '
        Me.btnSubmitGrpAddFeatTabFeatTbcMainFrmMain.Location = New System.Drawing.Point(178, 288)
        Me.btnSubmitGrpAddFeatTabFeatTbcMainFrmMain.Name = "btnSubmitGrpAddFeatTabFeatTbcMainFrmMain"
        Me.btnSubmitGrpAddFeatTabFeatTbcMainFrmMain.Size = New System.Drawing.Size(75, 23)
        Me.btnSubmitGrpAddFeatTabFeatTbcMainFrmMain.TabIndex = 10
        Me.btnSubmitGrpAddFeatTabFeatTbcMainFrmMain.Text = "&Submit"
        Me.tipTPMS.SetToolTip(Me.btnSubmitGrpAddFeatTabFeatTbcMainFrmMain, "Click to validate and submit customer information")
        Me.btnSubmitGrpAddFeatTabFeatTbcMainFrmMain.UseVisualStyleBackColor = True
        '
        'tabTransLogTbcMainFrmMain
        '
        Me.tabTransLogTbcMainFrmMain.BackColor = System.Drawing.Color.LightGray
        Me.tabTransLogTbcMainFrmMain.Controls.Add(Me.btnClearTabTransLogTbcMainFrmMain)
        Me.tabTransLogTbcMainFrmMain.Controls.Add(Me.grpTransLogTabTransLogTbcMain)
        Me.tabTransLogTbcMainFrmMain.Location = New System.Drawing.Point(4, 27)
        Me.tabTransLogTbcMainFrmMain.Name = "tabTransLogTbcMainFrmMain"
        Me.tabTransLogTbcMainFrmMain.Padding = New System.Windows.Forms.Padding(3)
        Me.tabTransLogTbcMainFrmMain.Size = New System.Drawing.Size(919, 468)
        Me.tabTransLogTbcMainFrmMain.TabIndex = 4
        Me.tabTransLogTbcMainFrmMain.Text = "Transaction Log"
        Me.tipTPMS.SetToolTip(Me.tabTransLogTbcMainFrmMain, "View system transaction log")
        '
        'btnClearTabTransLogTbcMainFrmMain
        '
        Me.btnClearTabTransLogTbcMainFrmMain.Location = New System.Drawing.Point(422, 423)
        Me.btnClearTabTransLogTbcMainFrmMain.Name = "btnClearTabTransLogTbcMainFrmMain"
        Me.btnClearTabTransLogTbcMainFrmMain.Size = New System.Drawing.Size(75, 23)
        Me.btnClearTabTransLogTbcMainFrmMain.TabIndex = 1
        Me.btnClearTabTransLogTbcMainFrmMain.Text = "&Clear"
        Me.tipTPMS.SetToolTip(Me.btnClearTabTransLogTbcMainFrmMain, "Click to Clear transaction log")
        Me.btnClearTabTransLogTbcMainFrmMain.UseVisualStyleBackColor = True
        '
        'grpTransLogTabTransLogTbcMain
        '
        Me.grpTransLogTabTransLogTbcMain.Controls.Add(Me.txtTransLogTabTransLogTbcMainFrmMain)
        Me.grpTransLogTabTransLogTbcMain.Location = New System.Drawing.Point(6, 20)
        Me.grpTransLogTabTransLogTbcMain.Name = "grpTransLogTabTransLogTbcMain"
        Me.grpTransLogTabTransLogTbcMain.Size = New System.Drawing.Size(907, 387)
        Me.grpTransLogTabTransLogTbcMain.TabIndex = 0
        Me.grpTransLogTabTransLogTbcMain.TabStop = False
        Me.grpTransLogTabTransLogTbcMain.Text = "System Transaction Log"
        Me.tipTPMS.SetToolTip(Me.grpTransLogTabTransLogTbcMain, "View the system transaction log")
        '
        'txtTransLogTabTransLogTbcMainFrmMain
        '
        Me.txtTransLogTabTransLogTbcMainFrmMain.BackColor = System.Drawing.SystemColors.Control
        Me.txtTransLogTabTransLogTbcMainFrmMain.Location = New System.Drawing.Point(6, 21)
        Me.txtTransLogTabTransLogTbcMainFrmMain.Multiline = True
        Me.txtTransLogTabTransLogTbcMainFrmMain.Name = "txtTransLogTabTransLogTbcMainFrmMain"
        Me.txtTransLogTabTransLogTbcMainFrmMain.ReadOnly = True
        Me.txtTransLogTabTransLogTbcMainFrmMain.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtTransLogTabTransLogTbcMainFrmMain.Size = New System.Drawing.Size(895, 360)
        Me.txtTransLogTabTransLogTbcMainFrmMain.TabIndex = 0
        Me.txtTransLogTabTransLogTbcMainFrmMain.TabStop = False
        Me.tipTPMS.SetToolTip(Me.txtTransLogTabTransLogTbcMainFrmMain, "Displays current system transaction log")
        '
        'tabSysTestTbcMainFrmMain
        '
        Me.tabSysTestTbcMainFrmMain.BackColor = System.Drawing.Color.LightGray
        Me.tabSysTestTbcMainFrmMain.Controls.Add(Me.grpSysTestTabSysTestTbcMainFrmMain)
        Me.tabSysTestTbcMainFrmMain.Location = New System.Drawing.Point(4, 27)
        Me.tabSysTestTbcMainFrmMain.Name = "tabSysTestTbcMainFrmMain"
        Me.tabSysTestTbcMainFrmMain.Padding = New System.Windows.Forms.Padding(3)
        Me.tabSysTestTbcMainFrmMain.Size = New System.Drawing.Size(919, 468)
        Me.tabSysTestTbcMainFrmMain.TabIndex = 6
        Me.tabSysTestTbcMainFrmMain.Text = "System Test"
        Me.tipTPMS.SetToolTip(Me.tabSysTestTbcMainFrmMain, "Exercise the system with sample test data")
        '
        'grpSysTestTabSysTestTbcMainFrmMain
        '
        Me.grpSysTestTabSysTestTbcMainFrmMain.BackColor = System.Drawing.Color.LightGray
        Me.grpSysTestTabSysTestTbcMainFrmMain.Controls.Add(Me.chkUseTestParkGrpSysTestTabSysTestTbcMainFrmMain)
        Me.grpSysTestTabSysTestTbcMainFrmMain.Controls.Add(Me.grpAnon5)
        Me.grpSysTestTabSysTestTbcMainFrmMain.Controls.Add(Me.btnProcTestDataGrpSysTestTabSysTestTbcMainFrmMain)
        Me.grpSysTestTabSysTestTbcMainFrmMain.Location = New System.Drawing.Point(215, 41)
        Me.grpSysTestTabSysTestTbcMainFrmMain.Name = "grpSysTestTabSysTestTbcMainFrmMain"
        Me.grpSysTestTabSysTestTbcMainFrmMain.Size = New System.Drawing.Size(489, 239)
        Me.grpSysTestTabSysTestTbcMainFrmMain.TabIndex = 0
        Me.grpSysTestTabSysTestTbcMainFrmMain.TabStop = False
        Me.grpSysTestTabSysTestTbcMainFrmMain.Text = "System Test"
        '
        'chkUseTestParkGrpSysTestTabSysTestTbcMainFrmMain
        '
        Me.chkUseTestParkGrpSysTestTabSysTestTbcMainFrmMain.AutoSize = True
        Me.chkUseTestParkGrpSysTestTabSysTestTbcMainFrmMain.Location = New System.Drawing.Point(231, 52)
        Me.chkUseTestParkGrpSysTestTabSysTestTbcMainFrmMain.Name = "chkUseTestParkGrpSysTestTabSysTestTbcMainFrmMain"
        Me.chkUseTestParkGrpSysTestTabSysTestTbcMainFrmMain.Size = New System.Drawing.Size(202, 19)
        Me.chkUseTestParkGrpSysTestTabSysTestTbcMainFrmMain.TabIndex = 1
        Me.chkUseTestParkGrpSysTestTabSysTestTbcMainFrmMain.Text = "Use Temporary Test Park Object"
        Me.tipTPMS.SetToolTip(Me.chkUseTestParkGrpSysTestTabSysTestTbcMainFrmMain, "If checked will use an internal tempory theme park object to test with")
        Me.chkUseTestParkGrpSysTestTabSysTestTbcMainFrmMain.UseVisualStyleBackColor = True
        '
        'grpAnon5
        '
        Me.grpAnon5.BackColor = System.Drawing.SystemColors.Control
        Me.grpAnon5.Controls.Add(Me.btnWriteFileGrpSysTestTabSysTestTbcMainFrmMain)
        Me.grpAnon5.Controls.Add(Me.chkAppendTabSysTestTbcMainFrmMain)
        Me.grpAnon5.Controls.Add(Me.btnReadFileTabSysTestTbcMainFrmMain)
        Me.grpAnon5.Enabled = False
        Me.grpAnon5.Location = New System.Drawing.Point(58, 89)
        Me.grpAnon5.Name = "grpAnon5"
        Me.grpAnon5.Size = New System.Drawing.Size(344, 92)
        Me.grpAnon5.TabIndex = 2
        Me.grpAnon5.TabStop = False
        '
        'btnWriteFileGrpSysTestTabSysTestTbcMainFrmMain
        '
        Me.btnWriteFileGrpSysTestTabSysTestTbcMainFrmMain.Location = New System.Drawing.Point(22, 50)
        Me.btnWriteFileGrpSysTestTabSysTestTbcMainFrmMain.Name = "btnWriteFileGrpSysTestTabSysTestTbcMainFrmMain"
        Me.btnWriteFileGrpSysTestTabSysTestTbcMainFrmMain.Size = New System.Drawing.Size(75, 23)
        Me.btnWriteFileGrpSysTestTabSysTestTbcMainFrmMain.TabIndex = 1
        Me.btnWriteFileGrpSysTestTabSysTestTbcMainFrmMain.Text = "&Write File"
        Me.btnWriteFileGrpSysTestTabSysTestTbcMainFrmMain.UseVisualStyleBackColor = True
        '
        'chkAppendTabSysTestTbcMainFrmMain
        '
        Me.chkAppendTabSysTestTbcMainFrmMain.AutoSize = True
        Me.chkAppendTabSysTestTbcMainFrmMain.Location = New System.Drawing.Point(115, 52)
        Me.chkAppendTabSysTestTbcMainFrmMain.Name = "chkAppendTabSysTestTbcMainFrmMain"
        Me.chkAppendTabSysTestTbcMainFrmMain.Size = New System.Drawing.Size(187, 19)
        Me.chkAppendTabSysTestTbcMainFrmMain.TabIndex = 2
        Me.chkAppendTabSysTestTbcMainFrmMain.Text = "Check to Append output to file"
        Me.tipTPMS.SetToolTip(Me.chkAppendTabSysTestTbcMainFrmMain, "Check this box to append output data to file")
        Me.chkAppendTabSysTestTbcMainFrmMain.UseVisualStyleBackColor = True
        '
        'btnReadFileTabSysTestTbcMainFrmMain
        '
        Me.btnReadFileTabSysTestTbcMainFrmMain.Location = New System.Drawing.Point(22, 21)
        Me.btnReadFileTabSysTestTbcMainFrmMain.Name = "btnReadFileTabSysTestTbcMainFrmMain"
        Me.btnReadFileTabSysTestTbcMainFrmMain.Size = New System.Drawing.Size(75, 23)
        Me.btnReadFileTabSysTestTbcMainFrmMain.TabIndex = 0
        Me.btnReadFileTabSysTestTbcMainFrmMain.Text = "&Read File"
        Me.btnReadFileTabSysTestTbcMainFrmMain.UseVisualStyleBackColor = True
        '
        'btnProcTestDataGrpSysTestTabSysTestTbcMainFrmMain
        '
        Me.btnProcTestDataGrpSysTestTabSysTestTbcMainFrmMain.Location = New System.Drawing.Point(58, 47)
        Me.btnProcTestDataGrpSysTestTabSysTestTbcMainFrmMain.Name = "btnProcTestDataGrpSysTestTabSysTestTbcMainFrmMain"
        Me.btnProcTestDataGrpSysTestTabSysTestTbcMainFrmMain.Size = New System.Drawing.Size(149, 27)
        Me.btnProcTestDataGrpSysTestTabSysTestTbcMainFrmMain.TabIndex = 0
        Me.btnProcTestDataGrpSysTestTabSysTestTbcMainFrmMain.Text = "Process &Test Data"
        Me.tipTPMS.SetToolTip(Me.btnProcTestDataGrpSysTestTabSysTestTbcMainFrmMain, "Click to enable automated testing")
        Me.btnProcTestDataGrpSysTestTabSysTestTbcMainFrmMain.UseVisualStyleBackColor = True
        '
        'btnExitFrmMain
        '
        Me.btnExitFrmMain.BackColor = System.Drawing.Color.Transparent
        Me.btnExitFrmMain.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExitFrmMain.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.btnExitFrmMain.Location = New System.Drawing.Point(457, 635)
        Me.btnExitFrmMain.Name = "btnExitFrmMain"
        Me.btnExitFrmMain.Size = New System.Drawing.Size(99, 30)
        Me.btnExitFrmMain.TabIndex = 3
        Me.btnExitFrmMain.Text = "E&xit"
        Me.btnExitFrmMain.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage
        Me.tipTPMS.SetToolTip(Me.btnExitFrmMain, "Click to Exit and shutdown the system")
        Me.btnExitFrmMain.UseVisualStyleBackColor = False
        '
        'tipTPMS
        '
        Me.tipTPMS.AutomaticDelay = 300
        '
        'btnAddGrpCustInfoTcbMain
        '
        Me.btnAddGrpCustInfoTcbMain.Location = New System.Drawing.Point(178, 288)
        Me.btnAddGrpCustInfoTcbMain.Name = "btnAddGrpCustInfoTcbMain"
        Me.btnAddGrpCustInfoTcbMain.Size = New System.Drawing.Size(75, 23)
        Me.btnAddGrpCustInfoTcbMain.TabIndex = 4
        Me.btnAddGrpCustInfoTcbMain.Text = "&Add"
        Me.tipTPMS.SetToolTip(Me.btnAddGrpCustInfoTcbMain, "Click to validate and submit customer information")
        Me.btnAddGrpCustInfoTcbMain.UseVisualStyleBackColor = True
        '
        'btnResetGrpCustInfoTcbMain
        '
        Me.btnResetGrpCustInfoTcbMain.Location = New System.Drawing.Point(273, 288)
        Me.btnResetGrpCustInfoTcbMain.Name = "btnResetGrpCustInfoTcbMain"
        Me.btnResetGrpCustInfoTcbMain.Size = New System.Drawing.Size(75, 23)
        Me.btnResetGrpCustInfoTcbMain.TabIndex = 5
        Me.btnResetGrpCustInfoTcbMain.Text = "&Reset"
        Me.tipTPMS.SetToolTip(Me.btnResetGrpCustInfoTcbMain, "Click to reset input fields")
        Me.btnResetGrpCustInfoTcbMain.UseVisualStyleBackColor = True
        '
        'ListBox2
        '
        Me.ListBox2.FormattingEnabled = True
        Me.ListBox2.Items.AddRange(New Object() {"Park Pass", "Parking Lot Pass", "Meal Plan", "Early Entry Pass"})
        Me.ListBox2.Location = New System.Drawing.Point(154, 68)
        Me.ListBox2.Name = "ListBox2"
        Me.ListBox2.Size = New System.Drawing.Size(236, 17)
        Me.ListBox2.TabIndex = 3
        Me.tipTPMS.SetToolTip(Me.ListBox2, "Select the desired feature from the list")
        '
        'ListBox1
        '
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.Items.AddRange(New Object() {"Passbook 1", "Passbook 2", "Passbook 3", "Passbook 4"})
        Me.ListBox1.Location = New System.Drawing.Point(154, 103)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple
        Me.ListBox1.Size = New System.Drawing.Size(236, 17)
        Me.ListBox1.TabIndex = 5
        Me.tipTPMS.SetToolTip(Me.ListBox1, "Select the desired passbook from the list")
        '
        'NumericUpDown3
        '
        Me.NumericUpDown3.Location = New System.Drawing.Point(154, 141)
        Me.NumericUpDown3.Name = "NumericUpDown3"
        Me.NumericUpDown3.Size = New System.Drawing.Size(70, 20)
        Me.NumericUpDown3.TabIndex = 7
        Me.tipTPMS.SetToolTip(Me.NumericUpDown3, "Enter the feature quantity to purchase")
        Me.NumericUpDown3.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'Button5
        '
        Me.Button5.Location = New System.Drawing.Point(178, 288)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(75, 23)
        Me.Button5.TabIndex = 9
        Me.Button5.Text = "&Submit"
        Me.tipTPMS.SetToolTip(Me.Button5, "Click to validate and submit feature purchase")
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(273, 288)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 10
        Me.Button1.Text = "&Reset"
        Me.tipTPMS.SetToolTip(Me.Button1, "Click to reset all input fields")
        Me.Button1.UseVisualStyleBackColor = True
        '
        'lblCustIdTabAddCustTbcCustomerMainTabCustomerTbcMain
        '
        Me.lblCustIdTabAddCustTbcCustomerMainTabCustomerTbcMain.AutoSize = True
        Me.lblCustIdTabAddCustTbcCustomerMainTabCustomerTbcMain.Location = New System.Drawing.Point(104, 63)
        Me.lblCustIdTabAddCustTbcCustomerMainTabCustomerTbcMain.Name = "lblCustIdTabAddCustTbcCustomerMainTabCustomerTbcMain"
        Me.lblCustIdTabAddCustTbcCustomerMainTabCustomerTbcMain.Size = New System.Drawing.Size(84, 16)
        Me.lblCustIdTabAddCustTbcCustomerMainTabCustomerTbcMain.TabIndex = 0
        '
        'lblCustNameTabAddCustTbcCustomerMainTabCustomerTbcMain
        '
        Me.lblCustNameTabAddCustTbcCustomerMainTabCustomerTbcMain.AutoSize = True
        Me.lblCustNameTabAddCustTbcCustomerMainTabCustomerTbcMain.Location = New System.Drawing.Point(80, 100)
        Me.lblCustNameTabAddCustTbcCustomerMainTabCustomerTbcMain.Name = "lblCustNameTabAddCustTbcCustomerMainTabCustomerTbcMain"
        Me.lblCustNameTabAddCustTbcCustomerMainTabCustomerTbcMain.Size = New System.Drawing.Size(108, 16)
        Me.lblCustNameTabAddCustTbcCustomerMainTabCustomerTbcMain.TabIndex = 2
        '
        'Label45
        '
        Me.Label45.AutoSize = True
        Me.Label45.Location = New System.Drawing.Point(91, 72)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(57, 16)
        Me.Label45.TabIndex = 2
        '
        'Label44
        '
        Me.Label44.AutoSize = True
        Me.Label44.Location = New System.Drawing.Point(75, 107)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(73, 16)
        Me.Label44.TabIndex = 4
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Location = New System.Drawing.Point(89, 143)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(59, 16)
        Me.Label38.TabIndex = 6
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(50, 37)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(98, 16)
        Me.Label4.TabIndex = 0
        '
        'FrmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Beige
        Me.ClientSize = New System.Drawing.Size(1012, 687)
        Me.Controls.Add(Me.btnExitFrmMain)
        Me.Controls.Add(Me.tbcMainFrmMain)
        Me.Controls.Add(Me.lblThemeParkMgmtSysFrmMain)
        Me.Controls.Add(Me.mnuMainApplMenu)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MainMenuStrip = Me.mnuMainApplMenu
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "FrmMain"
        Me.mnuMainApplMenu.ResumeLayout(False)
        Me.mnuMainApplMenu.PerformLayout()
        Me.tabPassbkFeatTbcMainFrmMain.ResumeLayout(False)
        Me.tbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain.ResumeLayout(False)
        Me.tabAddFeatTbcPassbkFeatMainTbcMain.ResumeLayout(False)
        Me.grpAnon3.ResumeLayout(False)
        Me.grpAnon3.PerformLayout()
        Me.grpFeatTabAddFeatureTbcPassbookFeatureMainTbcMain.ResumeLayout(False)
        Me.grpFeatTabAddFeatureTbcPassbookFeatureMainTbcMain.PerformLayout()
        Me.grpPassbkTabAddFeatureTbcPassbookFeatureMainTbcMain.ResumeLayout(False)
        Me.grpPassbkTabAddFeatureTbcPassbookFeatureMainTbcMain.PerformLayout()
        Me.tabUpdtFeatTbcPassbkFeatMainTbcMain.ResumeLayout(False)
        Me.grpAnon4.ResumeLayout(False)
        Me.grpAnon4.PerformLayout()
        Me.grpPassbkTabUpdtFeatTbcPassbkFeatMainTbcMain.ResumeLayout(False)
        Me.grpPassbkTabUpdtFeatTbcPassbkFeatMainTbcMain.PerformLayout()
        Me.tabPostFeatTbcPassbkFeatMainTbcMain.ResumeLayout(False)
        Me.grpAnon1.ResumeLayout(False)
        Me.grpAnon1.PerformLayout()
        Me.grpPassbkTabPostTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain.ResumeLayout(False)
        Me.grpPassbkTabPostTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain.PerformLayout()
        Me.tabPassbkTbcMainFrmMain.ResumeLayout(False)
        Me.grpAddPassbkTabPassbkTbcMainFrmMain.ResumeLayout(False)
        Me.grpAnon2.ResumeLayout(False)
        Me.grpAnon2.PerformLayout()
        Me.grpCustInfoGrpAddPassbkTabPassbkTbcMainFrmMain.ResumeLayout(False)
        Me.grpCustInfoGrpAddPassbkTabPassbkTbcMainFrmMain.PerformLayout()
        Me.tabCustTbcMainFrmMain.ResumeLayout(False)
        Me.grpAddCustTabCustTbcMainFrmMain.ResumeLayout(False)
        Me.grpAnon6.ResumeLayout(False)
        Me.grpAnon6.PerformLayout()
        Me.tbcMainFrmMain.ResumeLayout(False)
        Me.tabDashTbcMainFrmMain.ResumeLayout(False)
        Me.tabDashTbcMainFrmMain.PerformLayout()
        Me.tabFeatTbcMainFrmMain.ResumeLayout(False)
        Me.grpAddFeatTabFeatTbcMainFrmMain.ResumeLayout(False)
        Me.grpAnon7.ResumeLayout(False)
        Me.grpAnon7.PerformLayout()
        Me.tabTransLogTbcMainFrmMain.ResumeLayout(False)
        Me.grpTransLogTabTransLogTbcMain.ResumeLayout(False)
        Me.grpTransLogTabTransLogTbcMain.PerformLayout()
        Me.tabSysTestTbcMainFrmMain.ResumeLayout(False)
        Me.grpSysTestTabSysTestTbcMainFrmMain.ResumeLayout(False)
        Me.grpSysTestTabSysTestTbcMainFrmMain.PerformLayout()
        Me.grpAnon5.ResumeLayout(False)
        Me.grpAnon5.PerformLayout()
        CType(Me.NumericUpDown3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents mnuMainApplMenu As MenuStrip
    Friend WithEvents mnuFileFrmMain As ToolStripMenuItem
    Friend WithEvents mnuSaveFileFrmMain As ToolStripMenuItem
    Friend WithEvents mnuImportFileFrmMain As ToolStripMenuItem
    Friend WithEvents mnuExportFileFrmMain As ToolStripMenuItem
    Friend WithEvents mnuExitFileFrmMain As ToolStripMenuItem
    Friend WithEvents mnuEditFrmMain As ToolStripMenuItem
    Friend WithEvents mnuCutEditFrmMain As ToolStripMenuItem
    Friend WithEvents mnuCopyEditFrmMain As ToolStripMenuItem
    Friend WithEvents mnuPasteEditFrmMain As ToolStripMenuItem
    Friend WithEvents mnuViewFrmMain As ToolStripMenuItem
    Friend WithEvents mnuHelpFrmMain As ToolStripMenuItem
    Friend WithEvents mnuAboutHelpFrmMain As ToolStripMenuItem
    Friend WithEvents lblThemeParkMgmtSysFrmMain As Label
    Friend WithEvents mnuDashboardViewFrmMain As ToolStripMenuItem
    Friend WithEvents mnuTransLogViewFrmMain As ToolStripMenuItem
    Friend WithEvents mnuPassbooksFrmMain As ToolStripMenuItem
    Friend WithEvents mnuPurchasePassbooksFrmMain As ToolStripMenuItem
    Friend WithEvents mnuFeaturePassbooksFrmMain As ToolStripMenuItem
    Friend WithEvents tabPassbkFeatTbcMainFrmMain As TabPage
    Friend WithEvents tbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain As TabControl
    Friend WithEvents tabAddFeatTbcPassbkFeatMainTbcMain As TabPage
    Friend WithEvents tabUpdtFeatTbcPassbkFeatMainTbcMain As TabPage
    Friend WithEvents tabPassbkTbcMainFrmMain As TabPage
    Friend WithEvents tabCustTbcMainFrmMain As TabPage
    Friend WithEvents tbcMainFrmMain As TabControl
    Friend WithEvents mnuAddFeaturesPassbooksFrmMain As ToolStripMenuItem
    Friend WithEvents mnuUpdateFeaturesPassbooksFrmMain As ToolStripMenuItem
    Friend WithEvents btnExitFrmMain As Button
    Friend WithEvents tipTPMS As ToolTip
    Friend WithEvents tabPostFeatTbcPassbkFeatMainTbcMain As TabPage
    Friend WithEvents grpPassbkTabPostTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain As GroupBox
    Friend WithEvents Label22 As Label
    Private WithEvents txtLocTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain As TextBox
    Friend WithEvents Label26 As Label
    Friend WithEvents tabTransLogTbcMainFrmMain As TabPage
    Friend WithEvents grpTransLogTabTransLogTbcMain As GroupBox
    Friend WithEvents tabDashTbcMainFrmMain As TabPage
    Friend WithEvents grpKpiTabDashboardTbcMain As GroupBox
    Friend WithEvents mnuTestFrmMain As ToolStripMenuItem
    Friend WithEvents mnuImportTestFrmMain As ToolStripMenuItem
    Friend WithEvents mnuExportTestFrmMain As ToolStripMenuItem
    Friend WithEvents btnResetTabPostFeatTbcPassbkFeatMainTbcMain As Button
    Friend WithEvents btnSubmitTabPostFeatTbcPassbkFeatMainTbcMain As Button
    Friend WithEvents btnResetTabAddFeatTbcPassbkFeatMainTbcMain As Button
    Friend WithEvents btnSubmitTabAddFeatTbcPassbkFeatMainTbcMain As Button
    Friend WithEvents btnClearTabTransLogTbcMainFrmMain As Button
    Friend WithEvents lblCustIdTabAddCustTbcCustomerMainTabCustomerTbcMain As Label
    Friend WithEvents lblCustNameTabAddCustTbcCustomerMainTabCustomerTbcMain As Label
    Friend WithEvents txtCustNameTabAddCustTbcCustomerMainTabCustomerTbcMain As TextBox
    Friend WithEvents btnAddGrpCustInfoTcbMain As Button
    Friend WithEvents btnResetGrpCustInfoTcbMain As Button
    Friend WithEvents lstUsedFeatCntTabDashboardTbcMain As System.Windows.Forms.TextBox
    Friend WithEvents txtPassbkFeatCntTabDashboardTbcMain As System.Windows.Forms.TextBox
    Friend WithEvents txtPassbkCntTabDashboardTbcMain As System.Windows.Forms.TextBox
    Friend WithEvents txtFeatCntTabDashboardTbcMain As System.Windows.Forms.TextBox
    Friend WithEvents txtCustCntTabDashboardTbcMain As System.Windows.Forms.TextBox
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents txtToStringTabDashboardTbcMain As System.Windows.Forms.TextBox
    Friend WithEvents lstUsedFeatTabDashboardTbcMain As System.Windows.Forms.ListBox
    Friend WithEvents lstPassbkFeatTabDashboardTbcMain As System.Windows.Forms.ListBox
    Friend WithEvents lstPassbkTabDashboardTbcMain As System.Windows.Forms.ListBox
    Friend WithEvents lstFeatTabDashboardTbcMain As System.Windows.Forms.ListBox
    Friend WithEvents lstCustTabDashboardTbcMain As System.Windows.Forms.ListBox
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents tabFeatTbcMainFrmMain As System.Windows.Forms.TabPage
    Friend WithEvents grpAddFeatTabFeatTbcMainFrmMain As System.Windows.Forms.GroupBox
    Friend WithEvents btnResetGrpAddFeatTabFeatTbcMainFrmMain As System.Windows.Forms.Button
    Friend WithEvents btnSubmitGrpAddFeatTabFeatTbcMainFrmMain As System.Windows.Forms.Button
    Friend WithEvents grpAddCustTabCustTbcMainFrmMain As System.Windows.Forms.GroupBox
    Friend WithEvents btnResetGrpCustInfoTabCustTbcMainFrmMain As System.Windows.Forms.Button
    Friend WithEvents btnSubmitGrpCustInfoTabCustTbcMainFrmMain As System.Windows.Forms.Button
    Friend WithEvents grpAddPassbkTabPassbkTbcMainFrmMain As System.Windows.Forms.GroupBox
    Friend WithEvents grpCustInfoGrpAddPassbkTabPassbkTbcMainFrmMain As System.Windows.Forms.GroupBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtToStringGrpCustInfoGrpAddPassbkTabPassbkTbcMainFrmMain As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents btnResetGrpAddPassbkTabPassbkTbcMainFrmMain As System.Windows.Forms.Button
    Friend WithEvents btnSubmitGrpAddPassbkTabPassbkTbcMainFrmMain As System.Windows.Forms.Button
    Friend WithEvents grpAnon1 As System.Windows.Forms.GroupBox
    Friend WithEvents txtQtyUsedTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain As System.Windows.Forms.TextBox
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents txtRemQuantTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain As System.Windows.Forms.TextBox
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents txtPrevUsedTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain As System.Windows.Forms.TextBox
    Friend WithEvents txtVisToStringTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain As System.Windows.Forms.TextBox
    Friend WithEvents txtFeatToStringTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain As System.Windows.Forms.TextBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents txtCustToStringTabPostFeatTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents grpAnon2 As System.Windows.Forms.GroupBox
    Friend WithEvents txtVisNameGrpAddPassbkTabPassbkTbcMainFrmMain As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents txtVisDobGrpAddPassbkTabPassbkTbcMainFrmMain As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Private WithEvents txtPassbkIdGrpAddPassbkTabPassbkTbcMainFrmMain As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents grpFeatTabAddFeatureTbcPassbookFeatureMainTbcMain As System.Windows.Forms.GroupBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents txtFeatToStringTabAddFeatTbcPassbkFeatMainTbcMain As System.Windows.Forms.TextBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents grpPassbkTabAddFeatureTbcPassbookFeatureMainTbcMain As System.Windows.Forms.GroupBox
    Friend WithEvents txtVisToStringTabAddFeatTbcPassbkFeatMainTbcMain As System.Windows.Forms.TextBox
    Friend WithEvents txtCustToStringTabAddFeatTbcPassbkFeatMainTbcMain As System.Windows.Forms.TextBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents grpAnon3 As System.Windows.Forms.GroupBox
    Friend WithEvents txtPriceTabAddFeatTbcPassbkFeatMainTbcMain As System.Windows.Forms.TextBox
    Friend WithEvents Label46 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents txtQtyTabAddFeatTbcPassbkFeatMainTbcMain As System.Windows.Forms.TextBox
    Friend WithEvents grpAnon4 As System.Windows.Forms.GroupBox
    Friend WithEvents txtNewQtyTabUpdtFeatTbcPassbkFeatMainTbcMain As System.Windows.Forms.TextBox
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents txtRemQtyTabUpdtFeatTbcPassbkFeatMainTbcMain As System.Windows.Forms.TextBox
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents grpPassbkTabUpdtFeatTbcPassbkFeatMainTbcMain As System.Windows.Forms.GroupBox
    Friend WithEvents txtPrevUsedToStringTabUpdtFeatTbcPassbkFeatMainTbcMain As System.Windows.Forms.TextBox
    Friend WithEvents txtVisToStringTabUpdtFeatTbcPassbkFeatMainTbcMain As System.Windows.Forms.TextBox
    Friend WithEvents txtFeatToStringTabUpdtFeatTbcPassbkFeatMainTbcMain As System.Windows.Forms.TextBox
    Friend WithEvents Label47 As System.Windows.Forms.Label
    Friend WithEvents txtCustToStringTabUpdtFeatTbcPassbkFeatMainTbcMain As System.Windows.Forms.TextBox
    Friend WithEvents Label48 As System.Windows.Forms.Label
    Friend WithEvents Label49 As System.Windows.Forms.Label
    Friend WithEvents Label50 As System.Windows.Forms.Label
    Friend WithEvents Label51 As System.Windows.Forms.Label
    Friend WithEvents btnResetTabUpdtFeatTbcPassbkFeatMainTbcMain As System.Windows.Forms.Button
    Friend WithEvents btnSubmitTabUpdtFeatTbcPassbkFeatMainTbcMain As System.Windows.Forms.Button
    Friend WithEvents txtPriceTabUpdtFeatTbcPassbkFeatMainTbcMain As System.Windows.Forms.TextBox
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents tabSysTestTbcMainFrmMain As System.Windows.Forms.TabPage
    Friend WithEvents grpSysTestTabSysTestTbcMainFrmMain As System.Windows.Forms.GroupBox
    Friend WithEvents grpAnon5 As System.Windows.Forms.GroupBox
    Friend WithEvents btnWriteFileGrpSysTestTabSysTestTbcMainFrmMain As System.Windows.Forms.Button
    Friend WithEvents chkAppendTabSysTestTbcMainFrmMain As System.Windows.Forms.CheckBox
    Friend WithEvents btnReadFileTabSysTestTbcMainFrmMain As System.Windows.Forms.Button
    Friend WithEvents btnProcTestDataGrpSysTestTabSysTestTbcMainFrmMain As System.Windows.Forms.Button
    Friend WithEvents Label45 As System.Windows.Forms.Label
    Friend WithEvents Label44 As System.Windows.Forms.Label
    Friend WithEvents ListBox2 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox1 As System.Windows.Forms.ListBox
    Friend WithEvents NumericUpDown3 As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents grpAnon6 As System.Windows.Forms.GroupBox
    Friend WithEvents txtCustNameGrpAddCustTabCustTbcMainFrmMain As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Private WithEvents txtCustIdGrpAddCustTabCustTbcMainFrmMain As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents grpAnon7 As System.Windows.Forms.GroupBox
    Friend WithEvents txtPriceChildGrpAddFeatTabFeatTbcMainFrmMain As System.Windows.Forms.TextBox
    Friend WithEvents Label39 As System.Windows.Forms.Label
    Friend WithEvents txtPriceAdultGrpAddFeatTabFeatTbcMainFrmMain As System.Windows.Forms.TextBox
    Friend WithEvents txtUnifOfMeasGrpAddFeatTabFeatTbcMainFrmMain As System.Windows.Forms.TextBox
    Friend WithEvents Label40 As System.Windows.Forms.Label
    Friend WithEvents txtFeatNameGrpAddFeatTabFeatTbcMainFrmMain As System.Windows.Forms.TextBox
    Friend WithEvents Label41 As System.Windows.Forms.Label
    Private WithEvents txtFeatIdAddFeatTabFeatTbcMainFrmMain As System.Windows.Forms.TextBox
    Friend WithEvents Label42 As System.Windows.Forms.Label
    Friend WithEvents Label43 As System.Windows.Forms.Label
    Private WithEvents txtTransLogTabTransLogTbcMainFrmMain As System.Windows.Forms.TextBox
    Friend WithEvents txtPassBkFeatIdTabAddFeatTbcPassbkFeatMainTbcMain As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents mnuRunSysTestTestFrmMain As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents cboPassbkIdTabAddFeatTbcPassbkFeatMainTbcMain As System.Windows.Forms.ComboBox
    Friend WithEvents cboFeatIdTabAddFeatTbcPassbkFeatMainTbcMain As System.Windows.Forms.ComboBox
    Friend WithEvents cboFeatIdTabUpdtFeatTbcPassbkFeatMainTbcMain As System.Windows.Forms.ComboBox
    Friend WithEvents cboPassbkFeatIdTbcPassbkFeatMainTabPassbkFeatTbcMainFrmMain As System.Windows.Forms.ComboBox
    Friend WithEvents cboCustIdGrpCustInfoGrpAddPassbkTabPassbkTbcMainFrmMain As System.Windows.Forms.ComboBox
    Friend WithEvents chkUseTestParkGrpSysTestTabSysTestTbcMainFrmMain As System.Windows.Forms.CheckBox
    Friend WithEvents mnuUseFeaturesPassbooksFrmMain As System.Windows.Forms.ToolStripMenuItem
End Class
