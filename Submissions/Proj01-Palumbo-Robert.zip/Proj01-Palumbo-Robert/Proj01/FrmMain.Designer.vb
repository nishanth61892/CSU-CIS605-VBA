﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmMain))
        Me.mnuMainApplMenu = New System.Windows.Forms.MenuStrip()
        Me.mnuFileFrmMain = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuSaveFileFrmMain = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuImportFileFrmMain = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuExportFileFrmMain = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuExitFileFrmMain = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuEditFrmMain = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuCutEditFrmMain = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuCopyEditFrmMain = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuPasteEditFrmMain = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuPassbooksFrmMain = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuPurchasePassbooksFrmMain = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuPassbookPurchasePassbooksFrmMain = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuFeaturePurchasePassbooksFrmMain = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuFeaturePassbooksFrmMain = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuAddFeaturesPassbooksFrmMain = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuUpdateFeaturesPassbooksFrmMain = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuViewFrmMain = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuDashboardViewFrmMain = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuTransLogViewFrmMain = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuTestFrmMain = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuImportTestFrmMain = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuExportTestFrmMain = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuHelpFrmMain = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuAboutHelpFrmMain = New System.Windows.Forms.ToolStripMenuItem()
        Me.lblThemeParkMgmtSys = New System.Windows.Forms.Label()
        Me.tabPassbookFeatureTbcMain = New System.Windows.Forms.TabPage()
        Me.tbcPassbookFeatureMainTbcMain = New System.Windows.Forms.TabControl()
        Me.tabAddFeatureTbcPassbookFeatureMainTbcMain = New System.Windows.Forms.TabPage()
        Me.grpAddFeatureTbcPassbookFeatureMainTbcMain = New System.Windows.Forms.GroupBox()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.txtPriceChildTabAddFeatureTbcPassbookFeatureMainTbcMain = New System.Windows.Forms.TextBox()
        Me.lblPriceChildTabAddFeatureTbcPassbookFeatureMainTbcMain = New System.Windows.Forms.Label()
        Me.txtPriceAdultTabAddFeatureTbcPassbookFeatureMainTbcMain = New System.Windows.Forms.TextBox()
        Me.txtUnitOfMeasAddFeatureTbcPassbookFeatureMainTbcMain = New System.Windows.Forms.TextBox()
        Me.lblUnitOfMeasTabAddFeatureTbcPassbookFeatureMainTbcMain = New System.Windows.Forms.Label()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.lblFeatureIdTabAddFeatureTbcPassbookFeatureMainTbcMain = New System.Windows.Forms.Label()
        Me.txtFeatureIdTabAddFeatureTbcPassbookFeatureMainTbcMain = New System.Windows.Forms.TextBox()
        Me.lblPriceTabAddFeatureTbcPassbookFeatureMainTbcMain = New System.Windows.Forms.Label()
        Me.lblFeatureNameTabAddFeatureTbcPassbookFeatureMainTbcMain = New System.Windows.Forms.Label()
        Me.tabUpdtFeatureTbcPassbookFeatureMainTbcMain = New System.Windows.Forms.TabPage()
        Me.grpUpdtFeatureTbcPassbookFeatureMainTbcMain = New System.Windows.Forms.GroupBox()
        Me.btnResetTabUpdtFeatureTbcPassbookFeatureMainTbcMain = New System.Windows.Forms.Button()
        Me.btnSubmitTabUpdtFeatureTbcPassbookFeatureMainTbcMain = New System.Windows.Forms.Button()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.lblQtyTabUpdtFeatureTbcPassbookFeatureMainTbcMain = New System.Windows.Forms.Label()
        Me.NumericUpDown1 = New System.Windows.Forms.NumericUpDown()
        Me.lstPassbookTabUpdtFeatureTbcPassbookFeatureMainTbcMain = New System.Windows.Forms.ListBox()
        Me.lblPassbookTabUpdtFeatureTbcPassbookFeatureMainTbcMain = New System.Windows.Forms.Label()
        Me.lblPassbookIdTabUpdtFeatureTbcPassbookFeatureMainTbcMain = New System.Windows.Forms.Label()
        Me.txtPassbookIdTabUpdtFeatureTbcPassbookFeatureMainTbcMain = New System.Windows.Forms.TextBox()
        Me.tabPostFeatureTbcPassbookFeatureMainTbcMain = New System.Windows.Forms.TabPage()
        Me.grpPostFeatureTbcPassbookFeatureMainTbcMain = New System.Windows.Forms.GroupBox()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.TextBox5 = New System.Windows.Forms.TextBox()
        Me.btnSubmitGrpUpdtFeatureTbcPassbookFeatureMainTbcMain = New System.Windows.Forms.Button()
        Me.lblLocationGrpUpdtFeatureTbcPassbookFeatureMainTbcMain = New System.Windows.Forms.Label()
        Me.lstFeatureGrpUpdtFeatureTbcPassbookFeatureMainTbcMain = New System.Windows.Forms.ListBox()
        Me.lblFeatureGrpUpdtFeatureTbcPassbookFeatureMainTbcMain = New System.Windows.Forms.Label()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.lblQtyGrpUpdtFeatureTbcPassbookFeatureMainTbcMain = New System.Windows.Forms.Label()
        Me.NumericUpDown2 = New System.Windows.Forms.NumericUpDown()
        Me.lstPassbookGrpUpdtFeatureTbcPassbookFeatureMainTbcMain = New System.Windows.Forms.ListBox()
        Me.lblPassbookGrpUpdtFeatureTbcPassbookFeatureMainTbcMain = New System.Windows.Forms.Label()
        Me.lblPassbookFeatureIddGrpUpdtFeatureTbcPassbookFeatureMainTbcMain = New System.Windows.Forms.Label()
        Me.txtPassbookFeatureIddGrpUpdtFeatureTbcPassbookFeatureMainTbcMain = New System.Windows.Forms.TextBox()
        Me.tabPurchaseTbcMain = New System.Windows.Forms.TabPage()
        Me.tbcPurchaseMainTabPurchaseTbcMain = New System.Windows.Forms.TabControl()
        Me.tabPassbookTbcPurchaseMainTabPurchaseTbcMain = New System.Windows.Forms.TabPage()
        Me.grpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain = New System.Windows.Forms.GroupBox()
        Me.btnResetGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain = New System.Windows.Forms.Button()
        Me.chkVChildPassbookIfnoTabPassbookTbcPurchaseMainTabPurchaseTbcMain = New System.Windows.Forms.CheckBox()
        Me.btnSubmitGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain = New System.Windows.Forms.Button()
        Me.txtVNameGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain = New System.Windows.Forms.TextBox()
        Me.lblVNameGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain = New System.Windows.Forms.Label()
        Me.dtpVDOBGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain = New System.Windows.Forms.DateTimePicker()
        Me.txtDatePurchasedGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain = New System.Windows.Forms.TextBox()
        Me.lstCustNameGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain = New System.Windows.Forms.ListBox()
        Me.lblDatePurchasedGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain = New System.Windows.Forms.Label()
        Me.lblPassbookIdGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain = New System.Windows.Forms.Label()
        Me.txtTransactIdGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain = New System.Windows.Forms.TextBox()
        Me.lblVDOBGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain = New System.Windows.Forms.Label()
        Me.lblCustNameGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain = New System.Windows.Forms.Label()
        Me.tabFeatureTbcPurchaseMainTabPurchaseTbcMain = New System.Windows.Forms.TabPage()
        Me.grpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain = New System.Windows.Forms.GroupBox()
        Me.lblTransIDGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain = New System.Windows.Forms.Label()
        Me.btnCancelTabFeatureTbcPurchaseMainTabPurchaseTbcMain = New System.Windows.Forms.Button()
        Me.btnSubmitTbcPurchaseMainTabPurchaseTbcMain = New System.Windows.Forms.Button()
        Me.txtTransactDGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain = New System.Windows.Forms.TextBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.lblQtyGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain = New System.Windows.Forms.Label()
        Me.nudQtyGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain = New System.Windows.Forms.NumericUpDown()
        Me.lstPassbookGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain = New System.Windows.Forms.ListBox()
        Me.lstFeatureGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain = New System.Windows.Forms.ListBox()
        Me.lblPassbookGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain = New System.Windows.Forms.Label()
        Me.lblFeatureGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain = New System.Windows.Forms.Label()
        Me.tabCustTbcMain = New System.Windows.Forms.TabPage()
        Me.tbcCustomerMainTabCustomerTbcMain = New System.Windows.Forms.TabControl()
        Me.tabAddTbcCustomerMainTabCustomerTbcMain = New System.Windows.Forms.TabPage()
        Me.grpCustInfoTbcCustomerMainTabCustomerTbcMain = New System.Windows.Forms.GroupBox()
        Me.btnResetGrpCustInfoTbcCustomerMainTabCustomerTbcMain = New System.Windows.Forms.Button()
        Me.btnSubmitGrpCustInfoTbcCustomerMainTabCustomerTbcMain = New System.Windows.Forms.Button()
        Me.txtCustNameGrpCustInfoTbcCustomerMainTabCustomerTbcMain = New System.Windows.Forms.TextBox()
        Me.lblCustIdGrpCustInfoTbcCustomerMainTabCustomerTbcMain = New System.Windows.Forms.Label()
        Me.txtCustIdGrpCustInfoTbcCustomerMainTabCustomerTbcMain = New System.Windows.Forms.TextBox()
        Me.lblCustNameGrpCustInfoTbcCustomerMainTabCustomerTbcMain = New System.Windows.Forms.Label()
        Me.tabViewCustTbcCustomerMainTabCustomerTbcMain = New System.Windows.Forms.TabPage()
        Me.grpCustInfo2TbcCustomerMainTabCustomerTbcMain = New System.Windows.Forms.GroupBox()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.txtCustNameGrpCustInfo2TbcCustomerMainTabCustomerTbcMain = New System.Windows.Forms.TextBox()
        Me.lblCustIdGrpCustInfo2TbcCustomerMainTabCustomerTbcMain = New System.Windows.Forms.Label()
        Me.txtCustIdGrpCustInfo2TbcCustomerMainTabCustomerTbcMain = New System.Windows.Forms.TextBox()
        Me.lblCustNameIdGrpCustInfo2TbcCustomerMainTabCustomerTbcMain = New System.Windows.Forms.Label()
        Me.tbcMain = New System.Windows.Forms.TabControl()
        Me.tabTransLogFeatureTbcMain = New System.Windows.Forms.TabPage()
        Me.grpTransLogTabTransLogTbcMain = New System.Windows.Forms.GroupBox()
        Me.btnTransLogTabTransLogTbcMain = New System.Windows.Forms.Button()
        Me.txtTransLogTabTransLogTbcMain = New System.Windows.Forms.TextBox()
        Me.tabSysKpiTbcMain = New System.Windows.Forms.TabPage()
        Me.grpKpiTabDashboardTbcMain = New System.Windows.Forms.GroupBox()
        Me.TextBox6 = New System.Windows.Forms.TextBox()
        Me.btnExitFrmMain = New System.Windows.Forms.Button()
        Me.tipTPMS = New System.Windows.Forms.ToolTip(Me.components)
        Me.txtCustIdTabAddCustTbcCustomerMainTabCustomerTbcMain = New System.Windows.Forms.TextBox()
        Me.txtCustNameTabAddCustTbcCustomerMainTabCustomerTbcMain = New System.Windows.Forms.TextBox()
        Me.btnAddGrpCustInfoTcbMain = New System.Windows.Forms.Button()
        Me.btnResetGrpCustInfoTcbMain = New System.Windows.Forms.Button()
        Me.btnTesttFrmMain = New System.Windows.Forms.Button()
        Me.lblCustIdTabAddCustTbcCustomerMainTabCustomerTbcMain = New System.Windows.Forms.Label()
        Me.lblCustNameTabAddCustTbcCustomerMainTabCustomerTbcMain = New System.Windows.Forms.Label()
        Me.mnuMainApplMenu.SuspendLayout()
        Me.tabPassbookFeatureTbcMain.SuspendLayout()
        Me.tbcPassbookFeatureMainTbcMain.SuspendLayout()
        Me.tabAddFeatureTbcPassbookFeatureMainTbcMain.SuspendLayout()
        Me.grpAddFeatureTbcPassbookFeatureMainTbcMain.SuspendLayout()
        Me.tabUpdtFeatureTbcPassbookFeatureMainTbcMain.SuspendLayout()
        Me.grpUpdtFeatureTbcPassbookFeatureMainTbcMain.SuspendLayout()
        CType(Me.NumericUpDown1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tabPostFeatureTbcPassbookFeatureMainTbcMain.SuspendLayout()
        Me.grpPostFeatureTbcPassbookFeatureMainTbcMain.SuspendLayout()
        CType(Me.NumericUpDown2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tabPurchaseTbcMain.SuspendLayout()
        Me.tbcPurchaseMainTabPurchaseTbcMain.SuspendLayout()
        Me.tabPassbookTbcPurchaseMainTabPurchaseTbcMain.SuspendLayout()
        Me.grpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.SuspendLayout()
        Me.tabFeatureTbcPurchaseMainTabPurchaseTbcMain.SuspendLayout()
        Me.grpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.SuspendLayout()
        CType(Me.nudQtyGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tabCustTbcMain.SuspendLayout()
        Me.tbcCustomerMainTabCustomerTbcMain.SuspendLayout()
        Me.tabAddTbcCustomerMainTabCustomerTbcMain.SuspendLayout()
        Me.grpCustInfoTbcCustomerMainTabCustomerTbcMain.SuspendLayout()
        Me.tabViewCustTbcCustomerMainTabCustomerTbcMain.SuspendLayout()
        Me.grpCustInfo2TbcCustomerMainTabCustomerTbcMain.SuspendLayout()
        Me.tbcMain.SuspendLayout()
        Me.tabTransLogFeatureTbcMain.SuspendLayout()
        Me.grpTransLogTabTransLogTbcMain.SuspendLayout()
        Me.tabSysKpiTbcMain.SuspendLayout()
        Me.grpKpiTabDashboardTbcMain.SuspendLayout()
        Me.SuspendLayout()
        '
        'mnuMainApplMenu
        '
        Me.mnuMainApplMenu.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.mnuMainApplMenu.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.mnuMainApplMenu.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuFileFrmMain, Me.mnuEditFrmMain, Me.mnuPassbooksFrmMain, Me.mnuViewFrmMain, Me.mnuTestFrmMain, Me.mnuHelpFrmMain})
        Me.mnuMainApplMenu.Location = New System.Drawing.Point(0, 0)
        Me.mnuMainApplMenu.Name = "mnuMainApplMenu"
        Me.mnuMainApplMenu.Padding = New System.Windows.Forms.Padding(8, 2, 0, 2)
        Me.mnuMainApplMenu.Size = New System.Drawing.Size(742, 25)
        Me.mnuMainApplMenu.TabIndex = 0
        Me.mnuMainApplMenu.Text = "MenuStrip1"
        '
        'mnuFileFrmMain
        '
        Me.mnuFileFrmMain.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuSaveFileFrmMain, Me.mnuImportFileFrmMain, Me.mnuExportFileFrmMain, Me.mnuExitFileFrmMain})
        Me.mnuFileFrmMain.Name = "mnuFileFrmMain"
        Me.mnuFileFrmMain.Size = New System.Drawing.Size(40, 21)
        Me.mnuFileFrmMain.Text = "&File"
        Me.mnuFileFrmMain.ToolTipText = "Save Session"
        '
        'mnuSaveFileFrmMain
        '
        Me.mnuSaveFileFrmMain.Image = CType(resources.GetObject("mnuSaveFileFrmMain.Image"), System.Drawing.Image)
        Me.mnuSaveFileFrmMain.Name = "mnuSaveFileFrmMain"
        Me.mnuSaveFileFrmMain.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.S), System.Windows.Forms.Keys)
        Me.mnuSaveFileFrmMain.Size = New System.Drawing.Size(149, 22)
        Me.mnuSaveFileFrmMain.Text = "Save"
        Me.mnuSaveFileFrmMain.ToolTipText = "Save Session"
        '
        'mnuImportFileFrmMain
        '
        Me.mnuImportFileFrmMain.Name = "mnuImportFileFrmMain"
        Me.mnuImportFileFrmMain.Size = New System.Drawing.Size(149, 22)
        Me.mnuImportFileFrmMain.Text = "Import"
        Me.mnuImportFileFrmMain.ToolTipText = "Import Data"
        '
        'mnuExportFileFrmMain
        '
        Me.mnuExportFileFrmMain.Name = "mnuExportFileFrmMain"
        Me.mnuExportFileFrmMain.Size = New System.Drawing.Size(149, 22)
        Me.mnuExportFileFrmMain.Text = "Export"
        Me.mnuExportFileFrmMain.ToolTipText = "Export Data"
        '
        'mnuExitFileFrmMain
        '
        Me.mnuExitFileFrmMain.Name = "mnuExitFileFrmMain"
        Me.mnuExitFileFrmMain.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.X), System.Windows.Forms.Keys)
        Me.mnuExitFileFrmMain.Size = New System.Drawing.Size(149, 22)
        Me.mnuExitFileFrmMain.Text = "Exit"
        Me.mnuExitFileFrmMain.ToolTipText = "Exit the system"
        '
        'mnuEditFrmMain
        '
        Me.mnuEditFrmMain.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuCutEditFrmMain, Me.mnuCopyEditFrmMain, Me.mnuPasteEditFrmMain})
        Me.mnuEditFrmMain.Name = "mnuEditFrmMain"
        Me.mnuEditFrmMain.Size = New System.Drawing.Size(43, 21)
        Me.mnuEditFrmMain.Text = "&Edit"
        '
        'mnuCutEditFrmMain
        '
        Me.mnuCutEditFrmMain.Image = CType(resources.GetObject("mnuCutEditFrmMain.Image"), System.Drawing.Image)
        Me.mnuCutEditFrmMain.Name = "mnuCutEditFrmMain"
        Me.mnuCutEditFrmMain.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.X), System.Windows.Forms.Keys)
        Me.mnuCutEditFrmMain.Size = New System.Drawing.Size(155, 22)
        Me.mnuCutEditFrmMain.Text = "Cut"
        '
        'mnuCopyEditFrmMain
        '
        Me.mnuCopyEditFrmMain.Image = CType(resources.GetObject("mnuCopyEditFrmMain.Image"), System.Drawing.Image)
        Me.mnuCopyEditFrmMain.Name = "mnuCopyEditFrmMain"
        Me.mnuCopyEditFrmMain.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.C), System.Windows.Forms.Keys)
        Me.mnuCopyEditFrmMain.Size = New System.Drawing.Size(155, 22)
        Me.mnuCopyEditFrmMain.Text = "Copy"
        '
        'mnuPasteEditFrmMain
        '
        Me.mnuPasteEditFrmMain.Image = CType(resources.GetObject("mnuPasteEditFrmMain.Image"), System.Drawing.Image)
        Me.mnuPasteEditFrmMain.Name = "mnuPasteEditFrmMain"
        Me.mnuPasteEditFrmMain.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.V), System.Windows.Forms.Keys)
        Me.mnuPasteEditFrmMain.Size = New System.Drawing.Size(155, 22)
        Me.mnuPasteEditFrmMain.Text = "Paste"
        '
        'mnuPassbooksFrmMain
        '
        Me.mnuPassbooksFrmMain.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuPurchasePassbooksFrmMain, Me.mnuFeaturePassbooksFrmMain})
        Me.mnuPassbooksFrmMain.Name = "mnuPassbooksFrmMain"
        Me.mnuPassbooksFrmMain.Size = New System.Drawing.Size(84, 21)
        Me.mnuPassbooksFrmMain.Text = "&Passbooks"
        Me.mnuPassbooksFrmMain.ToolTipText = "Purchase Passbook & Features"
        '
        'mnuPurchasePassbooksFrmMain
        '
        Me.mnuPurchasePassbooksFrmMain.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right
        Me.mnuPurchasePassbooksFrmMain.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuPassbookPurchasePassbooksFrmMain, Me.mnuFeaturePurchasePassbooksFrmMain})
        Me.mnuPurchasePassbooksFrmMain.Name = "mnuPurchasePassbooksFrmMain"
        Me.mnuPurchasePassbooksFrmMain.Size = New System.Drawing.Size(131, 22)
        Me.mnuPurchasePassbooksFrmMain.Text = "Purchase"
        Me.mnuPurchasePassbooksFrmMain.ToolTipText = "Passbook and feature purchase options"
        '
        'mnuPassbookPurchasePassbooksFrmMain
        '
        Me.mnuPassbookPurchasePassbooksFrmMain.Name = "mnuPassbookPurchasePassbooksFrmMain"
        Me.mnuPassbookPurchasePassbooksFrmMain.Size = New System.Drawing.Size(134, 22)
        Me.mnuPassbookPurchasePassbooksFrmMain.Text = "Passbook"
        Me.mnuPassbookPurchasePassbooksFrmMain.ToolTipText = "Purchase a new Theme Park Passbook"
        '
        'mnuFeaturePurchasePassbooksFrmMain
        '
        Me.mnuFeaturePurchasePassbooksFrmMain.Name = "mnuFeaturePurchasePassbooksFrmMain"
        Me.mnuFeaturePurchasePassbooksFrmMain.Size = New System.Drawing.Size(134, 22)
        Me.mnuFeaturePurchasePassbooksFrmMain.Text = "Feature"
        Me.mnuFeaturePurchasePassbooksFrmMain.ToolTipText = "Purchase a new Theme Park Feature"
        '
        'mnuFeaturePassbooksFrmMain
        '
        Me.mnuFeaturePassbooksFrmMain.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuAddFeaturesPassbooksFrmMain, Me.mnuUpdateFeaturesPassbooksFrmMain})
        Me.mnuFeaturePassbooksFrmMain.Name = "mnuFeaturePassbooksFrmMain"
        Me.mnuFeaturePassbooksFrmMain.Size = New System.Drawing.Size(131, 22)
        Me.mnuFeaturePassbooksFrmMain.Text = "Features"
        Me.mnuFeaturePassbooksFrmMain.ToolTipText = "Add or update a passbook feature"
        '
        'mnuAddFeaturesPassbooksFrmMain
        '
        Me.mnuAddFeaturesPassbooksFrmMain.Name = "mnuAddFeaturesPassbooksFrmMain"
        Me.mnuAddFeaturesPassbooksFrmMain.Size = New System.Drawing.Size(120, 22)
        Me.mnuAddFeaturesPassbooksFrmMain.Text = "Add"
        Me.mnuAddFeaturesPassbooksFrmMain.ToolTipText = "Add a passbook feature"
        '
        'mnuUpdateFeaturesPassbooksFrmMain
        '
        Me.mnuUpdateFeaturesPassbooksFrmMain.Name = "mnuUpdateFeaturesPassbooksFrmMain"
        Me.mnuUpdateFeaturesPassbooksFrmMain.Size = New System.Drawing.Size(120, 22)
        Me.mnuUpdateFeaturesPassbooksFrmMain.Text = "Update"
        Me.mnuUpdateFeaturesPassbooksFrmMain.ToolTipText = "Update a passbook feature"
        '
        'mnuViewFrmMain
        '
        Me.mnuViewFrmMain.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuDashboardViewFrmMain, Me.mnuTransLogViewFrmMain})
        Me.mnuViewFrmMain.Name = "mnuViewFrmMain"
        Me.mnuViewFrmMain.Size = New System.Drawing.Size(48, 21)
        Me.mnuViewFrmMain.Text = "&View"
        '
        'mnuDashboardViewFrmMain
        '
        Me.mnuDashboardViewFrmMain.Name = "mnuDashboardViewFrmMain"
        Me.mnuDashboardViewFrmMain.Size = New System.Drawing.Size(172, 22)
        Me.mnuDashboardViewFrmMain.Text = "Dashboard"
        Me.mnuDashboardViewFrmMain.ToolTipText = "View the system dashboard (KPI)"
        '
        'mnuTransLogViewFrmMain
        '
        Me.mnuTransLogViewFrmMain.Name = "mnuTransLogViewFrmMain"
        Me.mnuTransLogViewFrmMain.Size = New System.Drawing.Size(172, 22)
        Me.mnuTransLogViewFrmMain.Text = "Transaction Log"
        Me.mnuTransLogViewFrmMain.ToolTipText = "View the system transaction log"
        '
        'mnuTestFrmMain
        '
        Me.mnuTestFrmMain.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuImportTestFrmMain, Me.mnuExportTestFrmMain})
        Me.mnuTestFrmMain.Name = "mnuTestFrmMain"
        Me.mnuTestFrmMain.Size = New System.Drawing.Size(45, 21)
        Me.mnuTestFrmMain.Text = "&Test"
        '
        'mnuImportTestFrmMain
        '
        Me.mnuImportTestFrmMain.Name = "mnuImportTestFrmMain"
        Me.mnuImportTestFrmMain.Size = New System.Drawing.Size(120, 22)
        Me.mnuImportTestFrmMain.Text = "Import"
        Me.mnuImportTestFrmMain.ToolTipText = "Import test data for simulation"
        '
        'mnuExportTestFrmMain
        '
        Me.mnuExportTestFrmMain.Name = "mnuExportTestFrmMain"
        Me.mnuExportTestFrmMain.Size = New System.Drawing.Size(120, 22)
        Me.mnuExportTestFrmMain.Text = "Export "
        Me.mnuExportTestFrmMain.ToolTipText = "Export data for backup"
        '
        'mnuHelpFrmMain
        '
        Me.mnuHelpFrmMain.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuAboutHelpFrmMain})
        Me.mnuHelpFrmMain.Name = "mnuHelpFrmMain"
        Me.mnuHelpFrmMain.Size = New System.Drawing.Size(48, 21)
        Me.mnuHelpFrmMain.Text = "&Help"
        '
        'mnuAboutHelpFrmMain
        '
        Me.mnuAboutHelpFrmMain.AutoToolTip = True
        Me.mnuAboutHelpFrmMain.Name = "mnuAboutHelpFrmMain"
        Me.mnuAboutHelpFrmMain.Size = New System.Drawing.Size(279, 22)
        Me.mnuAboutHelpFrmMain.Text = "About Theme Park Mgmt System"
        '
        'lblThemeParkMgmtSys
        '
        Me.lblThemeParkMgmtSys.AutoSize = True
        Me.lblThemeParkMgmtSys.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblThemeParkMgmtSys.Font = New System.Drawing.Font("Modern No. 20", 27.75!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblThemeParkMgmtSys.ForeColor = System.Drawing.Color.Maroon
        Me.lblThemeParkMgmtSys.Location = New System.Drawing.Point(110, 49)
        Me.lblThemeParkMgmtSys.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblThemeParkMgmtSys.Name = "lblThemeParkMgmtSys"
        Me.lblThemeParkMgmtSys.Size = New System.Drawing.Size(523, 40)
        Me.lblThemeParkMgmtSys.TabIndex = 1
        Me.lblThemeParkMgmtSys.Text = "Theme Park Management System"
        '
        'tabPassbookFeatureTbcMain
        '
        Me.tabPassbookFeatureTbcMain.BackColor = System.Drawing.Color.Gainsboro
        Me.tabPassbookFeatureTbcMain.Controls.Add(Me.tbcPassbookFeatureMainTbcMain)
        Me.tabPassbookFeatureTbcMain.Location = New System.Drawing.Point(4, 28)
        Me.tabPassbookFeatureTbcMain.Name = "tabPassbookFeatureTbcMain"
        Me.tabPassbookFeatureTbcMain.Padding = New System.Windows.Forms.Padding(3)
        Me.tabPassbookFeatureTbcMain.Size = New System.Drawing.Size(646, 448)
        Me.tabPassbookFeatureTbcMain.TabIndex = 3
        Me.tabPassbookFeatureTbcMain.Text = "Passbook Features"
        Me.tipTPMS.SetToolTip(Me.tabPassbookFeatureTbcMain, "Passbook feature  options")
        '
        'tbcPassbookFeatureMainTbcMain
        '
        Me.tbcPassbookFeatureMainTbcMain.Appearance = System.Windows.Forms.TabAppearance.Buttons
        Me.tbcPassbookFeatureMainTbcMain.Controls.Add(Me.tabAddFeatureTbcPassbookFeatureMainTbcMain)
        Me.tbcPassbookFeatureMainTbcMain.Controls.Add(Me.tabUpdtFeatureTbcPassbookFeatureMainTbcMain)
        Me.tbcPassbookFeatureMainTbcMain.Controls.Add(Me.tabPostFeatureTbcPassbookFeatureMainTbcMain)
        Me.tbcPassbookFeatureMainTbcMain.Location = New System.Drawing.Point(34, 24)
        Me.tbcPassbookFeatureMainTbcMain.Name = "tbcPassbookFeatureMainTbcMain"
        Me.tbcPassbookFeatureMainTbcMain.SelectedIndex = 0
        Me.tbcPassbookFeatureMainTbcMain.Size = New System.Drawing.Size(579, 403)
        Me.tbcPassbookFeatureMainTbcMain.TabIndex = 0
        Me.tipTPMS.SetToolTip(Me.tbcPassbookFeatureMainTbcMain, "Update an existing passbook feature")
        '
        'tabAddFeatureTbcPassbookFeatureMainTbcMain
        '
        Me.tabAddFeatureTbcPassbookFeatureMainTbcMain.AllowDrop = True
        Me.tabAddFeatureTbcPassbookFeatureMainTbcMain.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.tabAddFeatureTbcPassbookFeatureMainTbcMain.Controls.Add(Me.grpAddFeatureTbcPassbookFeatureMainTbcMain)
        Me.tabAddFeatureTbcPassbookFeatureMainTbcMain.Location = New System.Drawing.Point(4, 28)
        Me.tabAddFeatureTbcPassbookFeatureMainTbcMain.Name = "tabAddFeatureTbcPassbookFeatureMainTbcMain"
        Me.tabAddFeatureTbcPassbookFeatureMainTbcMain.Padding = New System.Windows.Forms.Padding(3)
        Me.tabAddFeatureTbcPassbookFeatureMainTbcMain.Size = New System.Drawing.Size(571, 371)
        Me.tabAddFeatureTbcPassbookFeatureMainTbcMain.TabIndex = 0
        Me.tabAddFeatureTbcPassbookFeatureMainTbcMain.Text = "Add Feature"
        Me.tipTPMS.SetToolTip(Me.tabAddFeatureTbcPassbookFeatureMainTbcMain, "Add a new feature to the system")
        Me.tabAddFeatureTbcPassbookFeatureMainTbcMain.UseVisualStyleBackColor = True
        '
        'grpAddFeatureTbcPassbookFeatureMainTbcMain
        '
        Me.grpAddFeatureTbcPassbookFeatureMainTbcMain.Controls.Add(Me.Button3)
        Me.grpAddFeatureTbcPassbookFeatureMainTbcMain.Controls.Add(Me.Button4)
        Me.grpAddFeatureTbcPassbookFeatureMainTbcMain.Controls.Add(Me.txtPriceChildTabAddFeatureTbcPassbookFeatureMainTbcMain)
        Me.grpAddFeatureTbcPassbookFeatureMainTbcMain.Controls.Add(Me.lblPriceChildTabAddFeatureTbcPassbookFeatureMainTbcMain)
        Me.grpAddFeatureTbcPassbookFeatureMainTbcMain.Controls.Add(Me.txtPriceAdultTabAddFeatureTbcPassbookFeatureMainTbcMain)
        Me.grpAddFeatureTbcPassbookFeatureMainTbcMain.Controls.Add(Me.txtUnitOfMeasAddFeatureTbcPassbookFeatureMainTbcMain)
        Me.grpAddFeatureTbcPassbookFeatureMainTbcMain.Controls.Add(Me.lblUnitOfMeasTabAddFeatureTbcPassbookFeatureMainTbcMain)
        Me.grpAddFeatureTbcPassbookFeatureMainTbcMain.Controls.Add(Me.TextBox3)
        Me.grpAddFeatureTbcPassbookFeatureMainTbcMain.Controls.Add(Me.lblFeatureIdTabAddFeatureTbcPassbookFeatureMainTbcMain)
        Me.grpAddFeatureTbcPassbookFeatureMainTbcMain.Controls.Add(Me.txtFeatureIdTabAddFeatureTbcPassbookFeatureMainTbcMain)
        Me.grpAddFeatureTbcPassbookFeatureMainTbcMain.Controls.Add(Me.lblPriceTabAddFeatureTbcPassbookFeatureMainTbcMain)
        Me.grpAddFeatureTbcPassbookFeatureMainTbcMain.Controls.Add(Me.lblFeatureNameTabAddFeatureTbcPassbookFeatureMainTbcMain)
        Me.grpAddFeatureTbcPassbookFeatureMainTbcMain.Location = New System.Drawing.Point(24, 24)
        Me.grpAddFeatureTbcPassbookFeatureMainTbcMain.Name = "grpAddFeatureTbcPassbookFeatureMainTbcMain"
        Me.grpAddFeatureTbcPassbookFeatureMainTbcMain.Size = New System.Drawing.Size(523, 324)
        Me.grpAddFeatureTbcPassbookFeatureMainTbcMain.TabIndex = 0
        Me.grpAddFeatureTbcPassbookFeatureMainTbcMain.TabStop = False
        Me.grpAddFeatureTbcPassbookFeatureMainTbcMain.Text = "Feature Info"
        Me.tipTPMS.SetToolTip(Me.grpAddFeatureTbcPassbookFeatureMainTbcMain, "Enter feature specific information")
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(273, 288)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(75, 23)
        Me.Button3.TabIndex = 11
        Me.Button3.Text = "&Reset"
        Me.tipTPMS.SetToolTip(Me.Button3, "Click to reset all input fields")
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(178, 288)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(75, 23)
        Me.Button4.TabIndex = 10
        Me.Button4.Text = "&Submit"
        Me.tipTPMS.SetToolTip(Me.Button4, "Click to validate and submit feature information")
        Me.Button4.UseVisualStyleBackColor = True
        '
        'txtPriceChildTabAddFeatureTbcPassbookFeatureMainTbcMain
        '
        Me.txtPriceChildTabAddFeatureTbcPassbookFeatureMainTbcMain.Location = New System.Drawing.Point(197, 175)
        Me.txtPriceChildTabAddFeatureTbcPassbookFeatureMainTbcMain.Name = "txtPriceChildTabAddFeatureTbcPassbookFeatureMainTbcMain"
        Me.txtPriceChildTabAddFeatureTbcPassbookFeatureMainTbcMain.Size = New System.Drawing.Size(166, 22)
        Me.txtPriceChildTabAddFeatureTbcPassbookFeatureMainTbcMain.TabIndex = 9
        Me.tipTPMS.SetToolTip(Me.txtPriceChildTabAddFeatureTbcPassbookFeatureMainTbcMain, "Enter feature cost for a child ")
        '
        'lblPriceChildTabAddFeatureTbcPassbookFeatureMainTbcMain
        '
        Me.lblPriceChildTabAddFeatureTbcPassbookFeatureMainTbcMain.AutoSize = True
        Me.lblPriceChildTabAddFeatureTbcPassbookFeatureMainTbcMain.Location = New System.Drawing.Point(77, 178)
        Me.lblPriceChildTabAddFeatureTbcPassbookFeatureMainTbcMain.Name = "lblPriceChildTabAddFeatureTbcPassbookFeatureMainTbcMain"
        Me.lblPriceChildTabAddFeatureTbcPassbookFeatureMainTbcMain.Size = New System.Drawing.Size(107, 16)
        Me.lblPriceChildTabAddFeatureTbcPassbookFeatureMainTbcMain.TabIndex = 8
        Me.lblPriceChildTabAddFeatureTbcPassbookFeatureMainTbcMain.Text = "Price (Child < 13)"
        '
        'txtPriceAdultTabAddFeatureTbcPassbookFeatureMainTbcMain
        '
        Me.txtPriceAdultTabAddFeatureTbcPassbookFeatureMainTbcMain.Location = New System.Drawing.Point(197, 135)
        Me.txtPriceAdultTabAddFeatureTbcPassbookFeatureMainTbcMain.Name = "txtPriceAdultTabAddFeatureTbcPassbookFeatureMainTbcMain"
        Me.txtPriceAdultTabAddFeatureTbcPassbookFeatureMainTbcMain.Size = New System.Drawing.Size(166, 22)
        Me.txtPriceAdultTabAddFeatureTbcPassbookFeatureMainTbcMain.TabIndex = 7
        Me.tipTPMS.SetToolTip(Me.txtPriceAdultTabAddFeatureTbcPassbookFeatureMainTbcMain, "Enter feature cost fo an adult")
        '
        'txtUnitOfMeasAddFeatureTbcPassbookFeatureMainTbcMain
        '
        Me.txtUnitOfMeasAddFeatureTbcPassbookFeatureMainTbcMain.Location = New System.Drawing.Point(197, 97)
        Me.txtUnitOfMeasAddFeatureTbcPassbookFeatureMainTbcMain.Name = "txtUnitOfMeasAddFeatureTbcPassbookFeatureMainTbcMain"
        Me.txtUnitOfMeasAddFeatureTbcPassbookFeatureMainTbcMain.Size = New System.Drawing.Size(166, 22)
        Me.txtUnitOfMeasAddFeatureTbcPassbookFeatureMainTbcMain.TabIndex = 5
        Me.tipTPMS.SetToolTip(Me.txtUnitOfMeasAddFeatureTbcPassbookFeatureMainTbcMain, "Enter feature unit of measure (e.g ""Day"" for Parking Pass)")
        '
        'lblUnitOfMeasTabAddFeatureTbcPassbookFeatureMainTbcMain
        '
        Me.lblUnitOfMeasTabAddFeatureTbcPassbookFeatureMainTbcMain.AutoSize = True
        Me.lblUnitOfMeasTabAddFeatureTbcPassbookFeatureMainTbcMain.Location = New System.Drawing.Point(87, 100)
        Me.lblUnitOfMeasTabAddFeatureTbcPassbookFeatureMainTbcMain.Name = "lblUnitOfMeasTabAddFeatureTbcPassbookFeatureMainTbcMain"
        Me.lblUnitOfMeasTabAddFeatureTbcPassbookFeatureMainTbcMain.Size = New System.Drawing.Size(104, 16)
        Me.lblUnitOfMeasTabAddFeatureTbcPassbookFeatureMainTbcMain.TabIndex = 4
        Me.lblUnitOfMeasTabAddFeatureTbcPassbookFeatureMainTbcMain.Text = "Unit of Measure:"
        '
        'TextBox3
        '
        Me.TextBox3.Location = New System.Drawing.Point(197, 60)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(253, 22)
        Me.TextBox3.TabIndex = 3
        Me.tipTPMS.SetToolTip(Me.TextBox3, "Enter Feature name (e.g Meal Plan)")
        '
        'lblFeatureIdTabAddFeatureTbcPassbookFeatureMainTbcMain
        '
        Me.lblFeatureIdTabAddFeatureTbcPassbookFeatureMainTbcMain.AutoSize = True
        Me.lblFeatureIdTabAddFeatureTbcPassbookFeatureMainTbcMain.Location = New System.Drawing.Point(115, 29)
        Me.lblFeatureIdTabAddFeatureTbcPassbookFeatureMainTbcMain.Name = "lblFeatureIdTabAddFeatureTbcPassbookFeatureMainTbcMain"
        Me.lblFeatureIdTabAddFeatureTbcPassbookFeatureMainTbcMain.Size = New System.Drawing.Size(76, 16)
        Me.lblFeatureIdTabAddFeatureTbcPassbookFeatureMainTbcMain.TabIndex = 0
        Me.lblFeatureIdTabAddFeatureTbcPassbookFeatureMainTbcMain.Text = "Feature ID: "
        '
        'txtFeatureIdTabAddFeatureTbcPassbookFeatureMainTbcMain
        '
        Me.txtFeatureIdTabAddFeatureTbcPassbookFeatureMainTbcMain.Location = New System.Drawing.Point(197, 26)
        Me.txtFeatureIdTabAddFeatureTbcPassbookFeatureMainTbcMain.Name = "txtFeatureIdTabAddFeatureTbcPassbookFeatureMainTbcMain"
        Me.txtFeatureIdTabAddFeatureTbcPassbookFeatureMainTbcMain.Size = New System.Drawing.Size(148, 22)
        Me.txtFeatureIdTabAddFeatureTbcPassbookFeatureMainTbcMain.TabIndex = 1
        Me.tipTPMS.SetToolTip(Me.txtFeatureIdTabAddFeatureTbcPassbookFeatureMainTbcMain, "Enter the unique feature identifier")
        '
        'lblPriceTabAddFeatureTbcPassbookFeatureMainTbcMain
        '
        Me.lblPriceTabAddFeatureTbcPassbookFeatureMainTbcMain.AutoSize = True
        Me.lblPriceTabAddFeatureTbcPassbookFeatureMainTbcMain.Location = New System.Drawing.Point(104, 138)
        Me.lblPriceTabAddFeatureTbcPassbookFeatureMainTbcMain.Name = "lblPriceTabAddFeatureTbcPassbookFeatureMainTbcMain"
        Me.lblPriceTabAddFeatureTbcPassbookFeatureMainTbcMain.Size = New System.Drawing.Size(80, 16)
        Me.lblPriceTabAddFeatureTbcPassbookFeatureMainTbcMain.TabIndex = 6
        Me.lblPriceTabAddFeatureTbcPassbookFeatureMainTbcMain.Text = "Price (Adult)"
        '
        'lblFeatureNameTabAddFeatureTbcPassbookFeatureMainTbcMain
        '
        Me.lblFeatureNameTabAddFeatureTbcPassbookFeatureMainTbcMain.AutoSize = True
        Me.lblFeatureNameTabAddFeatureTbcPassbookFeatureMainTbcMain.Location = New System.Drawing.Point(94, 63)
        Me.lblFeatureNameTabAddFeatureTbcPassbookFeatureMainTbcMain.Name = "lblFeatureNameTabAddFeatureTbcPassbookFeatureMainTbcMain"
        Me.lblFeatureNameTabAddFeatureTbcPassbookFeatureMainTbcMain.Size = New System.Drawing.Size(97, 16)
        Me.lblFeatureNameTabAddFeatureTbcPassbookFeatureMainTbcMain.TabIndex = 2
        Me.lblFeatureNameTabAddFeatureTbcPassbookFeatureMainTbcMain.Text = "Feature Name:"
        '
        'tabUpdtFeatureTbcPassbookFeatureMainTbcMain
        '
        Me.tabUpdtFeatureTbcPassbookFeatureMainTbcMain.BackColor = System.Drawing.SystemColors.Control
        Me.tabUpdtFeatureTbcPassbookFeatureMainTbcMain.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.tabUpdtFeatureTbcPassbookFeatureMainTbcMain.Controls.Add(Me.grpUpdtFeatureTbcPassbookFeatureMainTbcMain)
        Me.tabUpdtFeatureTbcPassbookFeatureMainTbcMain.Location = New System.Drawing.Point(4, 28)
        Me.tabUpdtFeatureTbcPassbookFeatureMainTbcMain.Name = "tabUpdtFeatureTbcPassbookFeatureMainTbcMain"
        Me.tabUpdtFeatureTbcPassbookFeatureMainTbcMain.Padding = New System.Windows.Forms.Padding(3)
        Me.tabUpdtFeatureTbcPassbookFeatureMainTbcMain.Size = New System.Drawing.Size(571, 371)
        Me.tabUpdtFeatureTbcPassbookFeatureMainTbcMain.TabIndex = 1
        Me.tabUpdtFeatureTbcPassbookFeatureMainTbcMain.Text = "Update Feature"
        Me.tabUpdtFeatureTbcPassbookFeatureMainTbcMain.ToolTipText = "Update passbook feature"
        '
        'grpUpdtFeatureTbcPassbookFeatureMainTbcMain
        '
        Me.grpUpdtFeatureTbcPassbookFeatureMainTbcMain.Controls.Add(Me.btnResetTabUpdtFeatureTbcPassbookFeatureMainTbcMain)
        Me.grpUpdtFeatureTbcPassbookFeatureMainTbcMain.Controls.Add(Me.btnSubmitTabUpdtFeatureTbcPassbookFeatureMainTbcMain)
        Me.grpUpdtFeatureTbcPassbookFeatureMainTbcMain.Controls.Add(Me.TextBox1)
        Me.grpUpdtFeatureTbcPassbookFeatureMainTbcMain.Controls.Add(Me.lblQtyTabUpdtFeatureTbcPassbookFeatureMainTbcMain)
        Me.grpUpdtFeatureTbcPassbookFeatureMainTbcMain.Controls.Add(Me.NumericUpDown1)
        Me.grpUpdtFeatureTbcPassbookFeatureMainTbcMain.Controls.Add(Me.lstPassbookTabUpdtFeatureTbcPassbookFeatureMainTbcMain)
        Me.grpUpdtFeatureTbcPassbookFeatureMainTbcMain.Controls.Add(Me.lblPassbookTabUpdtFeatureTbcPassbookFeatureMainTbcMain)
        Me.grpUpdtFeatureTbcPassbookFeatureMainTbcMain.Controls.Add(Me.lblPassbookIdTabUpdtFeatureTbcPassbookFeatureMainTbcMain)
        Me.grpUpdtFeatureTbcPassbookFeatureMainTbcMain.Controls.Add(Me.txtPassbookIdTabUpdtFeatureTbcPassbookFeatureMainTbcMain)
        Me.grpUpdtFeatureTbcPassbookFeatureMainTbcMain.Location = New System.Drawing.Point(24, 24)
        Me.grpUpdtFeatureTbcPassbookFeatureMainTbcMain.Name = "grpUpdtFeatureTbcPassbookFeatureMainTbcMain"
        Me.grpUpdtFeatureTbcPassbookFeatureMainTbcMain.Size = New System.Drawing.Size(523, 324)
        Me.grpUpdtFeatureTbcPassbookFeatureMainTbcMain.TabIndex = 0
        Me.grpUpdtFeatureTbcPassbookFeatureMainTbcMain.TabStop = False
        Me.grpUpdtFeatureTbcPassbookFeatureMainTbcMain.Text = "Passbook Feature Info"
        Me.tipTPMS.SetToolTip(Me.grpUpdtFeatureTbcPassbookFeatureMainTbcMain, "Enter passbook feature specific informatin")
        '
        'btnResetTabUpdtFeatureTbcPassbookFeatureMainTbcMain
        '
        Me.btnResetTabUpdtFeatureTbcPassbookFeatureMainTbcMain.Location = New System.Drawing.Point(273, 288)
        Me.btnResetTabUpdtFeatureTbcPassbookFeatureMainTbcMain.Name = "btnResetTabUpdtFeatureTbcPassbookFeatureMainTbcMain"
        Me.btnResetTabUpdtFeatureTbcPassbookFeatureMainTbcMain.Size = New System.Drawing.Size(75, 23)
        Me.btnResetTabUpdtFeatureTbcPassbookFeatureMainTbcMain.TabIndex = 8
        Me.btnResetTabUpdtFeatureTbcPassbookFeatureMainTbcMain.Text = "&Reset"
        Me.tipTPMS.SetToolTip(Me.btnResetTabUpdtFeatureTbcPassbookFeatureMainTbcMain, "Click to reset all input fields")
        Me.btnResetTabUpdtFeatureTbcPassbookFeatureMainTbcMain.UseVisualStyleBackColor = True
        '
        'btnSubmitTabUpdtFeatureTbcPassbookFeatureMainTbcMain
        '
        Me.btnSubmitTabUpdtFeatureTbcPassbookFeatureMainTbcMain.Location = New System.Drawing.Point(178, 288)
        Me.btnSubmitTabUpdtFeatureTbcPassbookFeatureMainTbcMain.Name = "btnSubmitTabUpdtFeatureTbcPassbookFeatureMainTbcMain"
        Me.btnSubmitTabUpdtFeatureTbcPassbookFeatureMainTbcMain.Size = New System.Drawing.Size(75, 23)
        Me.btnSubmitTabUpdtFeatureTbcPassbookFeatureMainTbcMain.TabIndex = 7
        Me.btnSubmitTabUpdtFeatureTbcPassbookFeatureMainTbcMain.Text = "&Submit"
        Me.tipTPMS.SetToolTip(Me.btnSubmitTabUpdtFeatureTbcPassbookFeatureMainTbcMain, "Click to validate and submit passbook feature")
        Me.btnSubmitTabUpdtFeatureTbcPassbookFeatureMainTbcMain.UseVisualStyleBackColor = True
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(95, 134)
        Me.TextBox1.Multiline = True
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(354, 61)
        Me.TextBox1.TabIndex = 6
        Me.TextBox1.Text = "NOTE To Grader:  I am planning on displaying " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "a separate form that shows the Pas" &
    "sbook/Customer/" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Feature info when the Passbook selection is made"
        '
        'lblQtyTabUpdtFeatureTbcPassbookFeatureMainTbcMain
        '
        Me.lblQtyTabUpdtFeatureTbcPassbookFeatureMainTbcMain.AutoSize = True
        Me.lblQtyTabUpdtFeatureTbcPassbookFeatureMainTbcMain.Location = New System.Drawing.Point(105, 91)
        Me.lblQtyTabUpdtFeatureTbcPassbookFeatureMainTbcMain.Name = "lblQtyTabUpdtFeatureTbcPassbookFeatureMainTbcMain"
        Me.lblQtyTabUpdtFeatureTbcPassbookFeatureMainTbcMain.Size = New System.Drawing.Size(59, 16)
        Me.lblQtyTabUpdtFeatureTbcPassbookFeatureMainTbcMain.TabIndex = 4
        Me.lblQtyTabUpdtFeatureTbcPassbookFeatureMainTbcMain.Text = "Quantity:"
        Me.tipTPMS.SetToolTip(Me.lblQtyTabUpdtFeatureTbcPassbookFeatureMainTbcMain, "Enter the update passbook feature quantity")
        '
        'NumericUpDown1
        '
        Me.NumericUpDown1.Location = New System.Drawing.Point(170, 89)
        Me.NumericUpDown1.Name = "NumericUpDown1"
        Me.NumericUpDown1.Size = New System.Drawing.Size(66, 22)
        Me.NumericUpDown1.TabIndex = 5
        Me.tipTPMS.SetToolTip(Me.NumericUpDown1, "Enter updated feature quantity")
        Me.NumericUpDown1.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'lstPassbookTabUpdtFeatureTbcPassbookFeatureMainTbcMain
        '
        Me.lstPassbookTabUpdtFeatureTbcPassbookFeatureMainTbcMain.FormattingEnabled = True
        Me.lstPassbookTabUpdtFeatureTbcPassbookFeatureMainTbcMain.ItemHeight = 16
        Me.lstPassbookTabUpdtFeatureTbcPassbookFeatureMainTbcMain.Items.AddRange(New Object() {"Passbook 1", "Passbook 2", "Passbook 3", "Passbook 4"})
        Me.lstPassbookTabUpdtFeatureTbcPassbookFeatureMainTbcMain.Location = New System.Drawing.Point(170, 58)
        Me.lstPassbookTabUpdtFeatureTbcPassbookFeatureMainTbcMain.Name = "lstPassbookTabUpdtFeatureTbcPassbookFeatureMainTbcMain"
        Me.lstPassbookTabUpdtFeatureTbcPassbookFeatureMainTbcMain.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple
        Me.lstPassbookTabUpdtFeatureTbcPassbookFeatureMainTbcMain.Size = New System.Drawing.Size(241, 20)
        Me.lstPassbookTabUpdtFeatureTbcPassbookFeatureMainTbcMain.TabIndex = 3
        Me.tipTPMS.SetToolTip(Me.lstPassbookTabUpdtFeatureTbcPassbookFeatureMainTbcMain, "Select the desired passbook from the list")
        '
        'lblPassbookTabUpdtFeatureTbcPassbookFeatureMainTbcMain
        '
        Me.lblPassbookTabUpdtFeatureTbcPassbookFeatureMainTbcMain.AutoSize = True
        Me.lblPassbookTabUpdtFeatureTbcPassbookFeatureMainTbcMain.Location = New System.Drawing.Point(91, 62)
        Me.lblPassbookTabUpdtFeatureTbcPassbookFeatureMainTbcMain.Name = "lblPassbookTabUpdtFeatureTbcPassbookFeatureMainTbcMain"
        Me.lblPassbookTabUpdtFeatureTbcPassbookFeatureMainTbcMain.Size = New System.Drawing.Size(73, 16)
        Me.lblPassbookTabUpdtFeatureTbcPassbookFeatureMainTbcMain.TabIndex = 2
        Me.lblPassbookTabUpdtFeatureTbcPassbookFeatureMainTbcMain.Text = "Passbook:"
        '
        'lblPassbookIdTabUpdtFeatureTbcPassbookFeatureMainTbcMain
        '
        Me.lblPassbookIdTabUpdtFeatureTbcPassbookFeatureMainTbcMain.AutoSize = True
        Me.lblPassbookIdTabUpdtFeatureTbcPassbookFeatureMainTbcMain.Location = New System.Drawing.Point(69, 29)
        Me.lblPassbookIdTabUpdtFeatureTbcPassbookFeatureMainTbcMain.Name = "lblPassbookIdTabUpdtFeatureTbcPassbookFeatureMainTbcMain"
        Me.lblPassbookIdTabUpdtFeatureTbcPassbookFeatureMainTbcMain.Size = New System.Drawing.Size(95, 16)
        Me.lblPassbookIdTabUpdtFeatureTbcPassbookFeatureMainTbcMain.TabIndex = 0
        Me.lblPassbookIdTabUpdtFeatureTbcPassbookFeatureMainTbcMain.Text = "Passbook  ID: "
        Me.tipTPMS.SetToolTip(Me.lblPassbookIdTabUpdtFeatureTbcPassbookFeatureMainTbcMain, "Enter unique passbook ID or select from dropdown list")
        '
        'txtPassbookIdTabUpdtFeatureTbcPassbookFeatureMainTbcMain
        '
        Me.txtPassbookIdTabUpdtFeatureTbcPassbookFeatureMainTbcMain.AccessibleRole = System.Windows.Forms.AccessibleRole.None
        Me.txtPassbookIdTabUpdtFeatureTbcPassbookFeatureMainTbcMain.Location = New System.Drawing.Point(170, 26)
        Me.txtPassbookIdTabUpdtFeatureTbcPassbookFeatureMainTbcMain.Name = "txtPassbookIdTabUpdtFeatureTbcPassbookFeatureMainTbcMain"
        Me.txtPassbookIdTabUpdtFeatureTbcPassbookFeatureMainTbcMain.Size = New System.Drawing.Size(140, 22)
        Me.txtPassbookIdTabUpdtFeatureTbcPassbookFeatureMainTbcMain.TabIndex = 1
        Me.tipTPMS.SetToolTip(Me.txtPassbookIdTabUpdtFeatureTbcPassbookFeatureMainTbcMain, "Enter the unique passbook identifier")
        '
        'tabPostFeatureTbcPassbookFeatureMainTbcMain
        '
        Me.tabPostFeatureTbcPassbookFeatureMainTbcMain.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.tabPostFeatureTbcPassbookFeatureMainTbcMain.Controls.Add(Me.grpPostFeatureTbcPassbookFeatureMainTbcMain)
        Me.tabPostFeatureTbcPassbookFeatureMainTbcMain.Location = New System.Drawing.Point(4, 28)
        Me.tabPostFeatureTbcPassbookFeatureMainTbcMain.Name = "tabPostFeatureTbcPassbookFeatureMainTbcMain"
        Me.tabPostFeatureTbcPassbookFeatureMainTbcMain.Padding = New System.Windows.Forms.Padding(3)
        Me.tabPostFeatureTbcPassbookFeatureMainTbcMain.Size = New System.Drawing.Size(571, 371)
        Me.tabPostFeatureTbcPassbookFeatureMainTbcMain.TabIndex = 2
        Me.tabPostFeatureTbcPassbookFeatureMainTbcMain.Text = "Post Feature"
        Me.tipTPMS.SetToolTip(Me.tabPostFeatureTbcPassbookFeatureMainTbcMain, "Register use of a specific feature")
        Me.tabPostFeatureTbcPassbookFeatureMainTbcMain.UseVisualStyleBackColor = True
        '
        'grpPostFeatureTbcPassbookFeatureMainTbcMain
        '
        Me.grpPostFeatureTbcPassbookFeatureMainTbcMain.Controls.Add(Me.Button2)
        Me.grpPostFeatureTbcPassbookFeatureMainTbcMain.Controls.Add(Me.TextBox5)
        Me.grpPostFeatureTbcPassbookFeatureMainTbcMain.Controls.Add(Me.btnSubmitGrpUpdtFeatureTbcPassbookFeatureMainTbcMain)
        Me.grpPostFeatureTbcPassbookFeatureMainTbcMain.Controls.Add(Me.lblLocationGrpUpdtFeatureTbcPassbookFeatureMainTbcMain)
        Me.grpPostFeatureTbcPassbookFeatureMainTbcMain.Controls.Add(Me.lstFeatureGrpUpdtFeatureTbcPassbookFeatureMainTbcMain)
        Me.grpPostFeatureTbcPassbookFeatureMainTbcMain.Controls.Add(Me.lblFeatureGrpUpdtFeatureTbcPassbookFeatureMainTbcMain)
        Me.grpPostFeatureTbcPassbookFeatureMainTbcMain.Controls.Add(Me.TextBox4)
        Me.grpPostFeatureTbcPassbookFeatureMainTbcMain.Controls.Add(Me.lblQtyGrpUpdtFeatureTbcPassbookFeatureMainTbcMain)
        Me.grpPostFeatureTbcPassbookFeatureMainTbcMain.Controls.Add(Me.NumericUpDown2)
        Me.grpPostFeatureTbcPassbookFeatureMainTbcMain.Controls.Add(Me.lstPassbookGrpUpdtFeatureTbcPassbookFeatureMainTbcMain)
        Me.grpPostFeatureTbcPassbookFeatureMainTbcMain.Controls.Add(Me.lblPassbookGrpUpdtFeatureTbcPassbookFeatureMainTbcMain)
        Me.grpPostFeatureTbcPassbookFeatureMainTbcMain.Controls.Add(Me.lblPassbookFeatureIddGrpUpdtFeatureTbcPassbookFeatureMainTbcMain)
        Me.grpPostFeatureTbcPassbookFeatureMainTbcMain.Controls.Add(Me.txtPassbookFeatureIddGrpUpdtFeatureTbcPassbookFeatureMainTbcMain)
        Me.grpPostFeatureTbcPassbookFeatureMainTbcMain.Location = New System.Drawing.Point(24, 24)
        Me.grpPostFeatureTbcPassbookFeatureMainTbcMain.Name = "grpPostFeatureTbcPassbookFeatureMainTbcMain"
        Me.grpPostFeatureTbcPassbookFeatureMainTbcMain.Size = New System.Drawing.Size(523, 324)
        Me.grpPostFeatureTbcPassbookFeatureMainTbcMain.TabIndex = 0
        Me.grpPostFeatureTbcPassbookFeatureMainTbcMain.TabStop = False
        Me.grpPostFeatureTbcPassbookFeatureMainTbcMain.Text = "Feature Info"
        Me.tipTPMS.SetToolTip(Me.grpPostFeatureTbcPassbookFeatureMainTbcMain, "Enter feature specific information")
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(273, 288)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(75, 23)
        Me.Button2.TabIndex = 12
        Me.Button2.Text = "&Reset"
        Me.tipTPMS.SetToolTip(Me.Button2, "Click to reset all input fields")
        Me.Button2.UseVisualStyleBackColor = True
        '
        'TextBox5
        '
        Me.TextBox5.AccessibleRole = System.Windows.Forms.AccessibleRole.None
        Me.TextBox5.Location = New System.Drawing.Point(199, 171)
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.Size = New System.Drawing.Size(249, 22)
        Me.TextBox5.TabIndex = 9
        Me.tipTPMS.SetToolTip(Me.TextBox5, "Enter the passbook feature id to be posted")
        '
        'btnSubmitGrpUpdtFeatureTbcPassbookFeatureMainTbcMain
        '
        Me.btnSubmitGrpUpdtFeatureTbcPassbookFeatureMainTbcMain.Location = New System.Drawing.Point(178, 288)
        Me.btnSubmitGrpUpdtFeatureTbcPassbookFeatureMainTbcMain.Name = "btnSubmitGrpUpdtFeatureTbcPassbookFeatureMainTbcMain"
        Me.btnSubmitGrpUpdtFeatureTbcPassbookFeatureMainTbcMain.Size = New System.Drawing.Size(75, 23)
        Me.btnSubmitGrpUpdtFeatureTbcPassbookFeatureMainTbcMain.TabIndex = 11
        Me.btnSubmitGrpUpdtFeatureTbcPassbookFeatureMainTbcMain.Text = "&Submit"
        Me.tipTPMS.SetToolTip(Me.btnSubmitGrpUpdtFeatureTbcPassbookFeatureMainTbcMain, "Click to validate and submit feature information")
        Me.btnSubmitGrpUpdtFeatureTbcPassbookFeatureMainTbcMain.UseVisualStyleBackColor = True
        '
        'lblLocationGrpUpdtFeatureTbcPassbookFeatureMainTbcMain
        '
        Me.lblLocationGrpUpdtFeatureTbcPassbookFeatureMainTbcMain.AutoSize = True
        Me.lblLocationGrpUpdtFeatureTbcPassbookFeatureMainTbcMain.Location = New System.Drawing.Point(131, 171)
        Me.lblLocationGrpUpdtFeatureTbcPassbookFeatureMainTbcMain.Name = "lblLocationGrpUpdtFeatureTbcPassbookFeatureMainTbcMain"
        Me.lblLocationGrpUpdtFeatureTbcPassbookFeatureMainTbcMain.Size = New System.Drawing.Size(62, 16)
        Me.lblLocationGrpUpdtFeatureTbcPassbookFeatureMainTbcMain.TabIndex = 8
        Me.lblLocationGrpUpdtFeatureTbcPassbookFeatureMainTbcMain.Text = "Location:"
        Me.tipTPMS.SetToolTip(Me.lblLocationGrpUpdtFeatureTbcPassbookFeatureMainTbcMain, "Enter the location where transaction occurred")
        '
        'lstFeatureGrpUpdtFeatureTbcPassbookFeatureMainTbcMain
        '
        Me.lstFeatureGrpUpdtFeatureTbcPassbookFeatureMainTbcMain.AccessibleRole = System.Windows.Forms.AccessibleRole.None
        Me.lstFeatureGrpUpdtFeatureTbcPassbookFeatureMainTbcMain.FormattingEnabled = True
        Me.lstFeatureGrpUpdtFeatureTbcPassbookFeatureMainTbcMain.ItemHeight = 16
        Me.lstFeatureGrpUpdtFeatureTbcPassbookFeatureMainTbcMain.Items.AddRange(New Object() {"", "Park Pass", "Parking Lot Pass", "Meal Plan", "Early Entry Pass"})
        Me.lstFeatureGrpUpdtFeatureTbcPassbookFeatureMainTbcMain.Location = New System.Drawing.Point(199, 102)
        Me.lstFeatureGrpUpdtFeatureTbcPassbookFeatureMainTbcMain.Name = "lstFeatureGrpUpdtFeatureTbcPassbookFeatureMainTbcMain"
        Me.lstFeatureGrpUpdtFeatureTbcPassbookFeatureMainTbcMain.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple
        Me.lstFeatureGrpUpdtFeatureTbcPassbookFeatureMainTbcMain.Size = New System.Drawing.Size(249, 20)
        Me.lstFeatureGrpUpdtFeatureTbcPassbookFeatureMainTbcMain.TabIndex = 5
        Me.tipTPMS.SetToolTip(Me.lstFeatureGrpUpdtFeatureTbcPassbookFeatureMainTbcMain, "Select the desired passbook from the list")
        '
        'lblFeatureGrpUpdtFeatureTbcPassbookFeatureMainTbcMain
        '
        Me.lblFeatureGrpUpdtFeatureTbcPassbookFeatureMainTbcMain.AutoSize = True
        Me.lblFeatureGrpUpdtFeatureTbcPassbookFeatureMainTbcMain.Location = New System.Drawing.Point(136, 102)
        Me.lblFeatureGrpUpdtFeatureTbcPassbookFeatureMainTbcMain.Name = "lblFeatureGrpUpdtFeatureTbcPassbookFeatureMainTbcMain"
        Me.lblFeatureGrpUpdtFeatureTbcPassbookFeatureMainTbcMain.Size = New System.Drawing.Size(57, 16)
        Me.lblFeatureGrpUpdtFeatureTbcPassbookFeatureMainTbcMain.TabIndex = 4
        Me.lblFeatureGrpUpdtFeatureTbcPassbookFeatureMainTbcMain.Text = "Feature:"
        Me.tipTPMS.SetToolTip(Me.lblFeatureGrpUpdtFeatureTbcPassbookFeatureMainTbcMain, "Select desire feature from the list")
        '
        'TextBox4
        '
        Me.TextBox4.Location = New System.Drawing.Point(86, 218)
        Me.TextBox4.Multiline = True
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Size = New System.Drawing.Size(362, 36)
        Me.TextBox4.TabIndex = 10
        Me.TextBox4.Text = "NOTE To Grader:  I am planning on displaying a popup  form with passbook/feature " &
    "detail."
        '
        'lblQtyGrpUpdtFeatureTbcPassbookFeatureMainTbcMain
        '
        Me.lblQtyGrpUpdtFeatureTbcPassbookFeatureMainTbcMain.AutoSize = True
        Me.lblQtyGrpUpdtFeatureTbcPassbookFeatureMainTbcMain.Location = New System.Drawing.Point(134, 139)
        Me.lblQtyGrpUpdtFeatureTbcPassbookFeatureMainTbcMain.Name = "lblQtyGrpUpdtFeatureTbcPassbookFeatureMainTbcMain"
        Me.lblQtyGrpUpdtFeatureTbcPassbookFeatureMainTbcMain.Size = New System.Drawing.Size(59, 16)
        Me.lblQtyGrpUpdtFeatureTbcPassbookFeatureMainTbcMain.TabIndex = 6
        Me.lblQtyGrpUpdtFeatureTbcPassbookFeatureMainTbcMain.Text = "Quantity:"
        Me.tipTPMS.SetToolTip(Me.lblQtyGrpUpdtFeatureTbcPassbookFeatureMainTbcMain, "Enter the adjusted passbook feature quantity")
        '
        'NumericUpDown2
        '
        Me.NumericUpDown2.Location = New System.Drawing.Point(199, 137)
        Me.NumericUpDown2.Name = "NumericUpDown2"
        Me.NumericUpDown2.Size = New System.Drawing.Size(74, 22)
        Me.NumericUpDown2.TabIndex = 7
        Me.NumericUpDown2.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'lstPassbookGrpUpdtFeatureTbcPassbookFeatureMainTbcMain
        '
        Me.lstPassbookGrpUpdtFeatureTbcPassbookFeatureMainTbcMain.FormattingEnabled = True
        Me.lstPassbookGrpUpdtFeatureTbcPassbookFeatureMainTbcMain.ItemHeight = 16
        Me.lstPassbookGrpUpdtFeatureTbcPassbookFeatureMainTbcMain.Items.AddRange(New Object() {"", "Passbook 1", "Passbook 2", "Passbook 3", "Passbook 4"})
        Me.lstPassbookGrpUpdtFeatureTbcPassbookFeatureMainTbcMain.Location = New System.Drawing.Point(199, 72)
        Me.lstPassbookGrpUpdtFeatureTbcPassbookFeatureMainTbcMain.Name = "lstPassbookGrpUpdtFeatureTbcPassbookFeatureMainTbcMain"
        Me.lstPassbookGrpUpdtFeatureTbcPassbookFeatureMainTbcMain.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple
        Me.lstPassbookGrpUpdtFeatureTbcPassbookFeatureMainTbcMain.Size = New System.Drawing.Size(249, 20)
        Me.lstPassbookGrpUpdtFeatureTbcPassbookFeatureMainTbcMain.TabIndex = 3
        Me.tipTPMS.SetToolTip(Me.lstPassbookGrpUpdtFeatureTbcPassbookFeatureMainTbcMain, "Select the desired passbook from the list")
        '
        'lblPassbookGrpUpdtFeatureTbcPassbookFeatureMainTbcMain
        '
        Me.lblPassbookGrpUpdtFeatureTbcPassbookFeatureMainTbcMain.AutoSize = True
        Me.lblPassbookGrpUpdtFeatureTbcPassbookFeatureMainTbcMain.Location = New System.Drawing.Point(120, 72)
        Me.lblPassbookGrpUpdtFeatureTbcPassbookFeatureMainTbcMain.Name = "lblPassbookGrpUpdtFeatureTbcPassbookFeatureMainTbcMain"
        Me.lblPassbookGrpUpdtFeatureTbcPassbookFeatureMainTbcMain.Size = New System.Drawing.Size(73, 16)
        Me.lblPassbookGrpUpdtFeatureTbcPassbookFeatureMainTbcMain.TabIndex = 2
        Me.lblPassbookGrpUpdtFeatureTbcPassbookFeatureMainTbcMain.Text = "Passbook:"
        Me.tipTPMS.SetToolTip(Me.lblPassbookGrpUpdtFeatureTbcPassbookFeatureMainTbcMain, "Select desire passbook from the list")
        '
        'lblPassbookFeatureIddGrpUpdtFeatureTbcPassbookFeatureMainTbcMain
        '
        Me.lblPassbookFeatureIddGrpUpdtFeatureTbcPassbookFeatureMainTbcMain.AutoSize = True
        Me.lblPassbookFeatureIddGrpUpdtFeatureTbcPassbookFeatureMainTbcMain.Location = New System.Drawing.Point(55, 35)
        Me.lblPassbookFeatureIddGrpUpdtFeatureTbcPassbookFeatureMainTbcMain.Name = "lblPassbookFeatureIddGrpUpdtFeatureTbcPassbookFeatureMainTbcMain"
        Me.lblPassbookFeatureIddGrpUpdtFeatureTbcPassbookFeatureMainTbcMain.Size = New System.Drawing.Size(138, 16)
        Me.lblPassbookFeatureIddGrpUpdtFeatureTbcPassbookFeatureMainTbcMain.TabIndex = 0
        Me.lblPassbookFeatureIddGrpUpdtFeatureTbcPassbookFeatureMainTbcMain.Text = "Passbook Feature ID:"
        Me.tipTPMS.SetToolTip(Me.lblPassbookFeatureIddGrpUpdtFeatureTbcPassbookFeatureMainTbcMain, "Enter the assigned transaction ID")
        '
        'txtPassbookFeatureIddGrpUpdtFeatureTbcPassbookFeatureMainTbcMain
        '
        Me.txtPassbookFeatureIddGrpUpdtFeatureTbcPassbookFeatureMainTbcMain.AccessibleRole = System.Windows.Forms.AccessibleRole.None
        Me.txtPassbookFeatureIddGrpUpdtFeatureTbcPassbookFeatureMainTbcMain.Location = New System.Drawing.Point(199, 32)
        Me.txtPassbookFeatureIddGrpUpdtFeatureTbcPassbookFeatureMainTbcMain.Name = "txtPassbookFeatureIddGrpUpdtFeatureTbcPassbookFeatureMainTbcMain"
        Me.txtPassbookFeatureIddGrpUpdtFeatureTbcPassbookFeatureMainTbcMain.Size = New System.Drawing.Size(144, 22)
        Me.txtPassbookFeatureIddGrpUpdtFeatureTbcPassbookFeatureMainTbcMain.TabIndex = 1
        Me.tipTPMS.SetToolTip(Me.txtPassbookFeatureIddGrpUpdtFeatureTbcPassbookFeatureMainTbcMain, "Enter the passbook feature identifier to be posted")
        '
        'tabPurchaseTbcMain
        '
        Me.tabPurchaseTbcMain.BackColor = System.Drawing.Color.Gainsboro
        Me.tabPurchaseTbcMain.Controls.Add(Me.tbcPurchaseMainTabPurchaseTbcMain)
        Me.tabPurchaseTbcMain.Location = New System.Drawing.Point(4, 28)
        Me.tabPurchaseTbcMain.Name = "tabPurchaseTbcMain"
        Me.tabPurchaseTbcMain.Padding = New System.Windows.Forms.Padding(3)
        Me.tabPurchaseTbcMain.Size = New System.Drawing.Size(646, 448)
        Me.tabPurchaseTbcMain.TabIndex = 2
        Me.tabPurchaseTbcMain.Text = "Purchase"
        Me.tipTPMS.SetToolTip(Me.tabPurchaseTbcMain, "Passbook and Features purchases")
        '
        'tbcPurchaseMainTabPurchaseTbcMain
        '
        Me.tbcPurchaseMainTabPurchaseTbcMain.Appearance = System.Windows.Forms.TabAppearance.Buttons
        Me.tbcPurchaseMainTabPurchaseTbcMain.Controls.Add(Me.tabPassbookTbcPurchaseMainTabPurchaseTbcMain)
        Me.tbcPurchaseMainTabPurchaseTbcMain.Controls.Add(Me.tabFeatureTbcPurchaseMainTabPurchaseTbcMain)
        Me.tbcPurchaseMainTabPurchaseTbcMain.Location = New System.Drawing.Point(34, 24)
        Me.tbcPurchaseMainTabPurchaseTbcMain.Name = "tbcPurchaseMainTabPurchaseTbcMain"
        Me.tbcPurchaseMainTabPurchaseTbcMain.SelectedIndex = 0
        Me.tbcPurchaseMainTabPurchaseTbcMain.Size = New System.Drawing.Size(579, 403)
        Me.tbcPurchaseMainTabPurchaseTbcMain.TabIndex = 0
        Me.tipTPMS.SetToolTip(Me.tbcPurchaseMainTabPurchaseTbcMain, "Purchase a new feature")
        '
        'tabPassbookTbcPurchaseMainTabPurchaseTbcMain
        '
        Me.tabPassbookTbcPurchaseMainTabPurchaseTbcMain.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.tabPassbookTbcPurchaseMainTabPurchaseTbcMain.Controls.Add(Me.grpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain)
        Me.tabPassbookTbcPurchaseMainTabPurchaseTbcMain.Location = New System.Drawing.Point(4, 28)
        Me.tabPassbookTbcPurchaseMainTabPurchaseTbcMain.Name = "tabPassbookTbcPurchaseMainTabPurchaseTbcMain"
        Me.tabPassbookTbcPurchaseMainTabPurchaseTbcMain.Padding = New System.Windows.Forms.Padding(3)
        Me.tabPassbookTbcPurchaseMainTabPurchaseTbcMain.Size = New System.Drawing.Size(571, 371)
        Me.tabPassbookTbcPurchaseMainTabPurchaseTbcMain.TabIndex = 0
        Me.tabPassbookTbcPurchaseMainTabPurchaseTbcMain.Text = "Passbook"
        Me.tipTPMS.SetToolTip(Me.tabPassbookTbcPurchaseMainTabPurchaseTbcMain, "Enter new Passbook information")
        Me.tabPassbookTbcPurchaseMainTabPurchaseTbcMain.UseVisualStyleBackColor = True
        '
        'grpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain
        '
        Me.grpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Controls.Add(Me.btnResetGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain)
        Me.grpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Controls.Add(Me.chkVChildPassbookIfnoTabPassbookTbcPurchaseMainTabPurchaseTbcMain)
        Me.grpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Controls.Add(Me.btnSubmitGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain)
        Me.grpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Controls.Add(Me.txtVNameGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain)
        Me.grpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Controls.Add(Me.lblVNameGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain)
        Me.grpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Controls.Add(Me.dtpVDOBGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain)
        Me.grpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Controls.Add(Me.txtDatePurchasedGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain)
        Me.grpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Controls.Add(Me.lstCustNameGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain)
        Me.grpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Controls.Add(Me.lblDatePurchasedGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain)
        Me.grpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Controls.Add(Me.lblPassbookIdGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain)
        Me.grpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Controls.Add(Me.txtTransactIdGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain)
        Me.grpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Controls.Add(Me.lblVDOBGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain)
        Me.grpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Controls.Add(Me.lblCustNameGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain)
        Me.grpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Location = New System.Drawing.Point(24, 24)
        Me.grpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Name = "grpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain"
        Me.grpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Size = New System.Drawing.Size(523, 324)
        Me.grpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.TabIndex = 13
        Me.grpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.TabStop = False
        Me.grpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Text = "Passbook Info"
        Me.tipTPMS.SetToolTip(Me.grpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain, "Enter passbook specific information")
        '
        'btnResetGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain
        '
        Me.btnResetGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Location = New System.Drawing.Point(273, 288)
        Me.btnResetGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Name = "btnResetGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain"
        Me.btnResetGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Size = New System.Drawing.Size(75, 23)
        Me.btnResetGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.TabIndex = 12
        Me.btnResetGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Text = "&Reset"
        Me.tipTPMS.SetToolTip(Me.btnResetGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain, "Click to reset input fields")
        Me.btnResetGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.UseVisualStyleBackColor = True
        '
        'chkVChildPassbookIfnoTabPassbookTbcPurchaseMainTabPurchaseTbcMain
        '
        Me.chkVChildPassbookIfnoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.AutoSize = True
        Me.chkVChildPassbookIfnoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Enabled = False
        Me.chkVChildPassbookIfnoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.chkVChildPassbookIfnoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Location = New System.Drawing.Point(335, 127)
        Me.chkVChildPassbookIfnoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Name = "chkVChildPassbookIfnoTabPassbookTbcPurchaseMainTabPurchaseTbcMain"
        Me.chkVChildPassbookIfnoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Size = New System.Drawing.Size(55, 20)
        Me.chkVChildPassbookIfnoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.TabIndex = 8
        Me.chkVChildPassbookIfnoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Text = "Child"
        Me.tipTPMS.SetToolTip(Me.chkVChildPassbookIfnoTabPassbookTbcPurchaseMainTabPurchaseTbcMain, "Auto-checked if visitor is under age of 13")
        Me.chkVChildPassbookIfnoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.UseVisualStyleBackColor = True
        '
        'btnSubmitGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain
        '
        Me.btnSubmitGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Location = New System.Drawing.Point(178, 288)
        Me.btnSubmitGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Name = "btnSubmitGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain"
        Me.btnSubmitGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Size = New System.Drawing.Size(75, 23)
        Me.btnSubmitGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.TabIndex = 11
        Me.btnSubmitGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Text = "&Submit"
        Me.tipTPMS.SetToolTip(Me.btnSubmitGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain, "Click to validate and submit passbook purchase")
        Me.btnSubmitGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.UseVisualStyleBackColor = True
        '
        'txtVNameGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain
        '
        Me.txtVNameGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Location = New System.Drawing.Point(193, 95)
        Me.txtVNameGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Name = "txtVNameGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain"
        Me.txtVNameGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Size = New System.Drawing.Size(249, 22)
        Me.txtVNameGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.TabIndex = 5
        Me.tipTPMS.SetToolTip(Me.txtVNameGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain, "Enter Vistor name <Lastname, Firstname>")
        '
        'lblVNameGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain
        '
        Me.lblVNameGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.AutoSize = True
        Me.lblVNameGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Location = New System.Drawing.Point(99, 98)
        Me.lblVNameGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Name = "lblVNameGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain"
        Me.lblVNameGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Size = New System.Drawing.Size(88, 16)
        Me.lblVNameGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.TabIndex = 4
        Me.lblVNameGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Text = "Visitor Name:"
        '
        'dtpVDOBGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain
        '
        Me.dtpVDOBGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpVDOBGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Location = New System.Drawing.Point(195, 123)
        Me.dtpVDOBGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Name = "dtpVDOBGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain"
        Me.dtpVDOBGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Size = New System.Drawing.Size(107, 22)
        Me.dtpVDOBGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.TabIndex = 7
        Me.tipTPMS.SetToolTip(Me.dtpVDOBGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain, "Select Vistor's date of birth")
        '
        'txtDatePurchasedGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain
        '
        Me.txtDatePurchasedGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Location = New System.Drawing.Point(195, 160)
        Me.txtDatePurchasedGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Name = "txtDatePurchasedGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain"
        Me.txtDatePurchasedGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.ReadOnly = True
        Me.txtDatePurchasedGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Size = New System.Drawing.Size(142, 22)
        Me.txtDatePurchasedGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.TabIndex = 10
        Me.tipTPMS.SetToolTip(Me.txtDatePurchasedGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain, "System generated purchase date")
        '
        'lstCustNameGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain
        '
        Me.lstCustNameGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lstCustNameGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.FormattingEnabled = True
        Me.lstCustNameGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.ItemHeight = 16
        Me.lstCustNameGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Items.AddRange(New Object() {"Test Customer1", "Test Customer2", "Test Customer2"})
        Me.lstCustNameGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Location = New System.Drawing.Point(193, 60)
        Me.lstCustNameGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Name = "lstCustNameGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain"
        Me.lstCustNameGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple
        Me.lstCustNameGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Size = New System.Drawing.Size(227, 18)
        Me.lstCustNameGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.TabIndex = 3
        Me.tipTPMS.SetToolTip(Me.lstCustNameGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain, "Select customer name from the list")
        '
        'lblDatePurchasedGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain
        '
        Me.lblDatePurchasedGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.AutoSize = True
        Me.lblDatePurchasedGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Location = New System.Drawing.Point(79, 163)
        Me.lblDatePurchasedGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Name = "lblDatePurchasedGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain"
        Me.lblDatePurchasedGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Size = New System.Drawing.Size(108, 16)
        Me.lblDatePurchasedGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.TabIndex = 9
        Me.lblDatePurchasedGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Text = "Date Purchased:"
        '
        'lblPassbookIdGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain
        '
        Me.lblPassbookIdGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.AutoSize = True
        Me.lblPassbookIdGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Location = New System.Drawing.Point(90, 26)
        Me.lblPassbookIdGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Name = "lblPassbookIdGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain"
        Me.lblPassbookIdGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Size = New System.Drawing.Size(98, 16)
        Me.lblPassbookIdGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.TabIndex = 0
        Me.lblPassbookIdGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Text = "Transaction ID:"
        '
        'txtTransactIdGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain
        '
        Me.txtTransactIdGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Location = New System.Drawing.Point(193, 23)
        Me.txtTransactIdGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Name = "txtTransactIdGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain"
        Me.txtTransactIdGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Size = New System.Drawing.Size(144, 22)
        Me.txtTransactIdGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.TabIndex = 1
        Me.tipTPMS.SetToolTip(Me.txtTransactIdGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain, "Enter the assigned transaction identifier")
        '
        'lblVDOBGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain
        '
        Me.lblVDOBGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.AutoSize = True
        Me.lblVDOBGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Location = New System.Drawing.Point(108, 128)
        Me.lblVDOBGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Name = "lblVDOBGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain"
        Me.lblVDOBGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Size = New System.Drawing.Size(80, 16)
        Me.lblVDOBGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.TabIndex = 6
        Me.lblVDOBGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Text = "Visitor DOB:"
        '
        'lblCustNameGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain
        '
        Me.lblCustNameGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.AutoSize = True
        Me.lblCustNameGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Location = New System.Drawing.Point(80, 60)
        Me.lblCustNameGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Name = "lblCustNameGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain"
        Me.lblCustNameGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Size = New System.Drawing.Size(108, 16)
        Me.lblCustNameGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.TabIndex = 2
        Me.lblCustNameGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Text = "Customer Name:"
        '
        'tabFeatureTbcPurchaseMainTabPurchaseTbcMain
        '
        Me.tabFeatureTbcPurchaseMainTabPurchaseTbcMain.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.tabFeatureTbcPurchaseMainTabPurchaseTbcMain.Controls.Add(Me.grpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain)
        Me.tabFeatureTbcPurchaseMainTabPurchaseTbcMain.Location = New System.Drawing.Point(4, 28)
        Me.tabFeatureTbcPurchaseMainTabPurchaseTbcMain.Name = "tabFeatureTbcPurchaseMainTabPurchaseTbcMain"
        Me.tabFeatureTbcPurchaseMainTabPurchaseTbcMain.Padding = New System.Windows.Forms.Padding(3)
        Me.tabFeatureTbcPurchaseMainTabPurchaseTbcMain.Size = New System.Drawing.Size(571, 371)
        Me.tabFeatureTbcPurchaseMainTabPurchaseTbcMain.TabIndex = 1
        Me.tabFeatureTbcPurchaseMainTabPurchaseTbcMain.Text = "Feature"
        Me.tabFeatureTbcPurchaseMainTabPurchaseTbcMain.ToolTipText = "Enter new Feature information"
        Me.tabFeatureTbcPurchaseMainTabPurchaseTbcMain.UseVisualStyleBackColor = True
        '
        'grpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain
        '
        Me.grpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Controls.Add(Me.lblTransIDGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain)
        Me.grpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Controls.Add(Me.btnCancelTabFeatureTbcPurchaseMainTabPurchaseTbcMain)
        Me.grpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Controls.Add(Me.btnSubmitTbcPurchaseMainTabPurchaseTbcMain)
        Me.grpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Controls.Add(Me.txtTransactDGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain)
        Me.grpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Controls.Add(Me.TextBox2)
        Me.grpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Controls.Add(Me.lblQtyGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain)
        Me.grpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Controls.Add(Me.nudQtyGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain)
        Me.grpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Controls.Add(Me.lstPassbookGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain)
        Me.grpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Controls.Add(Me.lstFeatureGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain)
        Me.grpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Controls.Add(Me.lblPassbookGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain)
        Me.grpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Controls.Add(Me.lblFeatureGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain)
        Me.grpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Location = New System.Drawing.Point(24, 24)
        Me.grpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Name = "grpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain"
        Me.grpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Size = New System.Drawing.Size(523, 324)
        Me.grpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.TabIndex = 0
        Me.grpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.TabStop = False
        Me.grpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Text = "Feature Info"
        Me.tipTPMS.SetToolTip(Me.grpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain, "Enter feature specific information")
        '
        'lblTransIDGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain
        '
        Me.lblTransIDGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.AutoSize = True
        Me.lblTransIDGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Location = New System.Drawing.Point(50, 37)
        Me.lblTransIDGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Name = "lblTransIDGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain"
        Me.lblTransIDGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Size = New System.Drawing.Size(98, 16)
        Me.lblTransIDGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.TabIndex = 0
        Me.lblTransIDGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Text = "Transaction ID:"
        '
        'btnCancelTabFeatureTbcPurchaseMainTabPurchaseTbcMain
        '
        Me.btnCancelTabFeatureTbcPurchaseMainTabPurchaseTbcMain.Location = New System.Drawing.Point(273, 288)
        Me.btnCancelTabFeatureTbcPurchaseMainTabPurchaseTbcMain.Name = "btnCancelTabFeatureTbcPurchaseMainTabPurchaseTbcMain"
        Me.btnCancelTabFeatureTbcPurchaseMainTabPurchaseTbcMain.Size = New System.Drawing.Size(75, 23)
        Me.btnCancelTabFeatureTbcPurchaseMainTabPurchaseTbcMain.TabIndex = 10
        Me.btnCancelTabFeatureTbcPurchaseMainTabPurchaseTbcMain.Text = "&Reset"
        Me.tipTPMS.SetToolTip(Me.btnCancelTabFeatureTbcPurchaseMainTabPurchaseTbcMain, "Click to reset all input fields")
        Me.btnCancelTabFeatureTbcPurchaseMainTabPurchaseTbcMain.UseVisualStyleBackColor = True
        '
        'btnSubmitTbcPurchaseMainTabPurchaseTbcMain
        '
        Me.btnSubmitTbcPurchaseMainTabPurchaseTbcMain.Location = New System.Drawing.Point(178, 288)
        Me.btnSubmitTbcPurchaseMainTabPurchaseTbcMain.Name = "btnSubmitTbcPurchaseMainTabPurchaseTbcMain"
        Me.btnSubmitTbcPurchaseMainTabPurchaseTbcMain.Size = New System.Drawing.Size(75, 23)
        Me.btnSubmitTbcPurchaseMainTabPurchaseTbcMain.TabIndex = 9
        Me.btnSubmitTbcPurchaseMainTabPurchaseTbcMain.Text = "&Submit"
        Me.tipTPMS.SetToolTip(Me.btnSubmitTbcPurchaseMainTabPurchaseTbcMain, "Click to validate and submit feature purchase")
        Me.btnSubmitTbcPurchaseMainTabPurchaseTbcMain.UseVisualStyleBackColor = True
        '
        'txtTransactDGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain
        '
        Me.txtTransactDGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.AccessibleRole = System.Windows.Forms.AccessibleRole.None
        Me.txtTransactDGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Location = New System.Drawing.Point(154, 31)
        Me.txtTransactDGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Name = "txtTransactDGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain"
        Me.txtTransactDGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Size = New System.Drawing.Size(144, 22)
        Me.txtTransactDGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.TabIndex = 1
        Me.tipTPMS.SetToolTip(Me.txtTransactDGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain, "Enter the assigned transaction identifier")
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(78, 200)
        Me.TextBox2.Multiline = True
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(358, 59)
        Me.TextBox2.TabIndex = 8
        Me.TextBox2.Text = "NOTE To Grader:  I am planning on displaying " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "a separate form that shows the Pas" &
    "sbook/Customer/" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Feature info when the Passbook selection is made"
        '
        'lblQtyGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain
        '
        Me.lblQtyGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.AutoSize = True
        Me.lblQtyGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Location = New System.Drawing.Point(89, 143)
        Me.lblQtyGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Name = "lblQtyGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain"
        Me.lblQtyGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Size = New System.Drawing.Size(59, 16)
        Me.lblQtyGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.TabIndex = 6
        Me.lblQtyGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Text = "Quantity:"
        '
        'nudQtyGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain
        '
        Me.nudQtyGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Location = New System.Drawing.Point(154, 141)
        Me.nudQtyGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Name = "nudQtyGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain"
        Me.nudQtyGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Size = New System.Drawing.Size(70, 22)
        Me.nudQtyGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.TabIndex = 7
        Me.tipTPMS.SetToolTip(Me.nudQtyGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain, "Enter the feature quantity to purchase")
        Me.nudQtyGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'lstPassbookGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain
        '
        Me.lstPassbookGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.FormattingEnabled = True
        Me.lstPassbookGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.ItemHeight = 16
        Me.lstPassbookGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Items.AddRange(New Object() {"Passbook 1", "Passbook 2", "Passbook 3", "Passbook 4"})
        Me.lstPassbookGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Location = New System.Drawing.Point(154, 103)
        Me.lstPassbookGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Name = "lstPassbookGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain"
        Me.lstPassbookGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple
        Me.lstPassbookGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Size = New System.Drawing.Size(236, 20)
        Me.lstPassbookGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.TabIndex = 5
        Me.tipTPMS.SetToolTip(Me.lstPassbookGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain, "Select the desired passbook from the list")
        '
        'lstFeatureGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain
        '
        Me.lstFeatureGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.FormattingEnabled = True
        Me.lstFeatureGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.ItemHeight = 16
        Me.lstFeatureGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Items.AddRange(New Object() {"Park Pass", "Parking Lot Pass", "Meal Plan", "Early Entry Pass"})
        Me.lstFeatureGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Location = New System.Drawing.Point(154, 68)
        Me.lstFeatureGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Name = "lstFeatureGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain"
        Me.lstFeatureGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Size = New System.Drawing.Size(236, 20)
        Me.lstFeatureGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.TabIndex = 3
        Me.tipTPMS.SetToolTip(Me.lstFeatureGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain, "Select the desired feature from the list")
        '
        'lblPassbookGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain
        '
        Me.lblPassbookGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.AutoSize = True
        Me.lblPassbookGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Location = New System.Drawing.Point(75, 107)
        Me.lblPassbookGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Name = "lblPassbookGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain"
        Me.lblPassbookGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Size = New System.Drawing.Size(73, 16)
        Me.lblPassbookGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.TabIndex = 4
        Me.lblPassbookGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Text = "Passbook:"
        '
        'lblFeatureGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain
        '
        Me.lblFeatureGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.AutoSize = True
        Me.lblFeatureGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Location = New System.Drawing.Point(91, 72)
        Me.lblFeatureGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Name = "lblFeatureGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain"
        Me.lblFeatureGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Size = New System.Drawing.Size(57, 16)
        Me.lblFeatureGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.TabIndex = 2
        Me.lblFeatureGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.Text = "Feature:"
        '
        'tabCustTbcMain
        '
        Me.tabCustTbcMain.BackColor = System.Drawing.Color.Gainsboro
        Me.tabCustTbcMain.Controls.Add(Me.tbcCustomerMainTabCustomerTbcMain)
        Me.tabCustTbcMain.Location = New System.Drawing.Point(4, 28)
        Me.tabCustTbcMain.Margin = New System.Windows.Forms.Padding(4)
        Me.tabCustTbcMain.Name = "tabCustTbcMain"
        Me.tabCustTbcMain.Padding = New System.Windows.Forms.Padding(4)
        Me.tabCustTbcMain.Size = New System.Drawing.Size(646, 448)
        Me.tabCustTbcMain.TabIndex = 0
        Me.tabCustTbcMain.Text = "Customer"
        Me.tipTPMS.SetToolTip(Me.tabCustTbcMain, "Customer information options")
        '
        'tbcCustomerMainTabCustomerTbcMain
        '
        Me.tbcCustomerMainTabCustomerTbcMain.Appearance = System.Windows.Forms.TabAppearance.Buttons
        Me.tbcCustomerMainTabCustomerTbcMain.Controls.Add(Me.tabAddTbcCustomerMainTabCustomerTbcMain)
        Me.tbcCustomerMainTabCustomerTbcMain.Controls.Add(Me.tabViewCustTbcCustomerMainTabCustomerTbcMain)
        Me.tbcCustomerMainTabCustomerTbcMain.Location = New System.Drawing.Point(34, 24)
        Me.tbcCustomerMainTabCustomerTbcMain.Multiline = True
        Me.tbcCustomerMainTabCustomerTbcMain.Name = "tbcCustomerMainTabCustomerTbcMain"
        Me.tbcCustomerMainTabCustomerTbcMain.SelectedIndex = 0
        Me.tbcCustomerMainTabCustomerTbcMain.Size = New System.Drawing.Size(579, 403)
        Me.tbcCustomerMainTabCustomerTbcMain.TabIndex = 0
        '
        'tabAddTbcCustomerMainTabCustomerTbcMain
        '
        Me.tabAddTbcCustomerMainTabCustomerTbcMain.BackColor = System.Drawing.SystemColors.Control
        Me.tabAddTbcCustomerMainTabCustomerTbcMain.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.tabAddTbcCustomerMainTabCustomerTbcMain.Controls.Add(Me.grpCustInfoTbcCustomerMainTabCustomerTbcMain)
        Me.tabAddTbcCustomerMainTabCustomerTbcMain.Location = New System.Drawing.Point(4, 28)
        Me.tabAddTbcCustomerMainTabCustomerTbcMain.Name = "tabAddTbcCustomerMainTabCustomerTbcMain"
        Me.tabAddTbcCustomerMainTabCustomerTbcMain.Padding = New System.Windows.Forms.Padding(3)
        Me.tabAddTbcCustomerMainTabCustomerTbcMain.Size = New System.Drawing.Size(571, 371)
        Me.tabAddTbcCustomerMainTabCustomerTbcMain.TabIndex = 0
        Me.tabAddTbcCustomerMainTabCustomerTbcMain.Text = "Add"
        Me.tipTPMS.SetToolTip(Me.tabAddTbcCustomerMainTabCustomerTbcMain, "Add customer to system")
        '
        'grpCustInfoTbcCustomerMainTabCustomerTbcMain
        '
        Me.grpCustInfoTbcCustomerMainTabCustomerTbcMain.BackColor = System.Drawing.SystemColors.Control
        Me.grpCustInfoTbcCustomerMainTabCustomerTbcMain.Controls.Add(Me.btnResetGrpCustInfoTbcCustomerMainTabCustomerTbcMain)
        Me.grpCustInfoTbcCustomerMainTabCustomerTbcMain.Controls.Add(Me.btnSubmitGrpCustInfoTbcCustomerMainTabCustomerTbcMain)
        Me.grpCustInfoTbcCustomerMainTabCustomerTbcMain.Controls.Add(Me.txtCustNameGrpCustInfoTbcCustomerMainTabCustomerTbcMain)
        Me.grpCustInfoTbcCustomerMainTabCustomerTbcMain.Controls.Add(Me.lblCustIdGrpCustInfoTbcCustomerMainTabCustomerTbcMain)
        Me.grpCustInfoTbcCustomerMainTabCustomerTbcMain.Controls.Add(Me.txtCustIdGrpCustInfoTbcCustomerMainTabCustomerTbcMain)
        Me.grpCustInfoTbcCustomerMainTabCustomerTbcMain.Controls.Add(Me.lblCustNameGrpCustInfoTbcCustomerMainTabCustomerTbcMain)
        Me.grpCustInfoTbcCustomerMainTabCustomerTbcMain.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.grpCustInfoTbcCustomerMainTabCustomerTbcMain.Location = New System.Drawing.Point(24, 24)
        Me.grpCustInfoTbcCustomerMainTabCustomerTbcMain.Margin = New System.Windows.Forms.Padding(4)
        Me.grpCustInfoTbcCustomerMainTabCustomerTbcMain.Name = "grpCustInfoTbcCustomerMainTabCustomerTbcMain"
        Me.grpCustInfoTbcCustomerMainTabCustomerTbcMain.Padding = New System.Windows.Forms.Padding(4)
        Me.grpCustInfoTbcCustomerMainTabCustomerTbcMain.Size = New System.Drawing.Size(523, 324)
        Me.grpCustInfoTbcCustomerMainTabCustomerTbcMain.TabIndex = 0
        Me.grpCustInfoTbcCustomerMainTabCustomerTbcMain.TabStop = False
        Me.grpCustInfoTbcCustomerMainTabCustomerTbcMain.Text = "Customer Info"
        Me.tipTPMS.SetToolTip(Me.grpCustInfoTbcCustomerMainTabCustomerTbcMain, "Enter customer specific information")
        '
        'btnResetGrpCustInfoTbcCustomerMainTabCustomerTbcMain
        '
        Me.btnResetGrpCustInfoTbcCustomerMainTabCustomerTbcMain.Location = New System.Drawing.Point(273, 288)
        Me.btnResetGrpCustInfoTbcCustomerMainTabCustomerTbcMain.Name = "btnResetGrpCustInfoTbcCustomerMainTabCustomerTbcMain"
        Me.btnResetGrpCustInfoTbcCustomerMainTabCustomerTbcMain.Size = New System.Drawing.Size(75, 23)
        Me.btnResetGrpCustInfoTbcCustomerMainTabCustomerTbcMain.TabIndex = 5
        Me.btnResetGrpCustInfoTbcCustomerMainTabCustomerTbcMain.Text = "&Reset"
        Me.tipTPMS.SetToolTip(Me.btnResetGrpCustInfoTbcCustomerMainTabCustomerTbcMain, "Click to reset input fields")
        Me.btnResetGrpCustInfoTbcCustomerMainTabCustomerTbcMain.UseVisualStyleBackColor = True
        '
        'btnSubmitGrpCustInfoTbcCustomerMainTabCustomerTbcMain
        '
        Me.btnSubmitGrpCustInfoTbcCustomerMainTabCustomerTbcMain.Location = New System.Drawing.Point(178, 288)
        Me.btnSubmitGrpCustInfoTbcCustomerMainTabCustomerTbcMain.Name = "btnSubmitGrpCustInfoTbcCustomerMainTabCustomerTbcMain"
        Me.btnSubmitGrpCustInfoTbcCustomerMainTabCustomerTbcMain.Size = New System.Drawing.Size(75, 23)
        Me.btnSubmitGrpCustInfoTbcCustomerMainTabCustomerTbcMain.TabIndex = 4
        Me.btnSubmitGrpCustInfoTbcCustomerMainTabCustomerTbcMain.Text = "&Submit"
        Me.tipTPMS.SetToolTip(Me.btnSubmitGrpCustInfoTbcCustomerMainTabCustomerTbcMain, "Click to validate and submit customer information")
        Me.btnSubmitGrpCustInfoTbcCustomerMainTabCustomerTbcMain.UseVisualStyleBackColor = True
        '
        'txtCustNameGrpCustInfoTbcCustomerMainTabCustomerTbcMain
        '
        Me.txtCustNameGrpCustInfoTbcCustomerMainTabCustomerTbcMain.Location = New System.Drawing.Point(194, 71)
        Me.txtCustNameGrpCustInfoTbcCustomerMainTabCustomerTbcMain.Name = "txtCustNameGrpCustInfoTbcCustomerMainTabCustomerTbcMain"
        Me.txtCustNameGrpCustInfoTbcCustomerMainTabCustomerTbcMain.Size = New System.Drawing.Size(249, 22)
        Me.txtCustNameGrpCustInfoTbcCustomerMainTabCustomerTbcMain.TabIndex = 3
        Me.tipTPMS.SetToolTip(Me.txtCustNameGrpCustInfoTbcCustomerMainTabCustomerTbcMain, "Enter customer name <LastName, FirstName>")
        '
        'lblCustIdGrpCustInfoTbcCustomerMainTabCustomerTbcMain
        '
        Me.lblCustIdGrpCustInfoTbcCustomerMainTabCustomerTbcMain.AutoSize = True
        Me.lblCustIdGrpCustInfoTbcCustomerMainTabCustomerTbcMain.Location = New System.Drawing.Point(104, 40)
        Me.lblCustIdGrpCustInfoTbcCustomerMainTabCustomerTbcMain.Name = "lblCustIdGrpCustInfoTbcCustomerMainTabCustomerTbcMain"
        Me.lblCustIdGrpCustInfoTbcCustomerMainTabCustomerTbcMain.Size = New System.Drawing.Size(84, 16)
        Me.lblCustIdGrpCustInfoTbcCustomerMainTabCustomerTbcMain.TabIndex = 0
        Me.lblCustIdGrpCustInfoTbcCustomerMainTabCustomerTbcMain.Text = "Customer ID:"
        Me.tipTPMS.SetToolTip(Me.lblCustIdGrpCustInfoTbcCustomerMainTabCustomerTbcMain, "Enter assigned customer ID")
        '
        'txtCustIdGrpCustInfoTbcCustomerMainTabCustomerTbcMain
        '
        Me.txtCustIdGrpCustInfoTbcCustomerMainTabCustomerTbcMain.Location = New System.Drawing.Point(194, 37)
        Me.txtCustIdGrpCustInfoTbcCustomerMainTabCustomerTbcMain.Name = "txtCustIdGrpCustInfoTbcCustomerMainTabCustomerTbcMain"
        Me.txtCustIdGrpCustInfoTbcCustomerMainTabCustomerTbcMain.Size = New System.Drawing.Size(144, 22)
        Me.txtCustIdGrpCustInfoTbcCustomerMainTabCustomerTbcMain.TabIndex = 1
        Me.tipTPMS.SetToolTip(Me.txtCustIdGrpCustInfoTbcCustomerMainTabCustomerTbcMain, "Enter unique customer identifier")
        '
        'lblCustNameGrpCustInfoTbcCustomerMainTabCustomerTbcMain
        '
        Me.lblCustNameGrpCustInfoTbcCustomerMainTabCustomerTbcMain.AutoSize = True
        Me.lblCustNameGrpCustInfoTbcCustomerMainTabCustomerTbcMain.Location = New System.Drawing.Point(80, 74)
        Me.lblCustNameGrpCustInfoTbcCustomerMainTabCustomerTbcMain.Name = "lblCustNameGrpCustInfoTbcCustomerMainTabCustomerTbcMain"
        Me.lblCustNameGrpCustInfoTbcCustomerMainTabCustomerTbcMain.Size = New System.Drawing.Size(108, 16)
        Me.lblCustNameGrpCustInfoTbcCustomerMainTabCustomerTbcMain.TabIndex = 2
        Me.lblCustNameGrpCustInfoTbcCustomerMainTabCustomerTbcMain.Text = "Customer Name:"
        '
        'tabViewCustTbcCustomerMainTabCustomerTbcMain
        '
        Me.tabViewCustTbcCustomerMainTabCustomerTbcMain.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.tabViewCustTbcCustomerMainTabCustomerTbcMain.Controls.Add(Me.grpCustInfo2TbcCustomerMainTabCustomerTbcMain)
        Me.tabViewCustTbcCustomerMainTabCustomerTbcMain.Location = New System.Drawing.Point(4, 28)
        Me.tabViewCustTbcCustomerMainTabCustomerTbcMain.Name = "tabViewCustTbcCustomerMainTabCustomerTbcMain"
        Me.tabViewCustTbcCustomerMainTabCustomerTbcMain.Padding = New System.Windows.Forms.Padding(3)
        Me.tabViewCustTbcCustomerMainTabCustomerTbcMain.Size = New System.Drawing.Size(571, 371)
        Me.tabViewCustTbcCustomerMainTabCustomerTbcMain.TabIndex = 1
        Me.tabViewCustTbcCustomerMainTabCustomerTbcMain.Text = "View"
        Me.tipTPMS.SetToolTip(Me.tabViewCustTbcCustomerMainTabCustomerTbcMain, "View customer specific information")
        Me.tabViewCustTbcCustomerMainTabCustomerTbcMain.UseVisualStyleBackColor = True
        '
        'grpCustInfo2TbcCustomerMainTabCustomerTbcMain
        '
        Me.grpCustInfo2TbcCustomerMainTabCustomerTbcMain.BackColor = System.Drawing.SystemColors.Control
        Me.grpCustInfo2TbcCustomerMainTabCustomerTbcMain.Controls.Add(Me.Button5)
        Me.grpCustInfo2TbcCustomerMainTabCustomerTbcMain.Controls.Add(Me.txtCustNameGrpCustInfo2TbcCustomerMainTabCustomerTbcMain)
        Me.grpCustInfo2TbcCustomerMainTabCustomerTbcMain.Controls.Add(Me.lblCustIdGrpCustInfo2TbcCustomerMainTabCustomerTbcMain)
        Me.grpCustInfo2TbcCustomerMainTabCustomerTbcMain.Controls.Add(Me.txtCustIdGrpCustInfo2TbcCustomerMainTabCustomerTbcMain)
        Me.grpCustInfo2TbcCustomerMainTabCustomerTbcMain.Controls.Add(Me.lblCustNameIdGrpCustInfo2TbcCustomerMainTabCustomerTbcMain)
        Me.grpCustInfo2TbcCustomerMainTabCustomerTbcMain.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.grpCustInfo2TbcCustomerMainTabCustomerTbcMain.Location = New System.Drawing.Point(24, 24)
        Me.grpCustInfo2TbcCustomerMainTabCustomerTbcMain.Margin = New System.Windows.Forms.Padding(4)
        Me.grpCustInfo2TbcCustomerMainTabCustomerTbcMain.Name = "grpCustInfo2TbcCustomerMainTabCustomerTbcMain"
        Me.grpCustInfo2TbcCustomerMainTabCustomerTbcMain.Padding = New System.Windows.Forms.Padding(4)
        Me.grpCustInfo2TbcCustomerMainTabCustomerTbcMain.Size = New System.Drawing.Size(523, 324)
        Me.grpCustInfo2TbcCustomerMainTabCustomerTbcMain.TabIndex = 0
        Me.grpCustInfo2TbcCustomerMainTabCustomerTbcMain.TabStop = False
        Me.grpCustInfo2TbcCustomerMainTabCustomerTbcMain.Text = "Customer Info"
        Me.tipTPMS.SetToolTip(Me.grpCustInfo2TbcCustomerMainTabCustomerTbcMain, "Enter customer specific information")
        '
        'Button5
        '
        Me.Button5.Location = New System.Drawing.Point(224, 288)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(75, 23)
        Me.Button5.TabIndex = 4
        Me.Button5.Text = "&Reset"
        Me.tipTPMS.SetToolTip(Me.Button5, "Click to reset input fields")
        Me.Button5.UseVisualStyleBackColor = True
        '
        'txtCustNameGrpCustInfo2TbcCustomerMainTabCustomerTbcMain
        '
        Me.txtCustNameGrpCustInfo2TbcCustomerMainTabCustomerTbcMain.Location = New System.Drawing.Point(194, 71)
        Me.txtCustNameGrpCustInfo2TbcCustomerMainTabCustomerTbcMain.Name = "txtCustNameGrpCustInfo2TbcCustomerMainTabCustomerTbcMain"
        Me.txtCustNameGrpCustInfo2TbcCustomerMainTabCustomerTbcMain.Size = New System.Drawing.Size(249, 22)
        Me.txtCustNameGrpCustInfo2TbcCustomerMainTabCustomerTbcMain.TabIndex = 4
        Me.tipTPMS.SetToolTip(Me.txtCustNameGrpCustInfo2TbcCustomerMainTabCustomerTbcMain, "Enter customer name <LastName, FirstName>")
        '
        'lblCustIdGrpCustInfo2TbcCustomerMainTabCustomerTbcMain
        '
        Me.lblCustIdGrpCustInfo2TbcCustomerMainTabCustomerTbcMain.AutoSize = True
        Me.lblCustIdGrpCustInfo2TbcCustomerMainTabCustomerTbcMain.Location = New System.Drawing.Point(104, 40)
        Me.lblCustIdGrpCustInfo2TbcCustomerMainTabCustomerTbcMain.Name = "lblCustIdGrpCustInfo2TbcCustomerMainTabCustomerTbcMain"
        Me.lblCustIdGrpCustInfo2TbcCustomerMainTabCustomerTbcMain.Size = New System.Drawing.Size(84, 16)
        Me.lblCustIdGrpCustInfo2TbcCustomerMainTabCustomerTbcMain.TabIndex = 1
        Me.lblCustIdGrpCustInfo2TbcCustomerMainTabCustomerTbcMain.Text = "Customer ID:"
        Me.tipTPMS.SetToolTip(Me.lblCustIdGrpCustInfo2TbcCustomerMainTabCustomerTbcMain, "Enter assigned customer ID")
        '
        'txtCustIdGrpCustInfo2TbcCustomerMainTabCustomerTbcMain
        '
        Me.txtCustIdGrpCustInfo2TbcCustomerMainTabCustomerTbcMain.Location = New System.Drawing.Point(194, 37)
        Me.txtCustIdGrpCustInfo2TbcCustomerMainTabCustomerTbcMain.Name = "txtCustIdGrpCustInfo2TbcCustomerMainTabCustomerTbcMain"
        Me.txtCustIdGrpCustInfo2TbcCustomerMainTabCustomerTbcMain.Size = New System.Drawing.Size(144, 22)
        Me.txtCustIdGrpCustInfo2TbcCustomerMainTabCustomerTbcMain.TabIndex = 2
        Me.tipTPMS.SetToolTip(Me.txtCustIdGrpCustInfo2TbcCustomerMainTabCustomerTbcMain, "Enter unique customer identifier")
        '
        'lblCustNameIdGrpCustInfo2TbcCustomerMainTabCustomerTbcMain
        '
        Me.lblCustNameIdGrpCustInfo2TbcCustomerMainTabCustomerTbcMain.AutoSize = True
        Me.lblCustNameIdGrpCustInfo2TbcCustomerMainTabCustomerTbcMain.Location = New System.Drawing.Point(80, 74)
        Me.lblCustNameIdGrpCustInfo2TbcCustomerMainTabCustomerTbcMain.Name = "lblCustNameIdGrpCustInfo2TbcCustomerMainTabCustomerTbcMain"
        Me.lblCustNameIdGrpCustInfo2TbcCustomerMainTabCustomerTbcMain.Size = New System.Drawing.Size(108, 16)
        Me.lblCustNameIdGrpCustInfo2TbcCustomerMainTabCustomerTbcMain.TabIndex = 3
        Me.lblCustNameIdGrpCustInfo2TbcCustomerMainTabCustomerTbcMain.Text = "Customer Name:"
        '
        'tbcMain
        '
        Me.tbcMain.Appearance = System.Windows.Forms.TabAppearance.Buttons
        Me.tbcMain.Controls.Add(Me.tabCustTbcMain)
        Me.tbcMain.Controls.Add(Me.tabPurchaseTbcMain)
        Me.tbcMain.Controls.Add(Me.tabPassbookFeatureTbcMain)
        Me.tbcMain.Controls.Add(Me.tabTransLogFeatureTbcMain)
        Me.tbcMain.Controls.Add(Me.tabSysKpiTbcMain)
        Me.tbcMain.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbcMain.Location = New System.Drawing.Point(44, 123)
        Me.tbcMain.Margin = New System.Windows.Forms.Padding(4)
        Me.tbcMain.Name = "tbcMain"
        Me.tbcMain.RightToLeftLayout = True
        Me.tbcMain.SelectedIndex = 0
        Me.tbcMain.Size = New System.Drawing.Size(654, 480)
        Me.tbcMain.TabIndex = 2
        '
        'tabTransLogFeatureTbcMain
        '
        Me.tabTransLogFeatureTbcMain.BackColor = System.Drawing.Color.Gainsboro
        Me.tabTransLogFeatureTbcMain.Controls.Add(Me.grpTransLogTabTransLogTbcMain)
        Me.tabTransLogFeatureTbcMain.Location = New System.Drawing.Point(4, 28)
        Me.tabTransLogFeatureTbcMain.Name = "tabTransLogFeatureTbcMain"
        Me.tabTransLogFeatureTbcMain.Padding = New System.Windows.Forms.Padding(3)
        Me.tabTransLogFeatureTbcMain.Size = New System.Drawing.Size(646, 448)
        Me.tabTransLogFeatureTbcMain.TabIndex = 4
        Me.tabTransLogFeatureTbcMain.Text = "Transaction Log"
        Me.tipTPMS.SetToolTip(Me.tabTransLogFeatureTbcMain, "View sys transaction log")
        '
        'grpTransLogTabTransLogTbcMain
        '
        Me.grpTransLogTabTransLogTbcMain.Controls.Add(Me.btnTransLogTabTransLogTbcMain)
        Me.grpTransLogTabTransLogTbcMain.Controls.Add(Me.txtTransLogTabTransLogTbcMain)
        Me.grpTransLogTabTransLogTbcMain.Location = New System.Drawing.Point(34, 24)
        Me.grpTransLogTabTransLogTbcMain.Name = "grpTransLogTabTransLogTbcMain"
        Me.grpTransLogTabTransLogTbcMain.Size = New System.Drawing.Size(579, 403)
        Me.grpTransLogTabTransLogTbcMain.TabIndex = 0
        Me.grpTransLogTabTransLogTbcMain.TabStop = False
        Me.grpTransLogTabTransLogTbcMain.Text = "System Transaction Log"
        '
        'btnTransLogTabTransLogTbcMain
        '
        Me.btnTransLogTabTransLogTbcMain.Location = New System.Drawing.Point(252, 362)
        Me.btnTransLogTabTransLogTbcMain.Name = "btnTransLogTabTransLogTbcMain"
        Me.btnTransLogTabTransLogTbcMain.Size = New System.Drawing.Size(75, 23)
        Me.btnTransLogTabTransLogTbcMain.TabIndex = 1
        Me.btnTransLogTabTransLogTbcMain.Text = "Clea&r"
        Me.tipTPMS.SetToolTip(Me.btnTransLogTabTransLogTbcMain, "Click to Clear window")
        Me.btnTransLogTabTransLogTbcMain.UseVisualStyleBackColor = True
        '
        'txtTransLogTabTransLogTbcMain
        '
        Me.txtTransLogTabTransLogTbcMain.Location = New System.Drawing.Point(28, 30)
        Me.txtTransLogTabTransLogTbcMain.Multiline = True
        Me.txtTransLogTabTransLogTbcMain.Name = "txtTransLogTabTransLogTbcMain"
        Me.txtTransLogTabTransLogTbcMain.ReadOnly = True
        Me.txtTransLogTabTransLogTbcMain.Size = New System.Drawing.Size(523, 318)
        Me.txtTransLogTabTransLogTbcMain.TabIndex = 0
        Me.tipTPMS.SetToolTip(Me.txtTransLogTabTransLogTbcMain, "Displays current system transaction log")
        '
        'tabSysKpiTbcMain
        '
        Me.tabSysKpiTbcMain.BackColor = System.Drawing.Color.Gainsboro
        Me.tabSysKpiTbcMain.Controls.Add(Me.grpKpiTabDashboardTbcMain)
        Me.tabSysKpiTbcMain.Location = New System.Drawing.Point(4, 28)
        Me.tabSysKpiTbcMain.Name = "tabSysKpiTbcMain"
        Me.tabSysKpiTbcMain.Padding = New System.Windows.Forms.Padding(3)
        Me.tabSysKpiTbcMain.Size = New System.Drawing.Size(646, 448)
        Me.tabSysKpiTbcMain.TabIndex = 5
        Me.tabSysKpiTbcMain.Text = "Dashboard"
        '
        'grpKpiTabDashboardTbcMain
        '
        Me.grpKpiTabDashboardTbcMain.BackColor = System.Drawing.Color.Gainsboro
        Me.grpKpiTabDashboardTbcMain.Controls.Add(Me.TextBox6)
        Me.grpKpiTabDashboardTbcMain.Location = New System.Drawing.Point(34, 24)
        Me.grpKpiTabDashboardTbcMain.Name = "grpKpiTabDashboardTbcMain"
        Me.grpKpiTabDashboardTbcMain.Size = New System.Drawing.Size(579, 403)
        Me.grpKpiTabDashboardTbcMain.TabIndex = 0
        Me.grpKpiTabDashboardTbcMain.TabStop = False
        Me.grpKpiTabDashboardTbcMain.Text = "Key Performance Indicators"
        Me.tipTPMS.SetToolTip(Me.grpKpiTabDashboardTbcMain, "Displays system wide key performance indicators")
        '
        'TextBox6
        '
        Me.TextBox6.Location = New System.Drawing.Point(45, 39)
        Me.TextBox6.Multiline = True
        Me.TextBox6.Name = "TextBox6"
        Me.TextBox6.ReadOnly = True
        Me.TextBox6.Size = New System.Drawing.Size(506, 133)
        Me.TextBox6.TabIndex = 0
        Me.TextBox6.Text = "NOTE TO GRADER:  Details will be added later as the project progresses.  This is " &
    "more or lessa placehold until more specifics are given as to what indicators sho" &
    "uld be tracked and provided."
        Me.tipTPMS.SetToolTip(Me.TextBox6, "Displays current system transaction log")
        '
        'btnExitFrmMain
        '
        Me.btnExitFrmMain.BackColor = System.Drawing.Color.Transparent
        Me.btnExitFrmMain.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExitFrmMain.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.btnExitFrmMain.Location = New System.Drawing.Point(323, 634)
        Me.btnExitFrmMain.Name = "btnExitFrmMain"
        Me.btnExitFrmMain.Size = New System.Drawing.Size(99, 30)
        Me.btnExitFrmMain.TabIndex = 3
        Me.btnExitFrmMain.Text = "E&xit"
        Me.btnExitFrmMain.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage
        Me.tipTPMS.SetToolTip(Me.btnExitFrmMain, "Click to Exit and shutdown the system")
        Me.btnExitFrmMain.UseVisualStyleBackColor = False
        '
        'tipTPMS
        '
        Me.tipTPMS.AutomaticDelay = 300
        '
        'txtCustIdTabAddCustTbcCustomerMainTabCustomerTbcMain
        '
        Me.txtCustIdTabAddCustTbcCustomerMainTabCustomerTbcMain.Location = New System.Drawing.Point(194, 60)
        Me.txtCustIdTabAddCustTbcCustomerMainTabCustomerTbcMain.Name = "txtCustIdTabAddCustTbcCustomerMainTabCustomerTbcMain"
        Me.txtCustIdTabAddCustTbcCustomerMainTabCustomerTbcMain.Size = New System.Drawing.Size(144, 20)
        Me.txtCustIdTabAddCustTbcCustomerMainTabCustomerTbcMain.TabIndex = 1
        Me.tipTPMS.SetToolTip(Me.txtCustIdTabAddCustTbcCustomerMainTabCustomerTbcMain, "Enter the assigned customer ID")
        '
        'txtCustNameTabAddCustTbcCustomerMainTabCustomerTbcMain
        '
        Me.txtCustNameTabAddCustTbcCustomerMainTabCustomerTbcMain.Location = New System.Drawing.Point(194, 95)
        Me.txtCustNameTabAddCustTbcCustomerMainTabCustomerTbcMain.Name = "txtCustNameTabAddCustTbcCustomerMainTabCustomerTbcMain"
        Me.txtCustNameTabAddCustTbcCustomerMainTabCustomerTbcMain.Size = New System.Drawing.Size(249, 20)
        Me.txtCustNameTabAddCustTbcCustomerMainTabCustomerTbcMain.TabIndex = 3
        Me.tipTPMS.SetToolTip(Me.txtCustNameTabAddCustTbcCustomerMainTabCustomerTbcMain, "Enter customer name  <Lastname., Firstname>")
        '
        'btnAddGrpCustInfoTcbMain
        '
        Me.btnAddGrpCustInfoTcbMain.Location = New System.Drawing.Point(178, 288)
        Me.btnAddGrpCustInfoTcbMain.Name = "btnAddGrpCustInfoTcbMain"
        Me.btnAddGrpCustInfoTcbMain.Size = New System.Drawing.Size(75, 23)
        Me.btnAddGrpCustInfoTcbMain.TabIndex = 4
        Me.btnAddGrpCustInfoTcbMain.Text = "&Add"
        Me.tipTPMS.SetToolTip(Me.btnAddGrpCustInfoTcbMain, "Click to validate and submit customer information")
        Me.btnAddGrpCustInfoTcbMain.UseVisualStyleBackColor = True
        '
        'btnResetGrpCustInfoTcbMain
        '
        Me.btnResetGrpCustInfoTcbMain.Location = New System.Drawing.Point(273, 288)
        Me.btnResetGrpCustInfoTcbMain.Name = "btnResetGrpCustInfoTcbMain"
        Me.btnResetGrpCustInfoTcbMain.Size = New System.Drawing.Size(75, 23)
        Me.btnResetGrpCustInfoTcbMain.TabIndex = 5
        Me.btnResetGrpCustInfoTcbMain.Text = "&Reset"
        Me.tipTPMS.SetToolTip(Me.btnResetGrpCustInfoTcbMain, "Click to reset input fields")
        Me.btnResetGrpCustInfoTcbMain.UseVisualStyleBackColor = True
        '
        'btnTesttFrmMain
        '
        Me.btnTesttFrmMain.Location = New System.Drawing.Point(619, 638)
        Me.btnTesttFrmMain.Name = "btnTesttFrmMain"
        Me.btnTesttFrmMain.Size = New System.Drawing.Size(75, 23)
        Me.btnTesttFrmMain.TabIndex = 4
        Me.btnTesttFrmMain.Text = "Te&st"
        Me.btnTesttFrmMain.UseVisualStyleBackColor = True
        '
        'lblCustIdTabAddCustTbcCustomerMainTabCustomerTbcMain
        '
        Me.lblCustIdTabAddCustTbcCustomerMainTabCustomerTbcMain.AutoSize = True
        Me.lblCustIdTabAddCustTbcCustomerMainTabCustomerTbcMain.Location = New System.Drawing.Point(104, 63)
        Me.lblCustIdTabAddCustTbcCustomerMainTabCustomerTbcMain.Name = "lblCustIdTabAddCustTbcCustomerMainTabCustomerTbcMain"
        Me.lblCustIdTabAddCustTbcCustomerMainTabCustomerTbcMain.Size = New System.Drawing.Size(84, 16)
        Me.lblCustIdTabAddCustTbcCustomerMainTabCustomerTbcMain.TabIndex = 0
        '
        'lblCustNameTabAddCustTbcCustomerMainTabCustomerTbcMain
        '
        Me.lblCustNameTabAddCustTbcCustomerMainTabCustomerTbcMain.AutoSize = True
        Me.lblCustNameTabAddCustTbcCustomerMainTabCustomerTbcMain.Location = New System.Drawing.Point(80, 100)
        Me.lblCustNameTabAddCustTbcCustomerMainTabCustomerTbcMain.Name = "lblCustNameTabAddCustTbcCustomerMainTabCustomerTbcMain"
        Me.lblCustNameTabAddCustTbcCustomerMainTabCustomerTbcMain.Size = New System.Drawing.Size(108, 16)
        Me.lblCustNameTabAddCustTbcCustomerMainTabCustomerTbcMain.TabIndex = 2
        '
        'FrmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Beige
        Me.ClientSize = New System.Drawing.Size(742, 687)
        Me.Controls.Add(Me.btnTesttFrmMain)
        Me.Controls.Add(Me.btnExitFrmMain)
        Me.Controls.Add(Me.tbcMain)
        Me.Controls.Add(Me.lblThemeParkMgmtSys)
        Me.Controls.Add(Me.mnuMainApplMenu)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MainMenuStrip = Me.mnuMainApplMenu
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "FrmMain"
        Me.Text = "Theme Park Management System"
        Me.mnuMainApplMenu.ResumeLayout(False)
        Me.mnuMainApplMenu.PerformLayout()
        Me.tabPassbookFeatureTbcMain.ResumeLayout(False)
        Me.tbcPassbookFeatureMainTbcMain.ResumeLayout(False)
        Me.tabAddFeatureTbcPassbookFeatureMainTbcMain.ResumeLayout(False)
        Me.grpAddFeatureTbcPassbookFeatureMainTbcMain.ResumeLayout(False)
        Me.grpAddFeatureTbcPassbookFeatureMainTbcMain.PerformLayout()
        Me.tabUpdtFeatureTbcPassbookFeatureMainTbcMain.ResumeLayout(False)
        Me.grpUpdtFeatureTbcPassbookFeatureMainTbcMain.ResumeLayout(False)
        Me.grpUpdtFeatureTbcPassbookFeatureMainTbcMain.PerformLayout()
        CType(Me.NumericUpDown1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tabPostFeatureTbcPassbookFeatureMainTbcMain.ResumeLayout(False)
        Me.grpPostFeatureTbcPassbookFeatureMainTbcMain.ResumeLayout(False)
        Me.grpPostFeatureTbcPassbookFeatureMainTbcMain.PerformLayout()
        CType(Me.NumericUpDown2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tabPurchaseTbcMain.ResumeLayout(False)
        Me.tbcPurchaseMainTabPurchaseTbcMain.ResumeLayout(False)
        Me.tabPassbookTbcPurchaseMainTabPurchaseTbcMain.ResumeLayout(False)
        Me.grpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.ResumeLayout(False)
        Me.grpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.PerformLayout()
        Me.tabFeatureTbcPurchaseMainTabPurchaseTbcMain.ResumeLayout(False)
        Me.grpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.ResumeLayout(False)
        Me.grpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain.PerformLayout()
        CType(Me.nudQtyGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tabCustTbcMain.ResumeLayout(False)
        Me.tbcCustomerMainTabCustomerTbcMain.ResumeLayout(False)
        Me.tabAddTbcCustomerMainTabCustomerTbcMain.ResumeLayout(False)
        Me.grpCustInfoTbcCustomerMainTabCustomerTbcMain.ResumeLayout(False)
        Me.grpCustInfoTbcCustomerMainTabCustomerTbcMain.PerformLayout()
        Me.tabViewCustTbcCustomerMainTabCustomerTbcMain.ResumeLayout(False)
        Me.grpCustInfo2TbcCustomerMainTabCustomerTbcMain.ResumeLayout(False)
        Me.grpCustInfo2TbcCustomerMainTabCustomerTbcMain.PerformLayout()
        Me.tbcMain.ResumeLayout(False)
        Me.tabTransLogFeatureTbcMain.ResumeLayout(False)
        Me.grpTransLogTabTransLogTbcMain.ResumeLayout(False)
        Me.grpTransLogTabTransLogTbcMain.PerformLayout()
        Me.tabSysKpiTbcMain.ResumeLayout(False)
        Me.grpKpiTabDashboardTbcMain.ResumeLayout(False)
        Me.grpKpiTabDashboardTbcMain.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents mnuMainApplMenu As MenuStrip
    Friend WithEvents mnuFileFrmMain As ToolStripMenuItem
    Friend WithEvents mnuSaveFileFrmMain As ToolStripMenuItem
    Friend WithEvents mnuImportFileFrmMain As ToolStripMenuItem
    Friend WithEvents mnuExportFileFrmMain As ToolStripMenuItem
    Friend WithEvents mnuExitFileFrmMain As ToolStripMenuItem
    Friend WithEvents mnuEditFrmMain As ToolStripMenuItem
    Friend WithEvents mnuCutEditFrmMain As ToolStripMenuItem
    Friend WithEvents mnuCopyEditFrmMain As ToolStripMenuItem
    Friend WithEvents mnuPasteEditFrmMain As ToolStripMenuItem
    Friend WithEvents mnuViewFrmMain As ToolStripMenuItem
    Friend WithEvents mnuHelpFrmMain As ToolStripMenuItem
    Friend WithEvents mnuAboutHelpFrmMain As ToolStripMenuItem
    Friend WithEvents lblThemeParkMgmtSys As Label
    Friend WithEvents mnuDashboardViewFrmMain As ToolStripMenuItem
    Friend WithEvents mnuTransLogViewFrmMain As ToolStripMenuItem
    Friend WithEvents mnuPassbooksFrmMain As ToolStripMenuItem
    Friend WithEvents mnuPurchasePassbooksFrmMain As ToolStripMenuItem
    Friend WithEvents mnuFeaturePassbooksFrmMain As ToolStripMenuItem
    Friend WithEvents tabPassbookFeatureTbcMain As TabPage
    Friend WithEvents tbcPassbookFeatureMainTbcMain As TabControl
    Friend WithEvents tabAddFeatureTbcPassbookFeatureMainTbcMain As TabPage
    Friend WithEvents tabUpdtFeatureTbcPassbookFeatureMainTbcMain As TabPage
    Friend WithEvents grpUpdtFeatureTbcPassbookFeatureMainTbcMain As GroupBox
    Friend WithEvents lblPassbookIdTabUpdtFeatureTbcPassbookFeatureMainTbcMain As Label
    Private WithEvents txtPassbookIdTabUpdtFeatureTbcPassbookFeatureMainTbcMain As TextBox
    Friend WithEvents tabPurchaseTbcMain As TabPage
    Friend WithEvents tbcPurchaseMainTabPurchaseTbcMain As TabControl
    Friend WithEvents tabPassbookTbcPurchaseMainTabPurchaseTbcMain As TabPage
    Friend WithEvents tabFeatureTbcPurchaseMainTabPurchaseTbcMain As TabPage
    Friend WithEvents tabCustTbcMain As TabPage
    Friend WithEvents tbcMain As TabControl
    Friend WithEvents mnuAddFeaturesPassbooksFrmMain As ToolStripMenuItem
    Friend WithEvents mnuUpdateFeaturesPassbooksFrmMain As ToolStripMenuItem
    Friend WithEvents btnExitFrmMain As Button
    Friend WithEvents grpAddFeatureTbcPassbookFeatureMainTbcMain As GroupBox
    Friend WithEvents txtPriceAdultTabAddFeatureTbcPassbookFeatureMainTbcMain As TextBox
    Friend WithEvents txtUnitOfMeasAddFeatureTbcPassbookFeatureMainTbcMain As TextBox
    Friend WithEvents lblUnitOfMeasTabAddFeatureTbcPassbookFeatureMainTbcMain As Label
    Friend WithEvents TextBox3 As TextBox
    Friend WithEvents lblFeatureIdTabAddFeatureTbcPassbookFeatureMainTbcMain As Label
    Private WithEvents txtFeatureIdTabAddFeatureTbcPassbookFeatureMainTbcMain As TextBox
    Friend WithEvents lblPriceTabAddFeatureTbcPassbookFeatureMainTbcMain As Label
    Friend WithEvents lblFeatureNameTabAddFeatureTbcPassbookFeatureMainTbcMain As Label
    Friend WithEvents btnCancelTabFeatureTbcPurchaseMainTabPurchaseTbcMain As Button
    Friend WithEvents btnSubmitTbcPurchaseMainTabPurchaseTbcMain As Button
    Friend WithEvents btnResetGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain As Button
    Friend WithEvents btnSubmitGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain As Button
    Friend WithEvents grpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain As GroupBox
    Friend WithEvents lblDatePurchasedGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain As Label
    Friend WithEvents lblPassbookIdGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain As Label
    Private WithEvents txtTransactIdGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain As TextBox
    Friend WithEvents lblVDOBGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain As Label
    Friend WithEvents lblCustNameGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain As Label
    Friend WithEvents lstCustNameGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain As ListBox
    Friend WithEvents txtDatePurchasedGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain As TextBox
    Friend WithEvents dtpVDOBGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain As DateTimePicker
    Friend WithEvents lblVNameGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain As Label
    Friend WithEvents txtVNameGrpPassbookInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain As TextBox
    Friend WithEvents chkVChildPassbookIfnoTabPassbookTbcPurchaseMainTabPurchaseTbcMain As CheckBox
    Friend WithEvents grpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain As GroupBox
    Friend WithEvents lblPassbookGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain As Label
    Friend WithEvents lblFeatureGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain As Label
    Friend WithEvents tipTPMS As ToolTip
    Friend WithEvents txtPriceChildTabAddFeatureTbcPassbookFeatureMainTbcMain As TextBox
    Friend WithEvents lblPriceChildTabAddFeatureTbcPassbookFeatureMainTbcMain As Label
    Friend WithEvents lstFeatureGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain As ListBox
    Friend WithEvents lstPassbookGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain As ListBox
    Friend WithEvents nudQtyGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain As NumericUpDown
    Friend WithEvents lblQtyGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain As Label
    Friend WithEvents tabPostFeatureTbcPassbookFeatureMainTbcMain As TabPage
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents lblQtyTabUpdtFeatureTbcPassbookFeatureMainTbcMain As Label
    Friend WithEvents NumericUpDown1 As NumericUpDown
    Friend WithEvents lstPassbookTabUpdtFeatureTbcPassbookFeatureMainTbcMain As ListBox
    Friend WithEvents lblPassbookTabUpdtFeatureTbcPassbookFeatureMainTbcMain As Label
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents grpPostFeatureTbcPassbookFeatureMainTbcMain As GroupBox
    Friend WithEvents TextBox4 As TextBox
    Friend WithEvents lblQtyGrpUpdtFeatureTbcPassbookFeatureMainTbcMain As Label
    Friend WithEvents NumericUpDown2 As NumericUpDown
    Friend WithEvents lstPassbookGrpUpdtFeatureTbcPassbookFeatureMainTbcMain As ListBox
    Friend WithEvents lblPassbookGrpUpdtFeatureTbcPassbookFeatureMainTbcMain As Label
    Friend WithEvents lblPassbookFeatureIddGrpUpdtFeatureTbcPassbookFeatureMainTbcMain As Label
    Private WithEvents txtPassbookFeatureIddGrpUpdtFeatureTbcPassbookFeatureMainTbcMain As TextBox
    Friend WithEvents lstFeatureGrpUpdtFeatureTbcPassbookFeatureMainTbcMain As ListBox
    Friend WithEvents lblFeatureGrpUpdtFeatureTbcPassbookFeatureMainTbcMain As Label
    Friend WithEvents lblTransIDGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain As Label
    Private WithEvents txtTransactDGrpFeatureInfoTabPassbookTbcPurchaseMainTabPurchaseTbcMain As TextBox
    Private WithEvents TextBox5 As TextBox
    Friend WithEvents lblLocationGrpUpdtFeatureTbcPassbookFeatureMainTbcMain As Label
    Friend WithEvents tabTransLogFeatureTbcMain As TabPage
    Friend WithEvents grpTransLogTabTransLogTbcMain As GroupBox
    Friend WithEvents txtTransLogTabTransLogTbcMain As TextBox
    Friend WithEvents tabSysKpiTbcMain As TabPage
    Friend WithEvents grpKpiTabDashboardTbcMain As GroupBox
    Friend WithEvents TextBox6 As TextBox
    Friend WithEvents mnuTestFrmMain As ToolStripMenuItem
    Friend WithEvents mnuImportTestFrmMain As ToolStripMenuItem
    Friend WithEvents mnuExportTestFrmMain As ToolStripMenuItem
    Friend WithEvents mnuPassbookPurchasePassbooksFrmMain As ToolStripMenuItem
    Friend WithEvents mnuFeaturePurchasePassbooksFrmMain As ToolStripMenuItem
    Friend WithEvents Button2 As Button
    Friend WithEvents btnSubmitGrpUpdtFeatureTbcPassbookFeatureMainTbcMain As Button
    Friend WithEvents btnTesttFrmMain As Button
    Friend WithEvents btnResetTabUpdtFeatureTbcPassbookFeatureMainTbcMain As Button
    Friend WithEvents btnSubmitTabUpdtFeatureTbcPassbookFeatureMainTbcMain As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents btnTransLogTabTransLogTbcMain As Button
    Friend WithEvents tbcCustomerMainTabCustomerTbcMain As TabControl
    Friend WithEvents tabAddTbcCustomerMainTabCustomerTbcMain As TabPage
    Friend WithEvents grpCustInfoTbcCustomerMainTabCustomerTbcMain As GroupBox
    Friend WithEvents lblCustIdTabAddCustTbcCustomerMainTabCustomerTbcMain As Label
    Friend WithEvents txtCustIdTabAddCustTbcCustomerMainTabCustomerTbcMain As TextBox
    Friend WithEvents lblCustNameTabAddCustTbcCustomerMainTabCustomerTbcMain As Label
    Friend WithEvents txtCustNameTabAddCustTbcCustomerMainTabCustomerTbcMain As TextBox
    Friend WithEvents btnAddGrpCustInfoTcbMain As Button
    Friend WithEvents btnResetGrpCustInfoTcbMain As Button
    Friend WithEvents txtCustNameGrpCustInfoTbcCustomerMainTabCustomerTbcMain As TextBox
    Friend WithEvents lblCustIdGrpCustInfoTbcCustomerMainTabCustomerTbcMain As Label
    Private WithEvents txtCustIdGrpCustInfoTbcCustomerMainTabCustomerTbcMain As TextBox
    Friend WithEvents lblCustNameGrpCustInfoTbcCustomerMainTabCustomerTbcMain As Label
    Friend WithEvents btnResetGrpCustInfoTbcCustomerMainTabCustomerTbcMain As Button
    Friend WithEvents btnSubmitGrpCustInfoTbcCustomerMainTabCustomerTbcMain As Button
    Friend WithEvents tabViewCustTbcCustomerMainTabCustomerTbcMain As TabPage
    Friend WithEvents grpCustInfo2TbcCustomerMainTabCustomerTbcMain As GroupBox
    Friend WithEvents Button5 As Button
    Friend WithEvents txtCustNameGrpCustInfo2TbcCustomerMainTabCustomerTbcMain As TextBox
    Friend WithEvents lblCustIdGrpCustInfo2TbcCustomerMainTabCustomerTbcMain As Label
    Private WithEvents txtCustIdGrpCustInfo2TbcCustomerMainTabCustomerTbcMain As TextBox
    Friend WithEvents lblCustNameIdGrpCustInfo2TbcCustomerMainTabCustomerTbcMain As Label
End Class
